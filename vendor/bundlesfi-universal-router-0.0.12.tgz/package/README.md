# @bundlesfi/universal-router

A powerful router library for optimized token swaps on EVM chains, specializing in Bundles and Antfarm ecosystem tokens.

## Features

- **Multi-DEX Aggregation**: Routes trades across Uniswap V2, Uniswap V3, Bundles Swap, Antfarm, and Trader Joe.
- **Bundle Optimization**: Intelligent routing for Bundle tokens, supporting both direct swaps and mint/burn paths (e.g., buying underlying tokens and minting the bundle).
- **Flexible Configuration**: Fully configurable chain settings and contract addresses via the `Config` class.
- **Gas Optimized**: Generates efficient calldata for the Universal Router contract.

## Installation

```bash
npm install @bundlesfi/universal-router viem
```

## Usage

### Basic Setup

Initialize the `Router` with a `viem` PublicClient and configuration.

```typescript
import { createPublicClient, http } from "viem";
import { mainnet } from "viem/chains";
import { Router, defaultConfig } from "@bundlesfi/universal-router";

// 1. Create a viem client
const client = createPublicClient({
  chain: defaultConfig.chain, // or mainnet
  transport: defaultConfig.transport,
});

// 2. Initialize the router
// Uses defaultConfig (Mainnet) by default if no config provided
const router = new Router(client, defaultConfig);
```

### Finding the Best Route

Find the optimal path for swapping tokens.

```typescript
import { parseEther } from "viem";

const WETH = defaultConfig.contracts.weth;
const USDC = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48";
const amountIn = parseEther("1"); // 1 ETH

// Find best route for 1 WETH -> USDC
const result = await router.findBestRoute(
  [WETH, USDC],
  amountIn,
  recipientAddress
);

console.log(`Best quote: ${result.quote.toString()}`);
console.log(`Calldata: ${result.calldata}`);
```

### Bundle Operations

The router allows you to seamlessly buy or sell Bundles, automatically comparing direct secondary market swaps against primary market mint/burn operations.

```typescript
// Buy a Bundle with ETH
const bundleAddress = "0x...";
const buyResult = await router.findBestExactOutWithBundle(
  ["ETH", bundleAddress],
  bundleAmount,
  recipientAddress,
  { token: bundleAddress, isBuying: true }
);

// Sell a Bundle for ETH
const sellResult = await router.findBestExactInWithBundle(
  [bundleAddress, "ETH"],
  bundleAmount,
  recipientAddress,
  { token: bundleAddress, isBuying: false }
);
```

## Configuration

The library uses a `Config` class to manage chain-specific addresses. The default configuration targets Ethereum Mainnet.

To support other chains or override specific addresses:

```typescript
import { Config, RouterConfig } from "@bundlesfi/universal-router";

const myConfig = new Config({
  chain: myChain, // e.g., via viem/chains
  transport: http("https://..."),
  contracts: {
    ...defaultConfig.contracts,
    uniswapV2Router: "0x...", // Override specific contract
  }
});

const router = new Router(client, myConfig);
```

## Running Examples

The repository includes several example scripts to demonstrate functionality and simulate transactions.

You can run them using `tsx`:

```bash
# Simulate buying a Bundle
npx tsx src/examples/simulateBundleBuy.ts

# Simulate selling a Bundle
npx tsx src/examples/simulateBundleSell.ts

# Simulate creating a new Token Index
npx tsx src/examples/simulateCreateIndex.ts

# Test Bundle routes (Direct vs Mint/Burn)
npx tsx src/examples/testBundleRoutes.ts
```

## License

CC0-1.0