import {
  createPublicClient,
  http,
  decodeErrorResult,
  decodeAbiParameters,
  parseAbiParameters,
} from "viem";
import type { Address, Hex } from "viem";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";
import { Router } from "../router/Router.js";
import { universalRouterAbi } from "../contracts/abis.js";
import { simulateOnChain } from "../utils/simulation.js";
import { getRevertDataFromError } from "../utils/errorHelpers.js";
import { registerAdaptersForChain } from "../utils/routerHelpers.js";
import { mainnet } from "viem/chains";

/**
 * Simulate SELL 1000 units (18 decimals) of bundle 0xD52F... on-chain.
 * Uses account 0x0a0F... (has enough tokens). Run with: uncomment simulateBundleSellExample below.
 * If you get "No successful quote from any route", try a smaller amount (e.g. 50n * 10n ** 18n) for this bundle.
 */
export async function simulateBundleSellExample() {
  const client = createPublicClient({
    chain: mainnet,
    transport: http("https://eth.api.pocket.network"),
  });

  const router = new Router(client, DEFAULT_CONTRACT_ADDRESSES);
  registerAdaptersForChain(router, client, mainnet.id, DEFAULT_CONTRACT_ADDRESSES);

  const bundleAddress = "0xD52F7513B04b51110DAc8e3dd365aA9a1CCb2634" as Address;
  const amount = 600n * 10n ** 18n; // 1000 units, 18 decimals
  const recipient = DEFAULT_CONTRACT_ADDRESSES.UNIVERSAL_ROUTER; // recipient is the Router itself
  const simulationAccount = "0x6072A8C1c431D35643Ec5860626053e99e0373d5" as Address;

  console.log("\n--- On-chain simulation (eth_call: no transaction is sent, no signature) ---");
  console.log("SELL", amount.toString(), "bundle", bundleAddress);
  console.log("Simulation account:", simulationAccount);
  const simulationState: { lastInnerCalldata?: Hex } = {};
  try {
    await simulateOnChain(
      client,
      router,
      "sell",
      bundleAddress,
      amount,
      recipient,
      simulationAccount,
      simulationState
    );
  } catch (err: unknown) {
    if (simulationState.lastInnerCalldata) {
      console.error(`\nRouter inner calldata (calldata builder output):\n${simulationState.lastInnerCalldata}\n`);
    }
    const revertData = getRevertDataFromError(err);
    if (typeof revertData === "string" && revertData.startsWith("0x") && revertData.length > 10) {
      try {
        const decoded = decodeErrorResult({ abi: universalRouterAbi, data: revertData as Hex });
        console.error(
          "Simulation reverted:",
          decoded.errorName,
          decoded.args && decoded.args.length > 0 ? decoded.args : ""
        );
        if (
          decoded.errorName === "UniversalRouter__OperationFailed" &&
          decoded.args?.[0] !== undefined &&
          simulationState.lastInnerCalldata
        ) {
          const opIndex = Number(decoded.args[0]);
          const [targets, selectors, params] = decodeAbiParameters(
            parseAbiParameters("address[] targets, bytes4[] selectors, bytes[] params"),
            simulationState.lastInnerCalldata
          );
          if (opIndex >= 0 && opIndex < targets.length) {
            const p = params[opIndex];
            const paramBytes =
              typeof p === "string" ? (p.length - 2) / 2 : (p as unknown as Uint8Array).length;
            console.error(
              `Failing operation [${opIndex}]: target=${targets[opIndex]}, selector=${selectors[opIndex]}, params=${paramBytes} bytes`
            );
            if (paramBytes > 0) {
              console.error(
                "  (Params are present; tracer may show swapExactTokensForETH() with no args if it lacks the struct ABI.)"
              );
            }
          }
        }
      } catch {
        console.error("Simulation failed:", err);
      }
    } else {
      console.error("Simulation failed:", err);
    }
    throw err;
  }
}

// Entrypoint - can be run directly or imported from index.ts
// simulateBundleSellExample().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });
