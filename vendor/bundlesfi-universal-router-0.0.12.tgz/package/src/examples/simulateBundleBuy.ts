import {
  createPublicClient,
  http,
  decodeErrorResult,
  decodeAbiParameters,
  parseAbiParameters,
  toFunctionSelector,
} from "viem";
import type { Address, Hex } from "viem";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";
import { Router } from "../router/Router.js";
import { universalRouterAbi, indexAbi, bundleSwapRouterAbi } from "../contracts/abis.js";
import { simulateOnChain } from "../utils/simulation.js";
import { getRevertDataFromError } from "../utils/errorHelpers.js";
import { registerAdaptersForChain } from "../utils/routerHelpers.js";
import { mainnet } from "viem/chains";

const KNOWN_SELECTORS: Record<string, string> = {};
for (const entry of [...indexAbi, ...bundleSwapRouterAbi]) {
  if (entry.type === "function") {
    const sig = `${entry.name}(${entry.inputs.map((i: { type: string }) => i.type).join(",")})`;
    KNOWN_SELECTORS[toFunctionSelector(sig)] = `${entry.name}()`;
  }
}

/**
 * First test: simulate BUY 1000 units (18 decimals) of bundle 0xC5fB... on-chain.
 * Uses account 0x0a0F... (has enough ether). Run with: uncomment simulateBundleBuyExample below.
 * If you get "No successful quote from any route", try a smaller amount (e.g. 50n * 10n ** 18n) for this bundle.
 */
export async function simulateBundleBuyExample() {
  const client = createPublicClient({
    chain: mainnet,
    transport: http("https://mainnet.infura.io/v3/79cf00226caf4ac58a93ffd55e48c374"),
  });

  const router = new Router(client, DEFAULT_CONTRACT_ADDRESSES);
  registerAdaptersForChain(router, client, mainnet.id, DEFAULT_CONTRACT_ADDRESSES);

  const bundleAddress = "0xDC0500d4492fE15767A8b86157b308A225b68E31" as Address;
  const amount = 2000n * 10n ** 18n;
  const recipient = DEFAULT_CONTRACT_ADDRESSES.UNIVERSAL_ROUTER; // repicient is the Router itself
  const simulationAccount = "0x0a0F48d13cfFcB09DDCe184BEb9fbB23AC4b1e4d" as Address;

  console.log("\n--- On-chain simulation (eth_call: no transaction is sent, no signature) ---");
  console.log("BUY", amount.toString(), "bundle", bundleAddress);
  console.log("Simulation account:", simulationAccount);
  const simulationState: { lastInnerCalldata?: Hex } = {};
  try {
    await simulateOnChain(
      client,
      router,
      "buy",
      bundleAddress,
      amount,
      recipient,
      simulationAccount,
      simulationState
    );
  } catch (err: unknown) {
    if (simulationState.lastInnerCalldata) {
      console.error(`\nRouter inner calldata (calldata builder output):\n${simulationState.lastInnerCalldata}\n`);
    }
    const revertData = getRevertDataFromError(err);
    if (typeof revertData === "string" && revertData.startsWith("0x") && revertData.length > 10) {
      try {
        const decoded = decodeErrorResult({ abi: universalRouterAbi, data: revertData as Hex });
        console.error(
          "Simulation reverted:",
          decoded.errorName,
          decoded.args && decoded.args.length > 0 ? decoded.args : ""
        );
        if (
          decoded.errorName === "UniversalRouter__OperationFailed" &&
          decoded.args?.[0] !== undefined &&
          simulationState.lastInnerCalldata
        ) {
          const opIndex = Number(decoded.args[0]);
          const [targets, selectors, params] = decodeAbiParameters(
            parseAbiParameters("address[] targets, bytes4[] selectors, bytes[] params"),
            simulationState.lastInnerCalldata
          );
          if (opIndex >= 0 && opIndex < targets.length) {
            const p = params[opIndex];
            const paramBytes =
              typeof p === "string" ? (p.length - 2) / 2 : (p as unknown as Uint8Array).length;
            const sel = selectors[opIndex] as string;
            const fnName = KNOWN_SELECTORS[sel] ?? sel;
            console.error(
              `Failing operation [${opIndex}]: target=${targets[opIndex]}, fn=${fnName}, params=${paramBytes} bytes`
            );
          }
        }
      } catch {
        console.error("Simulation failed:", err);
      }
    } else {
      console.error("Simulation failed:", err);
    }
    throw err;
  }
}

// Entrypoint - can be run directly or imported from index.ts
// simulateBundleBuyExample().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });
