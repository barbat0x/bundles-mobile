import {
  createPublicClient,
  http,
  decodeErrorResult,
  decodeAbiParameters,
  parseAbiParameters,
  encodeFunctionData,
} from "viem";
import type { Address, Hex } from "viem";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";
import { universalRouterAbi, factoryErrorAbi } from "../contracts/abis.js";
import { getRevertDataFromError } from "../utils/errorHelpers.js";
import { quoteCreateIndex } from "../production/bundleActions.js";
import { mainnet } from "viem/chains";

/** Apply 99.5% to quoted minAmounts (0.5% slippage). Used only if not using zero minAmounts. */
const SIMULATION_SLIPPAGE_BPS = 995n;
const SIMULATION_SLIPPAGE_DENOM = 1000n;

/**
 * Simulate createIndex: quote create-index, then run eth_call with the returned
 * calldata and value to verify the transaction would succeed.
 *
 * Data shape (same as buy/sell): we must pass only the inner _data from the calldata
 * builder (result.calldata) as the _data argument to createIndex. The full transaction
 * is encodeFunctionData(createIndex, [..., result.calldata, deadline]) — we do NOT
 * pass the full createIndex-encoded bytes as _data.
 *
 * Simulation uses zero minAmounts (same as the Forge TestCreateIndexUniversalRouter script),
 * so the balance check always passes and we only verify swaps + Factory.createIndex.
 * For production the front-end should apply slippage to the quoted minAmounts.
 *
 * Uses a small set of tokens and ETH amounts. Uncomment the call at the bottom to run.
 */
export async function simulateCreateIndexExample() {
  const client = createPublicClient({
    chain: mainnet,
    transport: http("https://eth.api.pocket.network"),
  });

  const simulationAccount = "0x0a0F48d13cfFcB09DDCe184BEb9fbB23AC4b1e4d" as Address;

  // Example: protocol token first (required), then USDC, WETH. Protocol token weight must be >5%.
  const oneEth = 10n ** 18n;
  const tokens: Address[] = [
    DEFAULT_CONTRACT_ADDRESSES.BUNDLES_PROTOCOL_TOKEN_MAINNET, // BUN (protocol token, must be first)
    "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599" as Address, // WBTC
    "0x45804880De22913dAFE09f4980848ECE6EcbAf78" as Address, // PAX Gold
    "0x98C23E9d8f34FEFb1B7BD6a91B7FF122F4e16F5c" as Address, // aUSDC
    "0x9E2969Cb2Db5ED83E9b5983Ff9236eA39c4578f6" as Address,
    DEFAULT_CONTRACT_ADDRESSES.WETH,                           // WETH
  ];
  const ethAmounts = [
    oneEth / 10n, oneEth / 10n, oneEth / 10n,
    oneEth / 10n, oneEth / 10n, oneEth / 10n,
  ];

  const indexParams = {
    name: "Gipsy Crown",
    symbol: "GCR",
    swapFee: 222,
    mintAndBurnFee: 250,
    managerShareFee: 250,
  };

  // Denormalized weights: Factory expects total = 50 ether. Protocol token >5% (here 5% of 50 = 2.5).
  const weights = [
    (oneEth * 5n) / 2n,  // BUN: 5%
    oneEth * 10n,         // WBTC: 20%
    oneEth * 10n,         // PAX Gold: 20%
    oneEth * 5n,          // aUSDC: 10%
    (oneEth * 25n) / 2n,  // token5: 25%
    oneEth * 10n,         // WETH: 20%
  ]; // total = 50 ether
  const initialSupply = 100n;

  console.log("\n--- Create Index: quote then simulate (eth_call) ---");
  console.log("Tokens:", tokens);
  console.log("ETH amounts:", ethAmounts.map((a) => a.toString()));
  console.log("Simulation account:", simulationAccount);

  const result = await quoteCreateIndex(
    client,
    {
      tokens,
      ethAmounts,
      contractAddresses: DEFAULT_CONTRACT_ADDRESSES
    }
  );

  const totalEth = ethAmounts.reduce((a, b) => a + b, 0n);
  const deadline = BigInt(Math.floor(Date.now() / 1000) + 300);
  const userProvidedAmounts = tokens.map(() => 0n);
  // Use 99.5% of quoted minAmounts for slippage-tolerant simulation (avoids reverts when spot moves).
  const minAmountsForSimulation = result.minAmounts.map((m) => (m * SIMULATION_SLIPPAGE_BPS) / SIMULATION_SLIPPAGE_DENOM);

  // Pass only the inner _data (builder output) as _data — same pattern as swapETHForExactTokens / swapExactTokensForETH.
  const innerData = result.calldata;
  const simulationCalldata = encodeFunctionData({
    abi: universalRouterAbi,
    functionName: "createIndex",
    args: [
      indexParams,
      tokens,
      userProvidedAmounts,
      minAmountsForSimulation,
      weights,
      initialSupply,
      innerData,
      deadline,
    ],
  });

  console.log("Total ETH:", totalEth.toString());
  console.log("Min amounts (simulation, 99.5% of quoted):", minAmountsForSimulation.map((a) => a.toString()));
  console.log("Data length (bytes):", (innerData.length - 2) / 2);

  const simulationState: { lastInnerCalldata?: Hex } = { lastInnerCalldata: innerData };

  try {
    await client.call({
      to: DEFAULT_CONTRACT_ADDRESSES.UNIVERSAL_ROUTER,
      data: simulationCalldata,
      value: totalEth,
      account: simulationAccount,
    });
    console.log("Simulation succeeded.");
  } catch (err: unknown) {
    if (simulationState.lastInnerCalldata) {
      console.error(`\nRouter inner calldata (calldata builder output):\n${simulationState.lastInnerCalldata}\n`);
    }
    // viem often nests revert data at err.cause.cause.data (RpcRequestError)
    const revertData =
      getRevertDataFromError(err) ??
      (err as { cause?: { cause?: { data?: string } } })?.cause?.cause?.data;
    if (typeof revertData === "string" && revertData.startsWith("0x") && revertData.length >= 10) {
      console.error("Revert data (hex):", revertData.slice(0, 66) + (revertData.length > 66 ? "..." : ""));
      try {
        const decoded = decodeErrorResult({ abi: universalRouterAbi, data: revertData as Hex });
        console.error(
          "Simulation reverted:",
          decoded.errorName,
          decoded.args && decoded.args.length > 0 ? decoded.args : ""
        );
        if (
          decoded.errorName === "UniversalRouter__OperationFailed" &&
          decoded.args?.[0] !== undefined &&
          simulationState.lastInnerCalldata
        ) {
          const opIndex = Number(decoded.args[0]);
          const [targets, selectors, params] = decodeAbiParameters(
            parseAbiParameters("address[] targets, bytes4[] selectors, bytes[] params"),
            simulationState.lastInnerCalldata
          );
          if (opIndex >= 0 && opIndex < targets.length) {
            const p = params[opIndex];
            const paramBytes =
              typeof p === "string" ? (p.length - 2) / 2 : (p as unknown as Uint8Array).length;
            console.error(
              `Failing operation [${opIndex}]: target=${targets[opIndex]}, selector=${selectors[opIndex]}, params=${paramBytes} bytes`
            );
          }
        }
      } catch {
        try {
          const decoded = decodeErrorResult({ abi: factoryErrorAbi, data: revertData as Hex });
          console.error("Simulation reverted (Factory):", decoded.errorName, decoded.args ?? "");
        } catch {
          console.error("Simulation reverted (unknown selector). Revert data:", revertData.slice(0, 74));
        }
      }
    } else {
      console.error("Simulation failed (no revert data in error chain). Error:", err);
    }
    throw err;
  }
}

// Entrypoint - uncomment to run
// simulateCreateIndexExample().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });
