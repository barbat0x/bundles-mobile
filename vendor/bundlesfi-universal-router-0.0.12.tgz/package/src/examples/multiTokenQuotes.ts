import { createPublicClient, http } from "viem";
import type { Address } from "viem";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";
import { Router } from "../router/Router.js";
import { findBestRoute } from "../utils/routeHelpers.js";
import { registerAdaptersForChain } from "../utils/routerHelpers.js";
import { mainnet } from "viem/chains";

/**
 * Demo: find best exact-in routes for multiple tokens starting with 0.5 WETH each.
 * Tests WETH → Token paths and displays quotes from all DEXes.
 */
export async function main() {
  const client = createPublicClient({
    chain: mainnet,
    transport: http("https://eth.api.pocket.network"),
  });

  const router = new Router(client, DEFAULT_CONTRACT_ADDRESSES);
  registerAdaptersForChain(router, client, mainnet.id, DEFAULT_CONTRACT_ADDRESSES);

  // Target tokens to buy
  const tokens: Address[] = [
    "0xe202345c1a32A98F894f02D077Af98108376aDe3",
    "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", // USDC
    "0x695f775551fb0D28b64101c9507c06F334b4bA86",
  ];

  const amountIn = 5n * 10n ** 17n; // 0.5 WETH (18 decimals)
  const recipient = "0x1751F0eADFeB3d618B9e4176edDC9E7D24657c00";

  console.log("Testing routes for buying tokens with 0.5 WETH each");
  console.log("WETH address:", DEFAULT_CONTRACT_ADDRESSES.WETH);
  console.log("Amount per route:", amountIn.toString(), "(0.5 WETH)");

  // Test each token path
  for (const token of tokens) {
    const path: (Address | "ETH")[] = ["ETH", token];
    await findBestRoute(router, path, amountIn, recipient);
  }
}

// Entrypoint - run if this file is executed directly
// main().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });
