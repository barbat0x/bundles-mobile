import { createPublicClient, http } from "viem";
import type { Address } from "viem";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";
import { Router } from "../router/Router.js";
import { findBestRouteWithBundle } from "../utils/routeHelpers.js";
import { registerAdaptersForChain } from "../utils/routerHelpers.js";
import { mainnet } from "viem/chains";

/**
 * Test Bundle routes: compare direct swap vs mint/burn routes.
 */
export async function testBundleRoutes() {
  const client = createPublicClient({
    chain: mainnet,
    transport: http("https://eth.api.pocket.network"),
  });

  const router = new Router(client, DEFAULT_CONTRACT_ADDRESSES);
  registerAdaptersForChain(router, client, mainnet.id, DEFAULT_CONTRACT_ADDRESSES);

  const bundleAddress = "0xC5fB2F3820492C1d8058aa00d390542EE5109420" as Address;
  const recipient = "0x1751F0eADFeB3d618B9e4176edDC9E7D24657c00" as Address;

  console.log("\n" + "=".repeat(80));
  console.log("Testing Bundle routes");
  console.log("Bundle address:", bundleAddress);
  console.log("=".repeat(80));

  // Test 1: Sell 1000 Bundle tokens (18 decimals) for WETH
  console.log("\n>>> Test 1: Selling 1000 Bundle tokens for WETH");
  const sellAmount = 1000n * 10n ** 18n;
  await findBestRouteWithBundle(
    router,
    [bundleAddress, "ETH"],
    sellAmount,
    recipient,
    {
      isBundle: { token: bundleAddress, isBuying: false },
      printLogs: true,
    }
  );

  // Test 2: Buy 1000 Bundle tokens (18 decimals) with WETH (exact-out: desired Bundle amount)
  console.log("\n>>> Test 2: Buying 1000 Bundle tokens with WETH");
  const buyAmount = 1000n * 10n ** 18n;
  await findBestRouteWithBundle(
    router,
    ["ETH", bundleAddress],
    buyAmount,
    recipient,
    {
      isBundle: { token: bundleAddress, isBuying: false },
      printLogs: true,
    }
  );
}

// Entrypoint - run if this file is executed directly
// testBundleRoutes().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });
