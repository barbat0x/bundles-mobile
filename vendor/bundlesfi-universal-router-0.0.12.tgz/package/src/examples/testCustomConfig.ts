import { createPublicClient, http, type Address } from "viem";
import { mainnet } from "viem/chains";
import { Router } from "../router/Router.js";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";
import { registerAdaptersForChain } from "../utils/routerHelpers.js";

async function testCustomConfig() {
    console.log("Testing Custom Config Injection...");

    const customWeth: Address = "0xdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef";
    const customConfig = {
        ...DEFAULT_CONTRACT_ADDRESSES,
        WETH: customWeth,
    };

    const client = createPublicClient({
        chain: mainnet,
        transport: http("https://eth.api.pocket.network"),
    });

    console.log("Creating Router with custom config...");
    const router = new Router(client, customConfig);

    if (router.contractAddresses.WETH !== customWeth) {
        throw new Error(`Router config WETH mismatch! Expected ${customWeth}, got ${router.contractAddresses.WETH}`);
    }
    console.log("Router config WETH verified:", router.contractAddresses.WETH);

    console.log("Registering adapters with custom config...");
    // This will use the config passed to registerAdaptersForChain, ensuring adapters get it too
    // Note: We use chainId 1 (mainnet)
    registerAdaptersForChain(router, client, 1, customConfig);

    console.log("Custom config test passed!");
}

testCustomConfig().catch((err) => {
    console.error(err);
    process.exit(1);
});
