import {
  createPublicClient,
  http,
  decodeErrorResult,
  decodeAbiParameters,
  parseAbiParameters,
} from "viem";
import type { Address, Hex } from "viem";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";
import { Router } from "../router/Router.js";
import type { RouteHints } from "../router/types.js";
import { universalRouterAbi } from "../contracts/abis.js";
import { simulateOnChain } from "../utils/simulation.js";
import { getRevertDataFromError } from "../utils/errorHelpers.js";
import { registerAdaptersForChain } from "../utils/routerHelpers.js";
import { mainnet } from "viem/chains";

const EURC = "0x1aBaEA1f7C830bD89Acc67eC4af516284b1bC33c" as Address;
const USDC = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48" as Address;
const USDT = "0xdac17f958d2ee523a2206206994597c13d831ec7" as Address;

/**
 * Simulate BUY of bundle 0xf59a... with a route hint: for EURC, route through USDT
 * (WETH -> USDT -> EURC) instead of the direct (WETH -> EURC) which lacks liquidity.
 */
export async function simulateBundleBuyHintExample() {
  const client = createPublicClient({
    chain: mainnet,
    transport: http("https://eth.api.pocket.network"),
  });

  const router = new Router(client, DEFAULT_CONTRACT_ADDRESSES);
  registerAdaptersForChain(router, client, mainnet.id, DEFAULT_CONTRACT_ADDRESSES);

  const bundleAddress = "0xf59aBF583687d2a71b8471aF6F32558830dB0f30" as Address;
  const amount = 1000n * 10n ** 18n;
  const recipient = DEFAULT_CONTRACT_ADDRESSES.UNIVERSAL_ROUTER;
  const simulationAccount = "0x0a0F48d13cfFcB09DDCe184BEb9fbB23AC4b1e4d" as Address;

  const routeHints: RouteHints = new Map([
    [EURC, [USDC]],
  ]);

  console.log("\n--- On-chain simulation with route hints (eth_call) ---");
  console.log("BUY", amount.toString(), "bundle", bundleAddress);
  console.log("Route hint: EURC via USDT (WETH -> USDT -> EURC)");
  console.log("Simulation account:", simulationAccount);
  const simulationState: { lastInnerCalldata?: Hex } = {};
  try {
    await simulateOnChain(
      client,
      router,
      "buy",
      bundleAddress,
      amount,
      recipient,
      simulationAccount,
      simulationState,
      routeHints
    );
  } catch (err: unknown) {
    if (simulationState.lastInnerCalldata) {
      console.error(`\nRouter inner calldata (calldata builder output):\n${simulationState.lastInnerCalldata}\n`);
    }
    const revertData = getRevertDataFromError(err);
    if (typeof revertData === "string" && revertData.startsWith("0x") && revertData.length > 10) {
      try {
        const decoded = decodeErrorResult({ abi: universalRouterAbi, data: revertData as Hex });
        console.error(
          "Simulation reverted:",
          decoded.errorName,
          decoded.args && decoded.args.length > 0 ? decoded.args : ""
        );
        if (
          decoded.errorName === "UniversalRouter__OperationFailed" &&
          decoded.args?.[0] !== undefined &&
          simulationState.lastInnerCalldata
        ) {
          const opIndex = Number(decoded.args[0]);
          const [targets, selectors, params] = decodeAbiParameters(
            parseAbiParameters("address[] targets, bytes4[] selectors, bytes[] params"),
            simulationState.lastInnerCalldata
          );
          if (opIndex >= 0 && opIndex < targets.length) {
            const p = params[opIndex];
            const paramBytes =
              typeof p === "string" ? (p.length - 2) / 2 : (p as unknown as Uint8Array).length;
            console.error(
              `Failing operation [${opIndex}]: target=${targets[opIndex]}, selector=${selectors[opIndex]}, params=${paramBytes} bytes`
            );
            if (paramBytes > 0) {
              console.error(
                "  (Params are present; tracer may show swapTokensForExactTokens() with no args if it lacks the struct ABI.)"
              );
            }
          }
        }
      } catch {
        console.error("Simulation failed:", err);
      }
    } else {
      console.error("Simulation failed:", err);
    }
    throw err;
  }
}

// Entrypoint - can be run directly or imported from index.ts
// simulateBundleBuyExample().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });
