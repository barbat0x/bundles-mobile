import { createPublicClient, http, formatEther } from "viem";
import type { Address } from "viem";
import { mainnet } from "viem/chains";
import type { RouteHints } from "../router/types.js";
import { quoteBundles } from "../production/bundleActions.js";

const EURC = "0x1aBaEA1f7C830bD89Acc67eC4af516284b1bC33c" as Address;
const BOND_TOKEN = "0x418D75f65a02b3D53B2418FB8E1fe493759c7605" as Address;
const USDC = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48" as Address;
const USDT = "0xdac17f958d2ee523a2206206994597c13d831ec7" as Address;

export async function quoteBundlesExample() {
  const client = createPublicClient({
    chain: mainnet,
    transport: http("https://eth.api.pocket.network"),
  });

  const bundles: Address[] = [
    "0xf59aBF583687d2a71b8471aF6F32558830dB0f30",
  ];

  const routeHints: RouteHints = new Map([
    [EURC, [USDC]],
    [BOND_TOKEN, [USDC]],
    [USDC, [USDT]],
  ]);

  console.log("\n--- Bundle Quotation ---");
  console.log("Bundles to quote:", bundles);

  const results = await quoteBundles(client, bundles, { printLogs: true, routeHints });

  for (const r of results) {
    console.log(`\nBundle: ${r.bundleAddress}`);
    console.log(`  Total supply:       ${formatEther(r.totalSupply)} tokens`);
    console.log(`  Total supply value: ${formatEther(r.totalSupplyValueETH)} ETH`);
    console.log(`  Single token value: ${formatEther(r.singleTokenValueETH)} ETH`);
    console.log("  Token breakdown:");
    for (const t of r.tokenBreakdown) {
      console.log(`    ${t.token}: amount=${t.amount.toString()}, value=${formatEther(t.valueETH)} ETH`);
    }
  }
}

// Entrypoint - uncomment to run
// quoteBundlesExample().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });
