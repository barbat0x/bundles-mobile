import type { Address, PublicClient } from "viem";
import { decomposerAbi } from "../contracts/abis.js";

/**
 * TokenAmount represents a direct (non-index) token with its required amount and parent address.
 */
export interface TokenAmount {
  token: Address;
  amount: bigint;
  parentAddress: Address;
}

/**
 * IndexEntry represents a nested bundle/index token.
 */
export interface IndexEntry {
  index: Address;
  amount: bigint;
  parentAddress: Address;
}

/**
 * Decomposition structure returned by Decomposer contract.
 * Contains flattened arrays of all tokens and nested bundles.
 */
export interface Decomposition {
  tokens: TokenAmount[];
  indexes: IndexEntry[];
}

/**
 * One level of nested bundle decomposition: bundle address, amount, and aggregated tokens.
 * nesteds is empty for first-level nesting; extend for deeper trees later.
 */
export interface NestedDecomp {
  bundle: Address;
  amount: bigint;
  tokens: Map<Address, bigint>;
  nesteds: NestedDecomp[];
}

/**
 * Tree of decompositions for sell scenarios: root level-0 tokens and nested bundle decompositions.
 */
export interface SellTree {
  level0Tokens: Map<Address, bigint>;
  nesteds: NestedDecomp[];
}

/**
 * Build a sell tree from the root decomposition only.
 * The Decomposer returns a flattened token list with parentAddress for each amount,
 * so we can derive level-0 tokens (parent === root) and per-nested tokens (parent === nested)
 * without calling Decomposer again for each nested bundle.
 */
export function buildSellTree(
  rootDecomposition: Decomposition,
  rootBundleAddress: Address
): SellTree {
  const level0Tokens = new Map<Address, bigint>();
  const tokensByParent = new Map<Address, Map<Address, bigint>>();

  for (const t of rootDecomposition.tokens) {
    if (!tokensByParent.has(t.parentAddress)) {
      tokensByParent.set(t.parentAddress, new Map());
    }
    const map = tokensByParent.get(t.parentAddress)!;
    const existing = map.get(t.token) ?? 0n;
    map.set(t.token, existing + t.amount);
  }

  for (const [parent, tokenMap] of tokensByParent) {
    if (parent.toLowerCase() === rootBundleAddress.toLowerCase()) {
      for (const [token, amount] of tokenMap) {
        const existing = level0Tokens.get(token) ?? 0n;
        level0Tokens.set(token, existing + amount);
      }
    }
  }

  const nesteds: NestedDecomp[] = [];
  for (const indexEntry of rootDecomposition.indexes) {
    const tokens = tokensByParent.get(indexEntry.index) ?? new Map();
    nesteds.push({
      bundle: indexEntry.index,
      amount: indexEntry.amount,
      tokens: new Map(tokens),
      nesteds: [],
    });
  }

  return { level0Tokens, nesteds };
}

/**
 * Build a buy tree from the root decomposition only (same shape as sell).
 * Decomposer.buy returns a flattened token list with parentAddress; we derive
 * level-0 tokens (parent === root) and per-nested tokens (parent === nested).
 */
export function buildBuyTree(
  rootDecomposition: Decomposition,
  rootBundleAddress: Address
): SellTree {
  return buildSellTree(rootDecomposition, rootBundleAddress);
}

/**
 * Sort nested indexes for buy (mint): innermost first, so a bundle is only minted
 * after all bundles it depends on are available. Uses topological sort (child before parent).
 */
export function sortIndexesForBuy(
  indexes: readonly IndexEntry[],
  rootBundleAddress: Address
): IndexEntry[] {
  return topologicalSortIndexes(indexes, rootBundleAddress, false);
}

/**
 * Sort nested indexes for sell (burn): outermost first, so a bundle is burned
 * only after its parent has been burned. Uses topological sort (parent before child).
 */
export function sortIndexesForSell(
  indexes: readonly IndexEntry[],
  rootBundleAddress: Address
): IndexEntry[] {
  return topologicalSortIndexes(indexes, rootBundleAddress, true);
}

/**
 * Topological sort of index entries. Graph: each index has parentAddress (root or another index).
 * Edges: child -> parent (index.index -> index.parentAddress when parent is an index).
 * - For buy (reverse=false): output child before parent (innermost first).
 * - For sell (reverse=true): output parent before child (outermost first) = reverse of above.
 */
function topologicalSortIndexes(
  indexes: readonly IndexEntry[],
  rootBundleAddress: Address,
  reverse: boolean
): IndexEntry[] {
  const rootLower = rootBundleAddress.toLowerCase();
  const indexSet = new Set(indexes.map((i) => i.index.toLowerCase()));
  const indexByLower = new Map<string, IndexEntry>();
  for (const i of indexes) {
    indexByLower.set(i.index.toLowerCase(), i);
  }

  const outDegree = new Map<string, Set<string>>();
  const inDegree = new Map<string, Set<string>>();
  for (const i of indexes) {
    const node = i.index.toLowerCase();
    if (!outDegree.has(node)) outDegree.set(node, new Set());
    if (!inDegree.has(node)) inDegree.set(node, new Set());
  }
  for (const i of indexes) {
    const child = i.index.toLowerCase();
    const parent = i.parentAddress.toLowerCase();
    if (parent !== rootLower && indexSet.has(parent)) {
      outDegree.get(child)!.add(parent);
      inDegree.get(parent)!.add(child);
    }
  }

  const order: string[] = [];
  const queue: string[] = [];
  for (const node of indexSet) {
    if (inDegree.get(node)!.size === 0) queue.push(node);
  }
  while (queue.length > 0) {
    const node = queue.shift()!;
    order.push(node);
    for (const next of outDegree.get(node)!) {
      const nextIn = inDegree.get(next)!;
      nextIn.delete(node);
      if (nextIn.size === 0) queue.push(next);
    }
  }

  if (order.length !== indexes.length) {
    return [...indexes];
  }

  const orderedEntries = order.map((node) => indexByLower.get(node)!);
  return reverse ? orderedEntries.reverse() : orderedEntries;
}

/**
 * Decompose Bundle for buying: calculates exact amounts of all underlying tokens needed
 * to purchase a specific amount of Bundle tokens, including nested bundles.
 * Uses Decomposer contract which handles fee calculations and recursive decomposition.
 */
export async function decomposeBundleBuy(
  client: PublicClient,
  decomposerAddress: Address,
  bundleAddress: Address,
  amount: bigint
): Promise<Decomposition> {
  const result = await client.readContract({
    address: decomposerAddress,
    abi: decomposerAbi,
    functionName: "buy",
    args: [amount, bundleAddress],
  });

  // Convert the result to our TypeScript types
  const decomposition = result as {
    tokens: readonly { token: Address; amount: bigint; parentAddress: Address }[];
    indexes: readonly { index: Address; amount: bigint; parentAddress: Address }[];
  };

  return {
    tokens: decomposition.tokens.map((t) => ({
      token: t.token,
      amount: t.amount,
      parentAddress: t.parentAddress,
    })),
    indexes: decomposition.indexes.map((i) => ({
      index: i.index,
      amount: i.amount,
      parentAddress: i.parentAddress,
    })),
  };
}

/**
 * Decompose Bundle for selling: calculates exact amounts of all underlying tokens received
 * when selling/burning a specific amount of Bundle tokens, including nested bundles.
 * Uses Decomposer contract which handles fee calculations and recursive decomposition.
 */
export async function decomposeBundleSell(
  client: PublicClient,
  decomposerAddress: Address,
  bundleAddress: Address,
  amount: bigint
): Promise<Decomposition> {
  const result = await client.readContract({
    address: decomposerAddress,
    abi: decomposerAbi,
    functionName: "sell",
    args: [amount, bundleAddress],
  });

  // Convert the result to our TypeScript types
  const decomposition = result as {
    tokens: readonly { token: Address; amount: bigint; parentAddress: Address }[];
    indexes: readonly { index: Address; amount: bigint; parentAddress: Address }[];
  };

  return {
    tokens: decomposition.tokens.map((t) => ({
      token: t.token,
      amount: t.amount,
      parentAddress: t.parentAddress,
    })),
    indexes: decomposition.indexes.map((i) => ({
      index: i.index,
      amount: i.amount,
      parentAddress: i.parentAddress,
    })),
  };
}
