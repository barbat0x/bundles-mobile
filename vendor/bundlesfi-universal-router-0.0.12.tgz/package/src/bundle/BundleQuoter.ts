import type { Address, PublicClient } from "viem";
import type { ContractAddresses } from "../config/addresses.js";
import type { DexAdapter, MulticallContract } from "../adapters/DexAdapter.js";
import { decomposerAbi, erc20Abi, aaveProtocolDataProviderAbi } from "../contracts/abis.js";
import { buildATokenMaps } from "../adapters/AaveV3Adapter.js";
import { getApplicableAdaptersForExactIn } from "../router/helpers/adapterFilters.js";
import { parseQuoteExactInResult } from "../router/helpers/quoteParsers.js";
import { buildQuotingPaths } from "../router/path.js";
import type { RouteHints } from "../router/types.js";
import type { BundleQuoteResult, TokenValuation } from "../production/bundleActions.js";

interface DecompositionEntry { token: Address; amount: bigint }
interface BundleDecomposition {
  bundleAddress: Address;
  totalSupply: bigint;
  tokens: DecompositionEntry[];
}

/** Tracks which token index and adapter produced each multicall contract entry. */
interface QuoteSlot {
  tokenIndex: number;
  adapter: DexAdapter;
  contract: MulticallContract;
}

/** Precision multiplier for intermediate bigint arithmetic (avoids truncation). */
const PRICE_PRECISION = 10n ** 36n;

/**
 * Build deduplicated quoting paths for a resolved token, trying hint lookup for
 * every original decomposition address that maps to it (handles aToken hint keys).
 */
function collectHintedPaths(
  from: Address,
  to: Address,
  resolvedToOriginals: Map<string, Set<string>>,
  routeHints?: RouteHints
): Address[][] {
  const resolvedKey = (from === to ? to : (from.length > to.length ? from : to)).toLowerCase();
  const nonWethToken = from.toLowerCase() !== to.toLowerCase()
    ? (resolvedToOriginals.has(from.toLowerCase()) ? from : to)
    : to;
  const originals = resolvedToOriginals.get(nonWethToken.toLowerCase());
  const hintKeys = originals ? [...originals] : [nonWethToken.toLowerCase()];

  const seen = new Set<string>();
  const result: Address[][] = [];
  for (const hk of hintKeys) {
    const paths = buildQuotingPaths(from, to, routeHints, hk as Address);
    for (const p of paths) {
      const pathKey = p.map((a) => a.toLowerCase()).join("-");
      if (!seen.has(pathKey)) {
        seen.add(pathKey);
        result.push(p);
      }
    }
  }
  return result;
}

/**
 * Core pricing logic for bundle quotation.
 *
 * Strategy: quote a meaningful amount (0.5 ETH) so that only liquid, arbed
 * pools can compete. Take the best (cheapest buy, richest sell) and average
 * for a mid-market price. Illiquid pools either revert or show heavy slippage,
 * losing to liquid pools. If there is only one illiquid pool, the buy/sell
 * average still dampens the error.
 *
 *   RPC 1 – Decomposer.holdings() for every bundle + Aave aToken mapping.
 *   RPC 2 – Buy quotes (ETH → token) across all adapters + decimals.
 *   RPC 3 – Sell quotes (token → ETH) using best buy amountOut, all adapters.
 *
 * @param client - viem PublicClient connected to the target chain
 * @param bundleAddresses - One or more bundle addresses to quote
 * @param contractAddresses - Contract addresses for the target chain
 * @param adapters - Registered DEX adapters to use for quoting
 * @param printLogs - Whether to print detailed logs
 * @param routeHints - Optional multi-hop route hints (same format as Router)
 * @returns One BundleQuoteResult per bundle address
 */
export async function computeBundleQuotes(
  client: PublicClient,
  bundleAddresses: Address[],
  contractAddresses: ContractAddresses,
  adapters: DexAdapter[],
  printLogs: boolean,
  routeHints?: RouteHints
): Promise<BundleQuoteResult[]> {
  const WETH = contractAddresses.WETH;
  const ETH_QUOTE_AMOUNT = 5n * 10n ** 17n; // 0.5 ETH – large enough that illiquid pools fail or show heavy slippage

  // ── RPC 1: holdings + Aave aToken mapping (parallel, batched) ────────
  // Deduplicate bundles and chunk holdings() calls to stay within gas limits.
  const HOLDINGS_BATCH_SIZE = 2;
  const seen = new Set<string>();
  const uniqueBundleAddrs: Address[] = [];
  for (const addr of bundleAddresses) {
    const key = addr.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      uniqueBundleAddrs.push(addr);
    }
  }

  const holdingsBatches: { address: Address; abi: typeof decomposerAbi; functionName: "holdings"; args: readonly [Address] }[][] = [];
  for (let i = 0; i < uniqueBundleAddrs.length; i += HOLDINGS_BATCH_SIZE) {
    holdingsBatches.push(
      uniqueBundleAddrs.slice(i, i + HOLDINGS_BATCH_SIZE).map((addr) => ({
        address: contractAddresses.DECOMPOSER_MAINNET as Address,
        abi: decomposerAbi,
        functionName: "holdings" as const,
        args: [addr] as const,
      }))
    );
  }

  const aaveContracts = [
    {
      address: contractAddresses.AAVE_V3_PROTOCOL_DATA_PROVIDER,
      abi: aaveProtocolDataProviderAbi,
      functionName: "getAllReservesTokens" as const,
    },
    {
      address: contractAddresses.AAVE_V3_PROTOCOL_DATA_PROVIDER,
      abi: aaveProtocolDataProviderAbi,
      functionName: "getAllATokens" as const,
    },
  ] as const;

  const [aaveResults, ...holdingsBatchResults] = await Promise.all([
    client.multicall({
      contracts: aaveContracts as Parameters<PublicClient["multicall"]>[0]["contracts"],
      allowFailure: true,
    }),
    ...holdingsBatches.map((batch) =>
      client.multicall({
        contracts: batch as Parameters<PublicClient["multicall"]>[0]["contracts"],
        allowFailure: true,
      })
    ),
  ]);

  // Build holdings lookup map: lowercase address → multicall result
  const holdingsMap = new Map<string, (typeof holdingsBatchResults)[0][0]>();
  let flatIdx = 0;
  for (const batchResult of holdingsBatchResults) {
    for (const res of batchResult) {
      holdingsMap.set(uniqueBundleAddrs[flatIdx]!.toLowerCase(), res);
      flatIdx++;
    }
  }

  // Parse Aave aToken mapping
  const reservesRes = aaveResults[0]!;
  const aTokensRes = aaveResults[1]!;
  let aTokenToUnderlying = new Map<string, Address>();
  if (reservesRes.status === "success" && aTokensRes.status === "success") {
    const reserves = reservesRes.result as readonly { symbol: string; tokenAddress: Address }[];
    const aTokens = aTokensRes.result as readonly { symbol: string; tokenAddress: Address }[];
    ({ aTokenToUnderlying } = buildATokenMaps(reserves, aTokens));
  }

  // Parse decompositions and collect unique leaf tokens.
  // Track original→resolved mapping so hints keyed by aToken addresses work.
  const bundles: BundleDecomposition[] = [];
  const uniqueTokens = new Set<string>();
  const resolvedToOriginals = new Map<string, Set<string>>();

  for (let i = 0; i < bundleAddresses.length; i++) {
    const res = holdingsMap.get(bundleAddresses[i]!.toLowerCase())!;
    if (res.status !== "success") {
      throw new Error(`holdings() failed for bundle ${bundleAddresses[i]}: ${String(res.error)}`);
    }
    const [decomposition, totalSupply] = res.result as [
      { tokens: readonly { token: Address; amount: bigint; parentAddress: Address }[]; indexes: readonly unknown[] },
      bigint,
    ];
    const tokens: DecompositionEntry[] = [];
    for (const t of decomposition.tokens) {
      tokens.push({ token: t.token, amount: t.amount });
      const underlying = aTokenToUnderlying.get(t.token.toLowerCase());
      const resolved = underlying ? underlying.toLowerCase() : t.token.toLowerCase();
      uniqueTokens.add(resolved);
      if (!resolvedToOriginals.has(resolved)) resolvedToOriginals.set(resolved, new Set());
      resolvedToOriginals.get(resolved)!.add(t.token.toLowerCase());
    }
    bundles.push({ bundleAddress: bundleAddresses[i]!, totalSupply, tokens });
  }

  // WETH price in ETH is trivially 1:1
  uniqueTokens.delete(WETH.toLowerCase());

  const tokenList: Address[] = [...uniqueTokens].map((t) => t as Address);

  if (printLogs) {
    console.log(`[quoteBundles] ${bundles.length} bundle(s), ${tokenList.length} unique leaf token(s) to quote`);
    if (aTokenToUnderlying.size > 0) {
      console.log(`  Aave aToken mapping loaded (${aTokenToUnderlying.size} entries)`);
    }
  }

  // ── RPC 2: Buy quotes (all adapters, with route hints) + decimals ───
  const buySlots: QuoteSlot[] = [];
  for (let ti = 0; ti < tokenList.length; ti++) {
    const token = tokenList[ti]!;
    const allPaths = collectHintedPaths(WETH, token, resolvedToOriginals, routeHints);
    for (const path of allPaths) {
      const applicable = getApplicableAdaptersForExactIn(adapters, path, WETH);
      for (const adapter of applicable) {
        const contract = adapter.getQuoteExactInContract(path, ETH_QUOTE_AMOUNT);
        buySlots.push({ tokenIndex: ti, adapter, contract });
      }
    }
  }

  const decimalContracts = tokenList.map((token) => ({
    address: token,
    abi: erc20Abi,
    functionName: "decimals" as const,
    args: [] as const,
  }));

  const rpc2Contracts = [
    ...buySlots.map((s) => s.contract),
    ...decimalContracts,
  ];

  const rpc2Results = await client.multicall({
    contracts: rpc2Contracts as Parameters<PublicClient["multicall"]>[0]["contracts"],
    allowFailure: true,
  });

  const buyResultsRaw = rpc2Results.slice(0, buySlots.length);
  const decimalResultsRaw = rpc2Results.slice(buySlots.length);

  // Best buy = most tokens per ETH (cheapest source, i.e. most liquid arbed pool).
  const tokenBuyAmountOut = new Map<string, bigint>();
  const tokenDecimals = new Map<string, number>();

  tokenDecimals.set(WETH.toLowerCase(), 18);

  for (let i = 0; i < buySlots.length; i++) {
    const slot = buySlots[i]!;
    const key = tokenList[slot.tokenIndex]!.toLowerCase();
    const res = buyResultsRaw[i]!;
    if (res.status === "success" && res.result !== undefined) {
      const amountOut = parseQuoteExactInResult(slot.adapter, res.result, slot.contract);
      if (amountOut !== undefined && amountOut > 0n) {
        const current = tokenBuyAmountOut.get(key);
        if (current === undefined || amountOut > current) {
          tokenBuyAmountOut.set(key, amountOut);
          if (printLogs) {
            console.log(`  [buy] ${key} via ${slot.adapter.name}: ${amountOut}${current !== undefined ? " (new best)" : ""}`);
          }
        }
      }
    }
  }

  for (let i = 0; i < tokenList.length; i++) {
    const key = tokenList[i]!.toLowerCase();
    const decRes = decimalResultsRaw[i]!;
    if (decRes.status === "success") {
      tokenDecimals.set(key, Number(decRes.result));
    } else {
      tokenDecimals.set(key, 18);
    }
  }

  // ── RPC 3: Sell quotes (all adapters) ───────────────────────────────
  // Sell the best buy amountOut back. Best sell = most ETH received (most liquid pool).
  const sellTokens: Address[] = [];
  const sellAmounts: bigint[] = [];
  for (const token of tokenList) {
    const key = token.toLowerCase();
    const buyOut = tokenBuyAmountOut.get(key);
    if (buyOut !== undefined && buyOut > 0n) {
      sellTokens.push(token);
      sellAmounts.push(buyOut);
    }
  }

  const sellSlots: QuoteSlot[] = [];
  for (let si = 0; si < sellTokens.length; si++) {
    const token = sellTokens[si]!;
    const amount = sellAmounts[si]!;
    const allPaths = collectHintedPaths(token, WETH, resolvedToOriginals, routeHints);
    for (const path of allPaths) {
      const applicable = getApplicableAdaptersForExactIn(adapters, path, WETH);
      for (const adapter of applicable) {
        const contract = adapter.getQuoteExactInContract(path, amount);
        sellSlots.push({ tokenIndex: si, adapter, contract });
      }
    }
  }

  const rpc3Results = await client.multicall({
    contracts: sellSlots.map((s) => s.contract) as Parameters<PublicClient["multicall"]>[0]["contracts"],
    allowFailure: true,
  });

  // Best sell = most ETH back (most liquid arbed pool).
  const tokenSellEthReceived = new Map<string, bigint>();

  for (let i = 0; i < sellSlots.length; i++) {
    const slot = sellSlots[i]!;
    const key = sellTokens[slot.tokenIndex]!.toLowerCase();
    const res = rpc3Results[i]!;
    if (res.status === "success" && res.result !== undefined) {
      const ethOut = parseQuoteExactInResult(slot.adapter, res.result, slot.contract);
      if (ethOut !== undefined && ethOut > 0n) {
        const current = tokenSellEthReceived.get(key);
        if (current === undefined || ethOut > current) {
          tokenSellEthReceived.set(key, ethOut);
          if (printLogs) {
            console.log(`  [sell] ${key} via ${slot.adapter.name}: ${ethOut}${current !== undefined ? " (new best)" : ""}`);
          }
        }
      }
    }
  }

  // ── Compute average price per token (scaled by PRICE_PRECISION) ─────
  // buyPrice  = ETH_QUOTE / bestBuyAmountOut  (how much ETH per token to buy)
  // sellPrice = bestSellEth / bestBuyAmountOut (how much ETH per token when selling)
  // Average of the two gives mid-market price, cancelling spread.
  const tokenAvgPrice = new Map<string, bigint>();

  tokenAvgPrice.set(WETH.toLowerCase(), PRICE_PRECISION);

  for (const token of sellTokens) {
    const key = token.toLowerCase();
    const buyAmountOut = tokenBuyAmountOut.get(key)!;
    const buyPrice = (ETH_QUOTE_AMOUNT * PRICE_PRECISION) / buyAmountOut;

    const ethReceived = tokenSellEthReceived.get(key);
    if (ethReceived !== undefined && ethReceived > 0n) {
      const sellPrice = (ethReceived * PRICE_PRECISION) / buyAmountOut;
      tokenAvgPrice.set(key, (buyPrice + sellPrice) / 2n);
    } else {
      tokenAvgPrice.set(key, buyPrice);
    }
  }

  // ── Assemble results per bundle ─────────────────────────────────────
  const results: BundleQuoteResult[] = [];

  for (const bundle of bundles) {
    let totalValueScaled = 0n;
    const breakdown: TokenValuation[] = [];

    for (const { token, amount } of bundle.tokens) {
      const underlying = aTokenToUnderlying.get(token.toLowerCase());
      const priceKey = underlying ? underlying.toLowerCase() : token.toLowerCase();
      const price = tokenAvgPrice.get(priceKey);
      let valueETH = 0n;
      if (price !== undefined && price > 0n) {
        valueETH = (amount * price) / PRICE_PRECISION;
      }
      totalValueScaled += valueETH;
      breakdown.push({ token, amount, valueETH });
    }

    const totalSupplyValueETH = totalValueScaled;
    const singleTokenValueETH =
      bundle.totalSupply > 0n
        ? (totalSupplyValueETH * 10n ** 18n) / bundle.totalSupply
        : 0n;

    results.push({
      bundleAddress: bundle.bundleAddress,
      totalSupply: bundle.totalSupply,
      totalSupplyValueETH,
      singleTokenValueETH,
      tokenBreakdown: breakdown,
    });

    if (printLogs) {
      console.log(`\n[quoteBundles] Bundle ${bundle.bundleAddress}`);
      console.log(`  Total supply: ${bundle.totalSupply}`);
      console.log(`  Total supply value: ${totalSupplyValueETH} wei (${Number(totalSupplyValueETH) / 1e18} ETH)`);
      console.log(`  Single token value: ${singleTokenValueETH} wei (${Number(singleTokenValueETH) / 1e18} ETH)`);
      for (const b of breakdown) {
        const isAToken = aTokenToUnderlying.has(b.token.toLowerCase());
        const suffix = isAToken ? ` (aToken → ${aTokenToUnderlying.get(b.token.toLowerCase())})` : "";
        console.log(`    ${b.token}: amount=${b.amount}, valueETH=${b.valueETH} wei${suffix}`);
      }
    }
  }

  return results;
}
