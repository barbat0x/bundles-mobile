import type { Abi } from "viem";

/** ERC20: approve, allowance, balanceOf */
export const erc20Abi = [
  {
    name: "approve",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "spender", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [{ type: "bool" }],
  },
  {
    name: "allowance",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "owner", type: "address" },
      { name: "spender", type: "address" },
    ],
    outputs: [{ type: "uint256" }],
  },
  {
    name: "balanceOf",
    type: "function",
    stateMutability: "view",
    inputs: [{ name: "account", type: "address" }],
    outputs: [{ type: "uint256" }],
  },
  {
    name: "decimals",
    type: "function",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "uint8" }],
  },
] as const satisfies Abi;

/** Uniswap V2 Router: getAmountsOut, getAmountsIn, swapExactTokensForTokens, swapTokensForExactTokens */
export const uniswapV2RouterAbi = [
  {
    name: "getAmountsOut",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "amountIn", type: "uint256" },
      { name: "path", type: "address[]" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "getAmountsIn",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "amountOut", type: "uint256" },
      { name: "path", type: "address[]" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapExactTokensForTokens",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "amountIn", type: "uint256" },
      { name: "amountOutMin", type: "uint256" },
      { name: "path", type: "address[]" },
      { name: "to", type: "address" },
      { name: "deadline", type: "uint256" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapTokensForExactTokens",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "amountOut", type: "uint256" },
      { name: "amountInMax", type: "uint256" },
      { name: "path", type: "address[]" },
      { name: "to", type: "address" },
      { name: "deadline", type: "uint256" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
] as const satisfies Abi;

/** Uniswap V3 Quoter: flat params (no struct) for quoteExactInputSingle / quoteExactOutputSingle */
export const uniswapV3QuoterAbi = [
  {
    name: "quoteExactInputSingle",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "tokenIn", type: "address" },
      { name: "tokenOut", type: "address" },
      { name: "fee", type: "uint24" },
      { name: "amountIn", type: "uint256" },
      { name: "sqrtPriceLimitX96", type: "uint160" },
    ],
    outputs: [{ name: "amountOut", type: "uint256" }],
  },
  {
    name: "quoteExactOutputSingle",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "tokenIn", type: "address" },
      { name: "tokenOut", type: "address" },
      { name: "fee", type: "uint24" },
      { name: "amountOut", type: "uint256" },
      { name: "sqrtPriceLimitX96", type: "uint160" },
    ],
    outputs: [{ name: "amountIn", type: "uint256" }],
  },
  {
    name: "quoteExactInput",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "path", type: "bytes" },
      { name: "amountIn", type: "uint256" },
    ],
    outputs: [{ name: "amountOut", type: "uint256" }],
  },
  {
    name: "quoteExactOutput",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "path", type: "bytes" },
      { name: "amountOut", type: "uint256" },
    ],
    outputs: [{ name: "amountIn", type: "uint256" }],
  },
] as const satisfies Abi;

/** Uniswap V3 SwapRouter: single-hop and multi-hop swap functions */
export const uniswapV3RouterAbi = [
  {
    name: "exactInputSingle",
    type: "function",
    stateMutability: "payable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "tokenIn", type: "address" },
          { name: "tokenOut", type: "address" },
          { name: "fee", type: "uint24" },
          { name: "recipient", type: "address" },
          { name: "deadline", type: "uint256" },
          { name: "amountIn", type: "uint256" },
          { name: "amountOutMinimum", type: "uint256" },
          { name: "sqrtPriceLimitX96", type: "uint160" },
        ],
      },
    ],
    outputs: [{ name: "amountOut", type: "uint256" }],
  },
  {
    name: "exactOutputSingle",
    type: "function",
    stateMutability: "payable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "tokenIn", type: "address" },
          { name: "tokenOut", type: "address" },
          { name: "fee", type: "uint24" },
          { name: "recipient", type: "address" },
          { name: "deadline", type: "uint256" },
          { name: "amountOut", type: "uint256" },
          { name: "amountInMaximum", type: "uint256" },
          { name: "sqrtPriceLimitX96", type: "uint160" },
        ],
      },
    ],
    outputs: [{ name: "amountIn", type: "uint256" }],
  },
  {
    name: "exactInput",
    type: "function",
    stateMutability: "payable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "path", type: "bytes" },
          { name: "recipient", type: "address" },
          { name: "deadline", type: "uint256" },
          { name: "amountIn", type: "uint256" },
          { name: "amountOutMinimum", type: "uint256" },
        ],
      },
    ],
    outputs: [{ name: "amountOut", type: "uint256" }],
  },
  {
    name: "exactOutput",
    type: "function",
    stateMutability: "payable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "path", type: "bytes" },
          { name: "recipient", type: "address" },
          { name: "deadline", type: "uint256" },
          { name: "amountOut", type: "uint256" },
          { name: "amountInMaximum", type: "uint256" },
        ],
      },
    ],
    outputs: [{ name: "amountIn", type: "uint256" }],
  },
] as const satisfies Abi;

/** BundleSwap Router: struct-based swaps with protocol token support */
export const bundleSwapRouterAbi = [
  {
    name: "getAmountsOut",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "amountIn", type: "uint256" },
      { name: "path", type: "address[]" },
      { name: "fees", type: "uint16[]" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "getAmountsIn",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "amountOut", type: "uint256" },
      { name: "path", type: "address[]" },
      { name: "fees", type: "uint16[]" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapExactETHForTokens",
    type: "function",
    stateMutability: "payable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "amountOutMin", type: "uint256" },
          { name: "maxFee", type: "uint256" },
          { name: "path", type: "address[]" },
          { name: "fees", type: "uint16[]" },
          { name: "to", type: "address" },
          { name: "deadline", type: "uint256" },
        ],
      },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapExactTokensForETH",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "amountIn", type: "uint256" },
          { name: "amountOutMin", type: "uint256" },
          { name: "maxFee", type: "uint256" },
          { name: "path", type: "address[]" },
          { name: "fees", type: "uint16[]" },
          { name: "to", type: "address" },
          { name: "deadline", type: "uint256" },
        ],
      },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapExactTokensForTokens",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "amountIn", type: "uint256" },
          { name: "amountOutMin", type: "uint256" },
          { name: "maxFee", type: "uint256" },
          { name: "path", type: "address[]" },
          { name: "fees", type: "uint16[]" },
          { name: "to", type: "address" },
          { name: "deadline", type: "uint256" },
        ],
      },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapETHForExactTokens",
    type: "function",
    stateMutability: "payable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "amountOut", type: "uint256" },
          { name: "maxFee", type: "uint256" },
          { name: "path", type: "address[]" },
          { name: "fees", type: "uint16[]" },
          { name: "to", type: "address" },
          { name: "deadline", type: "uint256" },
        ],
      },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapTokensForExactETH",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "amountOut", type: "uint256" },
          { name: "amountInMax", type: "uint256" },
          { name: "maxFee", type: "uint256" },
          { name: "path", type: "address[]" },
          { name: "fees", type: "uint16[]" },
          { name: "to", type: "address" },
          { name: "deadline", type: "uint256" },
        ],
      },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapTokensForExactTokens",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "amountOut", type: "uint256" },
          { name: "amountInMax", type: "uint256" },
          { name: "maxFee", type: "uint256" },
          { name: "path", type: "address[]" },
          { name: "fees", type: "uint16[]" },
          { name: "to", type: "address" },
          { name: "deadline", type: "uint256" },
        ],
      },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
] as const satisfies Abi;

/** Antfarm Router: same struct signatures as BundleSwap */
export const antfarmRouterAbi = bundleSwapRouterAbi;

/** Bundles Router (IBundlesRouter): flat swap functions for 2-token paths */
export const bundlesRouterAbi = [
  {
    name: "swapExactETHForTokens",
    type: "function",
    stateMutability: "payable",
    inputs: [
      { name: "_output", type: "address" },
      { name: "_fee", type: "uint16" },
      { name: "_to", type: "address" },
      { name: "_deadline", type: "uint256" },
      { name: "_amountOutMin", type: "uint256" },
    ],
    outputs: [{ name: "_amountOut", type: "uint256" }],
  },
  {
    name: "swapExactTokensForETH",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "_input", type: "address" },
      { name: "_fee", type: "uint16" },
      { name: "_to", type: "address" },
      { name: "_deadline", type: "uint256" },
      { name: "_amountIn", type: "uint256" },
      { name: "_amountOutMin", type: "uint256" },
    ],
    outputs: [{ name: "_amountOut", type: "uint256" }],
  },
  {
    name: "swapETHForExactTokens",
    type: "function",
    stateMutability: "payable",
    inputs: [
      { name: "_output", type: "address" },
      { name: "_fee", type: "uint16" },
      { name: "_to", type: "address" },
      { name: "_deadline", type: "uint256" },
      { name: "_amountOut", type: "uint256" },
    ],
    outputs: [{ name: "_amountIn", type: "uint256" }],
  },
  {
    name: "swapExactWETHForTokens",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "_amountIn", type: "uint256" },
      { name: "_output", type: "address" },
      { name: "_fee", type: "uint16" },
      { name: "_to", type: "address" },
      { name: "_deadline", type: "uint256" },
      { name: "_amountOutMin", type: "uint256" },
    ],
    outputs: [{ name: "_amountOut", type: "uint256" }],
  },
  {
    name: "swapExactTokensForWETH",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "_input", type: "address" },
      { name: "_fee", type: "uint16" },
      { name: "_to", type: "address" },
      { name: "_deadline", type: "uint256" },
      { name: "_amountIn", type: "uint256" },
      { name: "_amountOutMin", type: "uint256" },
    ],
    outputs: [{ name: "_amountOut", type: "uint256" }],
  },
  {
    name: "swapWETHForExactTokens",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "_amountInMax", type: "uint256" },
      { name: "_output", type: "address" },
      { name: "_fee", type: "uint16" },
      { name: "_to", type: "address" },
      { name: "_deadline", type: "uint256" },
      { name: "_amountOut", type: "uint256" },
    ],
    outputs: [{ name: "_amountIn", type: "uint256" }],
  },
  {
    name: "estimateExactETHForTokens",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "_output", type: "address" },
      { name: "_fee", type: "uint16" },
      { name: "_amountIn", type: "uint256" },
    ],
    outputs: [{ name: "estimatedOut", type: "uint256" }],
  },
  {
    name: "estimateExactTokensForETH",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "_input", type: "address" },
      { name: "_fee", type: "uint16" },
      { name: "_amountIn", type: "uint256" },
    ],
    outputs: [{ name: "estimatedOut", type: "uint256" }],
  },
  {
    name: "estimateETHForExactTokens",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "_output", type: "address" },
      { name: "_fee", type: "uint16" },
      { name: "_amountOut", type: "uint256" },
    ],
    outputs: [{ name: "estimatedIn", type: "uint256" }],
  },
] as const satisfies Abi;

/** Index Contract (IIndex): Bundle token mint/burn interface */
export const indexAbi = [
  {
    name: "getTokens",
    type: "function",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "_tokens", type: "address[]" }],
  },
  {
    name: "getBalance",
    type: "function",
    stateMutability: "view",
    inputs: [{ name: "token", type: "address" }],
    outputs: [{ name: "balance", type: "uint256" }],
  },
  {
    name: "mintAndBurnFee",
    type: "function",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint8" }],
  },
  {
    name: "mint",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "amount", type: "uint256" },
      { name: "maxAmountsIn", type: "uint256[]" },
      { name: "to", type: "address" },
    ],
    outputs: [],
  },
  {
    name: "burn",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "amount", type: "uint256" },
      { name: "minAmountsOut", type: "uint256[]" },
      { name: "to", type: "address" },
    ],
    outputs: [],
  },
] as const satisfies Abi;

/** Decomposer Contract: Decomposes Index/Bundle tokens into underlying assets */
export const decomposerAbi = [
  {
    name: "buy",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "_amount", type: "uint256" },
      { name: "_index", type: "address" },
    ],
    outputs: [
      {
        name: "decomposition",
        type: "tuple",
        components: [
          {
            name: "tokens",
            type: "tuple[]",
            components: [
              { name: "token", type: "address" },
              { name: "amount", type: "uint256" },
              { name: "parentAddress", type: "address" },
            ],
          },
          {
            name: "indexes",
            type: "tuple[]",
            components: [
              { name: "index", type: "address" },
              { name: "amount", type: "uint256" },
              { name: "parentAddress", type: "address" },
            ],
          },
        ],
      },
    ],
  },
  {
    name: "sell",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "_amount", type: "uint256" },
      { name: "_index", type: "address" },
    ],
    outputs: [
      {
        name: "decomposition",
        type: "tuple",
        components: [
          {
            name: "tokens",
            type: "tuple[]",
            components: [
              { name: "token", type: "address" },
              { name: "amount", type: "uint256" },
              { name: "parentAddress", type: "address" },
            ],
          },
          {
            name: "indexes",
            type: "tuple[]",
            components: [
              { name: "index", type: "address" },
              { name: "amount", type: "uint256" },
              { name: "parentAddress", type: "address" },
            ],
          },
        ],
      },
    ],
  },
  {
    name: "holdings",
    type: "function",
    stateMutability: "view",
    inputs: [{ name: "_index", type: "address" }],
    outputs: [
      {
        name: "decomposition",
        type: "tuple",
        components: [
          {
            name: "tokens",
            type: "tuple[]",
            components: [
              { name: "token", type: "address" },
              { name: "amount", type: "uint256" },
              { name: "parentAddress", type: "address" },
            ],
          },
          {
            name: "indexes",
            type: "tuple[]",
            components: [
              { name: "index", type: "address" },
              { name: "amount", type: "uint256" },
              { name: "parentAddress", type: "address" },
            ],
          },
        ],
      },
      { name: "totalSupply", type: "uint256" },
    ],
  },
] as const satisfies Abi;

/** Uniswap V4 Quoter: struct-based quoting via PoolKey */
export const uniswapV4QuoterAbi = [
  {
    name: "quoteExactInputSingle",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          {
            name: "poolKey",
            type: "tuple",
            components: [
              { name: "currency0", type: "address" },
              { name: "currency1", type: "address" },
              { name: "fee", type: "uint24" },
              { name: "tickSpacing", type: "int24" },
              { name: "hooks", type: "address" },
            ],
          },
          { name: "zeroForOne", type: "bool" },
          { name: "exactAmount", type: "uint128" },
          { name: "hookData", type: "bytes" },
        ],
      },
    ],
    outputs: [
      { name: "amountOut", type: "uint256" },
      { name: "gasEstimate", type: "uint256" },
    ],
  },
  {
    name: "quoteExactOutputSingle",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          {
            name: "poolKey",
            type: "tuple",
            components: [
              { name: "currency0", type: "address" },
              { name: "currency1", type: "address" },
              { name: "fee", type: "uint24" },
              { name: "tickSpacing", type: "int24" },
              { name: "hooks", type: "address" },
            ],
          },
          { name: "zeroForOne", type: "bool" },
          { name: "exactAmount", type: "uint128" },
          { name: "hookData", type: "bytes" },
        ],
      },
    ],
    outputs: [
      { name: "amountIn", type: "uint256" },
      { name: "gasEstimate", type: "uint256" },
    ],
  },
  {
    name: "quoteExactInput",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "exactCurrency", type: "address" },
          {
            name: "path",
            type: "tuple[]",
            components: [
              { name: "intermediateCurrency", type: "address" },
              { name: "fee", type: "uint24" },
              { name: "tickSpacing", type: "int24" },
              { name: "hooks", type: "address" },
              { name: "hookData", type: "bytes" },
            ],
          },
          { name: "exactAmount", type: "uint128" },
        ],
      },
    ],
    outputs: [
      { name: "amountOut", type: "uint256" },
      { name: "gasEstimate", type: "uint256" },
    ],
  },
  {
    name: "quoteExactOutput",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      {
        name: "params",
        type: "tuple",
        components: [
          { name: "exactCurrency", type: "address" },
          {
            name: "path",
            type: "tuple[]",
            components: [
              { name: "intermediateCurrency", type: "address" },
              { name: "fee", type: "uint24" },
              { name: "tickSpacing", type: "int24" },
              { name: "hooks", type: "address" },
              { name: "hookData", type: "bytes" },
            ],
          },
          { name: "exactAmount", type: "uint128" },
        ],
      },
    ],
    outputs: [
      { name: "amountIn", type: "uint256" },
      { name: "gasEstimate", type: "uint256" },
    ],
  },
] as const satisfies Abi;

/** TraderJoe V2 Router (IJoeRouter): AVAX swaps, similar to Uniswap V2 */
export const joeRouterAbi = [
  {
    name: "getAmountsOut",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "amountIn", type: "uint256" },
      { name: "path", type: "address[]" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "getAmountsIn",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "amountOut", type: "uint256" },
      { name: "path", type: "address[]" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapExactAVAXForTokens",
    type: "function",
    stateMutability: "payable",
    inputs: [
      { name: "amountOutMin", type: "uint256" },
      { name: "path", type: "address[]" },
      { name: "to", type: "address" },
      { name: "deadline", type: "uint256" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapExactTokensForAVAX",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "amountIn", type: "uint256" },
      { name: "amountOutMin", type: "uint256" },
      { name: "path", type: "address[]" },
      { name: "to", type: "address" },
      { name: "deadline", type: "uint256" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapExactTokensForTokens",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "amountIn", type: "uint256" },
      { name: "amountOutMin", type: "uint256" },
      { name: "path", type: "address[]" },
      { name: "to", type: "address" },
      { name: "deadline", type: "uint256" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapAVAXForExactTokens",
    type: "function",
    stateMutability: "payable",
    inputs: [
      { name: "amountOut", type: "uint256" },
      { name: "path", type: "address[]" },
      { name: "to", type: "address" },
      { name: "deadline", type: "uint256" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapTokensForExactAVAX",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "amountOut", type: "uint256" },
      { name: "amountInMax", type: "uint256" },
      { name: "path", type: "address[]" },
      { name: "to", type: "address" },
      { name: "deadline", type: "uint256" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
  {
    name: "swapTokensForExactTokens",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "amountOut", type: "uint256" },
      { name: "amountInMax", type: "uint256" },
      { name: "path", type: "address[]" },
      { name: "to", type: "address" },
      { name: "deadline", type: "uint256" },
    ],
    outputs: [{ name: "amounts", type: "uint256[]" }],
  },
] as const satisfies Abi;

/** Aave V3 Protocol Data Provider: getAllReservesTokens, getAllATokens */
export const aaveProtocolDataProviderAbi = [
  {
    name: "getAllReservesTokens",
    type: "function",
    stateMutability: "view",
    inputs: [],
    outputs: [
      {
        name: "",
        type: "tuple[]",
        components: [
          { name: "symbol", type: "string" },
          { name: "tokenAddress", type: "address" },
        ],
      },
    ],
  },
  {
    name: "getAllATokens",
    type: "function",
    stateMutability: "view",
    inputs: [],
    outputs: [
      {
        name: "",
        type: "tuple[]",
        components: [
          { name: "symbol", type: "string" },
          { name: "tokenAddress", type: "address" },
        ],
      },
    ],
  },
] as const satisfies Abi;

/** Aave V3 Pool: supply (mint aToken) and withdraw (burn aToken) */
export const aaveV3PoolAbi = [
  {
    name: "supply",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "asset", type: "address" },
      { name: "amount", type: "uint256" },
      { name: "onBehalfOf", type: "address" },
      { name: "referralCode", type: "uint16" },
    ],
    outputs: [],
  },
  {
    name: "withdraw",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "asset", type: "address" },
      { name: "amount", type: "uint256" },
      { name: "to", type: "address" },
    ],
    outputs: [{ name: "", type: "uint256" }],
  },
] as const satisfies Abi;

/** Factory custom errors (for decoding createIndex reverts that bubble from Factory). */
export const factoryErrorAbi = [
  { name: "Factory__UnsortedTokens", type: "error", inputs: [] },
  { name: "Factory__InvalidProtocolTokenWeight", type: "error", inputs: [] },
  { name: "Factory__InvalidTotalWeights", type: "error", inputs: [] },
  { name: "Factory__InvalidTokens", type: "error", inputs: [] },
  { name: "Factory__InvalidLengths", type: "error", inputs: [] },
  { name: "Factory__WeightOutOfRange", type: "error", inputs: [] },
  { name: "Factory__FeeOutOfRange", type: "error", inputs: [] },
  { name: "Factory__NotAllowed", type: "error", inputs: [] },
  { name: "Factory__InitialSupplyTooHigh", type: "error", inputs: [] },
  { name: "Factory__InitialSupplyTooLow", type: "error", inputs: [] },
  { name: "Factory__ZeroAddress", type: "error", inputs: [] },
] as const satisfies Abi;

/** Universal Router: outer entrypoints and custom errors for simulation (eth_call) and building real tx calldata. */
export const universalRouterAbi = [
  {
    name: "UniversalRouter__Expired",
    type: "error",
    inputs: [],
  },
  {
    name: "UniversalRouter__TransferFromBlocked",
    type: "error",
    inputs: [{ name: "operationIndex", type: "uint256" }],
  },
  {
    name: "UniversalRouter__OperationFailed",
    type: "error",
    inputs: [{ name: "operationIndex", type: "uint256" }],
  },
  {
    name: "UniversalRouter__ETHTransferFailed",
    type: "error",
    inputs: [],
  },
  {
    name: "UniversalRouter__InsufficientETHReceived",
    type: "error",
    inputs: [
      { name: "received", type: "uint256" },
      { name: "required", type: "uint256" },
    ],
  },
  {
    name: "UniversalRouter__InsufficientTokenBalance",
    type: "error",
    inputs: [
      { name: "token", type: "address" },
      { name: "balance", type: "uint256" },
      { name: "required", type: "uint256" },
    ],
  },
  {
    name: "swapETHForExactTokens",
    type: "function",
    stateMutability: "payable",
    inputs: [
      { name: "_tokenOut", type: "address" },
      { name: "_amountOut", type: "uint256" },
      { name: "_data", type: "bytes" },
      { name: "_deadline", type: "uint256" },
    ],
    outputs: [],
  },
  {
    name: "swapExactTokensForETH",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "_tokenIn", type: "address" },
      { name: "_amountIn", type: "uint256" },
      { name: "_minEthOut", type: "uint256" },
      { name: "_data", type: "bytes" },
      { name: "_deadline", type: "uint256" },
    ],
    outputs: [],
  },
  {
    name: "createIndex",
    type: "function",
    stateMutability: "payable",
    inputs: [
      {
        name: "_indexParams",
        type: "tuple",
        components: [
          { name: "name", type: "string" },
          { name: "symbol", type: "string" },
          { name: "swapFee", type: "uint16" },
          { name: "mintAndBurnFee", type: "uint8" },
          { name: "managerShareFee", type: "uint8" },
        ],
      },
      { name: "_tokens", type: "address[]" },
      { name: "_userProvidedAmounts", type: "uint256[]" },
      { name: "_minAmounts", type: "uint256[]" },
      { name: "_weights", type: "uint256[]" },
      { name: "_initialSupply", type: "uint256" },
      { name: "_data", type: "bytes" },
      { name: "_deadline", type: "uint256" },
    ],
    outputs: [{ name: "_index", type: "address" }],
  },
] as const satisfies Abi;
