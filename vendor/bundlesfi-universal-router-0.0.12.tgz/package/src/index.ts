// Export all adapters
export { UniswapV2Adapter } from "./adapters/UniswapV2Adapter.js";
export { UniswapV3Adapter } from "./adapters/UniswapV3Adapter.js";
export { TraderJoeV2Adapter } from "./adapters/TraderJoeV2Adapter.js";
export { BundlesSwapAdapter } from "./adapters/BundlesSwapAdapter.js";
export { AntfarmV1Adapter } from "./adapters/AntfarmV1Adapter.js";
export { BundlesIndexSwapAdapter } from "./adapters/BundlesIndexSwapAdapter.js";
export { AaveV3Adapter, buildATokenMaps } from "./adapters/AaveV3Adapter.js";
export { Router } from "./router/Router.js";
export type { RouteHints, TokenQuoteEntry, TokenQuoteMap, TokenAdapterSelection } from "./router/types.js";
export * from "./config/addresses.js";
export * from "./config/adapters.js";
export * from "./contracts/abis.js";

// Export utilities
export { simulateOnChain } from "./utils/simulation.js";
export { findBestRoute, findBestRouteWithBundle } from "./utils/routeHelpers.js";
export { getRevertDataFromError } from "./utils/errorHelpers.js";
export { registerAdaptersForChain } from "./utils/routerHelpers.js";
export { computeAllowanceSlot, findAllowanceBaseSlot, buildApprovalStateOverride } from "./utils/erc20Slots.js";

// Export production bundle actions
export { buyBundle, sellBundle, quoteCreateIndex, quoteBundles } from "./production/bundleActions.js";
export type {
  BundleBuyResult,
  BundleSellResult,
  BundleQuoteParams,
  BundleQuoteResult,
  TokenValuation,
  IndexParams,
  CreateIndexParams,
  CreateIndexResult,
} from "./production/bundleActions.js";

// Re-export examples for convenience (but they should typically be run directly)
// export { simulateBundleBuyExample } from "./examples/simulateBundleBuy.js";
// export { simulateBundleSellExample } from "./examples/simulateBundleSell.js";
// export { simulateCreateIndexExample } from "./examples/simulateCreateIndex.js";
// export { main as multiTokenQuotesExample } from "./examples/multiTokenQuotes.js";
// export { testBundleRoutes } from "./examples/testBundleRoutes.js";
// export { quoteBundlesExample } from "./examples/quoteBundles.js";

// --- Entrypoint: uncomment the one you want to run ---
// (1) On-chain simulation: BUY bundle via eth_call
// import { simulateBundleBuyExample } from "./examples/simulateBundleBuy.js";
// simulateBundleBuyExample().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });

// (1b) On-chain simulation: BUY bundle with route hints (EURC via USDT)
// import { simulateBundleBuyHintExample } from "./examples/simulateBundleBuyHint.js";
// simulateBundleBuyHintExample().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });

// (2) On-chain simulation: SELL bundle via eth_call
// import { simulateBundleSellExample } from "./examples/simulateBundleSell.js";
// simulateBundleSellExample().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });

// (3) Bundle route tests only (no simulation): compare direct swap vs mint/burn, log calldata.
// import { testBundleRoutes as runTestBundleRoutes } from "./examples/testBundleRoutes.js";
// runTestBundleRoutes().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });

// (4) Standard multi-token quote demo.
// import { multiTokenQuotesExample } from "./examples/multiTokenQuotes.js";
// multiTokenQuotesExample().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });

// (5) On-chain simulation: CREATE INDEX via eth_call
// import { simulateCreateIndexExample } from "./examples/simulateCreateIndex.js"
// simulateCreateIndexExample().catch((err) => {
//   console.error(err);
//   process.exit(1);
// })

// (6) Bundle quotation: get ETH value of one or multiple bundles
// import { quoteBundlesExample } from "./examples/quoteBundles.js";
// quoteBundlesExample().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });
