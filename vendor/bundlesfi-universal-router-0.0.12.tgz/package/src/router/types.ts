import type { DexAdapter } from "../adapters/DexAdapter.js";
import type { Address } from "viem";

export interface QuoteResult {
  adapter: DexAdapter;
  amountOut: bigint;
}

export interface QuoteResultExactOut {
  adapter: DexAdapter;
  amountIn: bigint;
}

/** One sell leg: asset (token or bundle) sold for WETH. */
export interface SellLeg {
  asset: Address;
  isBundle: boolean;
  amountIn: bigint;
  amountOut: bigint;
  adapterName: string;
}

/**
 * Route hints: maps a target token address to intermediary token(s).
 * For buying EURC via USDT: `new Map([[EURC, [USDT]]])` expands
 * `[WETH, EURC]` to `[WETH, USDT, EURC]`.
 */
export type RouteHints = Map<Address, Address[]>;

/** One quote entry for a token: tracks the multicall index, adapter, and path used. */
export interface TokenQuoteEntry {
  index: number;
  adapter: DexAdapter;
  path: Address[];
}

/** Map of token address to its quote entries. */
export type TokenQuoteMap = Map<Address, TokenQuoteEntry[]>;

/** Adapter selection for a token, including the winning path. */
export interface TokenAdapterSelection {
  adapter: DexAdapter;
  quotedAmountIn: bigint;
  path: Address[];
}
