import type { Address, Hex, PublicClient } from "viem";
import type { DexAdapter } from "../../adapters/DexAdapter.js";
import type { AaveV3Adapter } from "../../adapters/AaveV3Adapter.js";
import { CalldataBuilder } from "../../calldata/CalldataBuilder.js";
import { type ContractAddresses } from "../../config/addresses.js";
import { sortIndexesForBuy, sortIndexesForSell } from "../../bundle/BundleHelper.js";
import { indexAbi } from "../../contracts/abis.js";
import { getApplicableAdaptersForExactIn, getApplicableAdaptersForExactOut } from "../helpers/adapterFilters.js";
import type { NestedBundleRoute } from "./types.js";
import type { RouteHints, TokenAdapterSelection } from "../types.js";
import { buildQuotingPaths } from "../path.js";
import { debugLog } from "../../utils/logger.js";

export class BundleCalldataBuilder {
  constructor(
    private client: PublicClient,
    private contractAddresses: ContractAddresses,
    private adapters: DexAdapter[]
  ) { }

  /**
   * Build calldata for indirect buy route: buy tokens, mint nested bundles, mint root bundle.
   *
   * When aTokens are present in the decomposition (e.g. aEthUSDC), the flow becomes:
   *   1. Swap WETH -> underlying (via DEX adapter)
   *   2. Supply underlying -> aToken (via AaveV3Adapter, 1:1)
   *   3. Mint the bundle with the aToken
   */
  async buildIndirectBuyCalldata(
    bundleAddress: Address,
    bundleAmount: bigint,
    decomposition: {
      tokens: readonly { token: Address; amount: bigint; parentAddress: Address }[];
      indexes: readonly { index: Address; amount: bigint; parentAddress: Address }[];
    },
    recipient: Address,
    nestedBundleRoutes?: Map<Address, NestedBundleRoute>,
    tokenAdapterSelections?: Map<Address, TokenAdapterSelection>,
    aaveAdapter?: AaveV3Adapter,
    aTokensInDecomposition?: Map<string, Address>,
    routeHints?: RouteHints
  ): Promise<CalldataBuilder> {
    const builder = new CalldataBuilder(this.contractAddresses.RECIPIENT_PLACEHOLDER);

    const tokenAmounts = new Map<Address, bigint>();
    const directNestedAddresses = new Set<string>();
    if (nestedBundleRoutes) {
      for (const [bundleAddr, route] of nestedBundleRoutes) {
        if (route.isDirect) {
          directNestedAddresses.add(bundleAddr.toLowerCase());
        }
      }
    }

    let skippedCount = 0;
    for (const tokenAmount of decomposition.tokens) {
      if (directNestedAddresses.has(tokenAmount.parentAddress.toLowerCase())) {
        skippedCount++;
        continue;
      }
      const existing = tokenAmounts.get(tokenAmount.token) || 0n;
      tokenAmounts.set(tokenAmount.token, existing + tokenAmount.amount);
    }

    if (skippedCount > 0) {
      debugLog(`[DEBUG _buildIndirectBuyCalldata] Skipped ${skippedCount} token entries inside nested bundles bought directly`);
      debugLog(`[DEBUG _buildIndirectBuyCalldata] Aggregated ${tokenAmounts.size} unique tokens for buying`);
    }

    for (const [token, amount] of tokenAmounts) {
      if (token.toLowerCase() === this.contractAddresses.WETH.toLowerCase()) continue;

      const underlying = aTokensInDecomposition?.get(token.toLowerCase());
      const isAToken = underlying !== undefined && aaveAdapter !== undefined;
      const swapTarget = isAToken ? underlying : token;

      // For aTokens, add a buffer to the swap/supply amounts. The mint()
      // recalculates tokenAmountIn from the bundle's live aToken balance which
      // grows every block due to interest accrual. Without a buffer, the
      // Universal Router ends up with fewer aTokens than mint() demands.
      // 0.001% covers ~1.7 h of accrual at 5% APY plus Aave ray-math rounding.
      const aTokenBuffer = isAToken ? (amount / 100000n > 10n ? amount / 100000n : 10n) : 0n;
      const swapAmount = amount + aTokenBuffer;

      const selection = tokenAdapterSelections?.get(token);
      if (selection) {
        // Use stored adapter, path, and quoted amount from scenario calculation
        selection.adapter.buildExactOut(
          builder,
          selection.path,
          swapAmount,
          recipient,
          selection.quotedAmountIn
        );
      } else {
        // Fallback: try all paths (direct + hinted) and re-quote
        const paths = buildQuotingPaths(this.contractAddresses.WETH, swapTarget, routeHints, token);
        let bestAdapter: DexAdapter | null = null;
        let bestAmountIn = 2n ** 256n - 1n;
        let bestPath: Address[] = paths[0]!;

        for (const quotePath of paths) {
          const applicable = getApplicableAdaptersForExactOut(this.adapters, quotePath, this.contractAddresses.WETH);
          for (const adapter of applicable) {
            try {
              const quote = await adapter.quoteExactOut(quotePath, swapAmount);
              if (quote < bestAmountIn) {
                bestAmountIn = quote;
                bestAdapter = adapter;
                bestPath = quotePath;
              }
            } catch {
              // Quote failed
            }
          }
        }

        if (bestAdapter) {
          const amountInMax = bestAmountIn < 2n ** 256n - 1n ? bestAmountIn : undefined;
          bestAdapter.buildExactOut(
            builder,
            bestPath,
            swapAmount,
            recipient,
            amountInMax
          );
        }
      }

      if (isAToken) {
        debugLog(`[Aave BUY] Token ${token.slice(0, 10)}... is aToken — adding supply(${underlying.slice(0, 10)}..., ${swapAmount}) to Aave Pool (includes ${aTokenBuffer} buffer for interest accrual)`);
        aaveAdapter!.buildExactIn(builder, [underlying, token], swapAmount, recipient);
      }
    }

    // Handle nested bundles in innermost-to-outermost order (mint lower-level before upper)
    const sortedIndexesBuy = sortIndexesForBuy(decomposition.indexes, bundleAddress);
    for (const indexEntry of sortedIndexesBuy) {
      const routeDecision = nestedBundleRoutes?.get(indexEntry.index);
      if (routeDecision?.isDirect && routeDecision.adapter) {
        // Use direct swap - add swap calldata from the recursive result
        // Note: We can't easily merge calldatas, so we'll build the swap here
        const bundlePath: Address[] = [this.contractAddresses.WETH, indexEntry.index];
        routeDecision.adapter.buildExactOut(builder, bundlePath, indexEntry.amount, recipient);
      } else {
        // Mint indirectly - get tokens and mint
        const nestedTokens = await this.client.readContract({
          address: indexEntry.index,
          abi: indexAbi,
          functionName: "getTokens",
        });

        // Calculate actual token amounts needed for this nested bundle from decomposition
        const nestedTokenAmounts = new Map<Address, bigint>();
        const nestedBundleLower = indexEntry.index.toLowerCase();
        for (const tokenAmount of decomposition.tokens) {
          if (tokenAmount.parentAddress.toLowerCase() === nestedBundleLower) {
            const existing = nestedTokenAmounts.get(tokenAmount.token) || 0n;
            nestedTokenAmounts.set(tokenAmount.token, existing + tokenAmount.amount);
          }
        }

        builder.addBundleMint(
          indexEntry.index,
          indexEntry.amount,
          recipient,
          [...nestedTokens],
          nestedTokenAmounts
        );
      }
    }

    // Mint root bundle last
    // Get tokens for root bundle from the Index contract
    const rootTokens = await this.client.readContract({
      address: bundleAddress,
      abi: indexAbi,
      functionName: "getTokens",
    });

    // Calculate actual token amounts needed for root bundle from decomposition
    const rootTokenAmounts = new Map<Address, bigint>();
    const bundleAddressLower = bundleAddress.toLowerCase();
    for (const tokenAmount of decomposition.tokens) {
      if (tokenAmount.parentAddress.toLowerCase() === bundleAddressLower) {
        const existing = rootTokenAmounts.get(tokenAmount.token) || 0n;
        rootTokenAmounts.set(tokenAmount.token, existing + tokenAmount.amount);
      }
    }

    builder.addBundleMint(bundleAddress, bundleAmount, recipient, [...rootTokens], rootTokenAmounts);

    return builder;
  }

  /**
   * Build calldata for indirect sell route: burn root bundle, burn nested bundles, sell tokens.
   *
   * When aTokens are present in the decomposition, the flow becomes:
   *   1. Burn the bundle (receives aTokens)
   *   2. Withdraw underlying from Aave (burn aToken, 1:1)
   *   3. Sell underlying -> WETH (via DEX adapter)
   */
  async buildIndirectSellCalldata(
    bundleAddress: Address,
    bundleAmount: bigint,
    decomposition: {
      tokens: readonly { token: Address; amount: bigint; parentAddress: Address }[];
      indexes: readonly { index: Address; amount: bigint; parentAddress: Address }[];
    },
    recipient: Address,
    nestedBundleRoutes?: Map<Address, NestedBundleRoute>,
    aaveAdapter?: AaveV3Adapter,
    aTokensInDecomposition?: Map<string, Address>,
    routeHints?: RouteHints
  ): Promise<CalldataBuilder> {
    const builder = new CalldataBuilder(this.contractAddresses.RECIPIENT_PLACEHOLDER);

    const rootTokens = await this.client.readContract({
      address: bundleAddress,
      abi: indexAbi,
      functionName: "getTokens",
    });
    builder.addBundleBurn(bundleAddress, bundleAmount, recipient, [...rootTokens]);

    const sortedIndexesSell = sortIndexesForSell(decomposition.indexes, bundleAddress);
    for (const indexEntry of sortedIndexesSell) {
      const routeDecision = nestedBundleRoutes?.get(indexEntry.index);
      if (routeDecision?.isDirect && routeDecision.adapter) {
        const bundlePath: Address[] = [indexEntry.index, this.contractAddresses.WETH];
        routeDecision.adapter.buildExactIn(builder, bundlePath, indexEntry.amount, recipient);
      } else {
        const nestedTokens = await this.client.readContract({
          address: indexEntry.index,
          abi: indexAbi,
          functionName: "getTokens",
        });
        builder.addBundleBurn(
          indexEntry.index,
          indexEntry.amount,
          recipient,
          [...nestedTokens]
        );
      }
    }

    const tokenAmounts = new Map<Address, bigint>();
    for (const tokenAmount of decomposition.tokens) {
      const existing = tokenAmounts.get(tokenAmount.token) || 0n;
      tokenAmounts.set(tokenAmount.token, existing + tokenAmount.amount);
    }

    for (const [token, amount] of tokenAmounts) {
      if (token.toLowerCase() === this.contractAddresses.WETH.toLowerCase()) continue;

      const underlying = aTokensInDecomposition?.get(token.toLowerCase());
      const isAToken = underlying !== undefined && aaveAdapter !== undefined;

      if (isAToken) {
        debugLog(`[Aave SELL] Token ${token.slice(0, 10)}... is aToken — adding withdraw(${underlying.slice(0, 10)}..., ${amount}) from Aave Pool`);
        aaveAdapter!.buildExactIn(builder, [token, underlying], amount, recipient);
      }

      const sellToken = isAToken ? underlying : token;

      // Try all paths (direct + hinted) and find the best adapter
      const paths = buildQuotingPaths(sellToken, this.contractAddresses.WETH, routeHints, token);
      let bestAdapter: DexAdapter | null = null;
      let bestAmountOut = 0n;
      let bestPath: Address[] = paths[0]!;

      for (const quotePath of paths) {
        const applicable = getApplicableAdaptersForExactIn(this.adapters, quotePath, this.contractAddresses.WETH);
        for (const adapter of applicable) {
          try {
            const quote = await adapter.quoteExactIn(quotePath, amount);
            if (quote > bestAmountOut) {
              bestAmountOut = quote;
              bestAdapter = adapter;
              bestPath = quotePath;
            }
          } catch {
            // Quote failed
          }
        }
      }

      if (bestAdapter) {
        bestAdapter.buildExactIn(builder, bestPath, amount, recipient);
      }
    }

    return builder;
  }
}
