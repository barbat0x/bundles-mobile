import type { Address, Hex } from "viem";
import type { DexAdapter } from "../../adapters/DexAdapter.js";
import type { Decomposition } from "../../bundle/BundleHelper.js";

export interface BundleRouteOptions {
  token: Address;
  isBuying: boolean;
}

export interface NestedBundleRoute {
  isDirect: boolean;
  calldata?: Hex;
  adapter?: DexAdapter;
  amount?: bigint;
}

export interface ScenarioConfig {
  numScenarios: number;
  tokenTotalsByScenario: Map<number, Map<Address, bigint>>;
}

export interface RouteComparison {
  directQuote: bigint | null;
  indirectQuote: bigint | null;
  bestRoute: "direct" | "indirect" | null;
}

export interface BundleDecomposition {
  decomposition: Decomposition;
  bundleAddress: Address;
}
