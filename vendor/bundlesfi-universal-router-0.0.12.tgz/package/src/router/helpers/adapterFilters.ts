import type { Address } from "viem";
import type { DexAdapter } from "../../adapters/DexAdapter.js";
import { BundlesIndexSwapAdapter } from "../../adapters/BundlesIndexSwapAdapter.js";

/**
 * Check if adapter can handle exact-in for the given path.
 * Adapter can handle exact-in if path length >= 2 for V2-style or === 2 for V3-style.
 * If adapter implements canHandlePath, use that; otherwise use default logic.
 */
export function canAdapterHandleExactIn(adapter: DexAdapter, path: Address[]): boolean {
  if (path.length < 2) return false;
  // Use adapter's canHandlePath if available
  if (adapter.canHandlePath) {
    return adapter.canHandlePath(path, true);
  }
  // Default logic: V3 adapters only support length 2; V2 supports >= 2
  if (adapter.name.toLowerCase().includes("v3")) return path.length === 2;
  return true;
}

/**
 * Check if adapter can handle exact-out for the given path.
 * Same logic as exact-in.
 */
export function canAdapterHandleExactOut(adapter: DexAdapter, path: Address[]): boolean {
  if (path.length < 2) return false;
  // Use adapter's canHandlePath if available
  if (adapter.canHandlePath) {
    return adapter.canHandlePath(path, false);
  }
  // Default logic: same as exact-in
  if (adapter.name.toLowerCase().includes("v3")) return path.length === 2;
  return true;
}

/**
 * Get adapters that can handle exact-in for this path.
 * - WETH ↔ bundle: only BundlesIndexSwapAdapter (when other token is in bundleAddresses).
 * - WETH ↔ other: all adapters including BundlesIndexSwapAdapter (non-bundle tokens may
 *   also have pools on the BundlesIndexSwap router; on-chain failures are handled by
 *   multicall allowFailure).
 */
export function getApplicableAdaptersForExactIn(
  adapters: DexAdapter[],
  path: Address[],
  weth: Address,
  bundleAddresses?: Set<Address>
): DexAdapter[] {
  const base = adapters.filter((a) => canAdapterHandleExactIn(a, path));
  if (path.length !== 2) return base;
  const wethLower = weth.toLowerCase();
  const a = path[0]!.toLowerCase();
  const b = path[1]!.toLowerCase();
  if (a !== wethLower && b !== wethLower) return base;
  const other = a === wethLower ? path[1]! : path[0]!;
  const otherLower = other.toLowerCase();
  const isBundle =
    bundleAddresses &&
    Array.from(bundleAddresses).some((addr) => addr.toLowerCase() === otherLower);
  if (isBundle) {
    const indexAdapters = base.filter((a) => a instanceof BundlesIndexSwapAdapter);
    return indexAdapters.length > 0 ? indexAdapters : base;
  }
  return base;
}

/**
 * Get adapters that can handle exact-out for this path.
 * - WETH ↔ bundle (index): only BundlesIndexSwapAdapter (when other token is in bundleAddresses).
 * - WETH ↔ other: all adapters including BundlesIndexSwapAdapter.
 */
export function getApplicableAdaptersForExactOut(
  adapters: DexAdapter[],
  path: Address[],
  weth: Address,
  bundleAddresses?: Set<Address>
): DexAdapter[] {
  const base = adapters.filter((a) => canAdapterHandleExactOut(a, path));
  if (path.length !== 2) return base;
  const wethLower = weth.toLowerCase();
  const a = path[0]!.toLowerCase();
  const b = path[1]!.toLowerCase();
  if (a !== wethLower && b !== wethLower) return base;
  const other = a === wethLower ? path[1]! : path[0]!;
  const otherLower = other.toLowerCase();
  const isBundle =
    bundleAddresses &&
    Array.from(bundleAddresses).some((addr) => addr.toLowerCase() === otherLower);
  if (isBundle) {
    const indexAdapters = base.filter((a) => a instanceof BundlesIndexSwapAdapter);
    return indexAdapters.length > 0 ? indexAdapters : base;
  }
  return base;
}
