import type { DexAdapter, MulticallContract } from "../../adapters/DexAdapter.js";

/**
 * Parse quote result from exact-in multicall contract call.
 * Handles different function return types: getAmountsOut (array), quoteExactInputSingle (single value), etc.
 */
export function parseQuoteExactInResult(
  _adapter: DexAdapter,
  result: unknown,
  contract: MulticallContract
): bigint | undefined {
  if (contract.functionName === "getAmountsOut") {
    const amounts = result as bigint[];
    return Array.isArray(amounts) && amounts.length > 0 ? amounts[amounts.length - 1] : undefined;
  }
  if (contract.functionName === "quoteExactInputSingle" || contract.functionName === "quoteExactInput") {
    if (Array.isArray(result)) return result[0] as bigint; // V4: (amountOut, gasEstimate)
    return result as bigint;
  }
  // BundlesIndexSwap estimate functions return single uint256
  if (
    contract.functionName === "estimateExactETHForTokens" ||
    contract.functionName === "estimateExactTokensForETH"
  ) {
    return result as bigint;
  }
  return undefined;
}

/**
 * Parse quote result from exact-out multicall contract call.
 * Handles different function return types: getAmountsIn (array), quoteExactOutputSingle (single value), etc.
 */
export function parseQuoteExactOutResult(
  _adapter: DexAdapter,
  result: unknown,
  contract: MulticallContract
): bigint | undefined {
  if (contract.functionName === "getAmountsIn") {
    const amounts = result as bigint[];
    return Array.isArray(amounts) && amounts.length > 0 ? amounts[0] : undefined;
  }
  if (contract.functionName === "quoteExactOutputSingle" || contract.functionName === "quoteExactOutput") {
    if (Array.isArray(result)) return result[0] as bigint; // V4: (amountIn, gasEstimate)
    return result as bigint;
  }
  // BundlesIndexSwap estimate function returns single uint256
  if (contract.functionName === "estimateETHForExactTokens") {
    return result as bigint;
  }
  return undefined;
}
