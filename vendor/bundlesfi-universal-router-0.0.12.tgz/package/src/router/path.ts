import type { Address } from "viem";
import type { RouteHints } from "./types.js";

/**
 * Normalize path: replace "ETH" with WETH address.
 * Returns a new array of Address (no "ETH" string in output).
 */
export function normalizePath(
  path: (Address | "ETH")[],
  weth: Address
): Address[] {
  return path.map((p) => (p === "ETH" ? weth : p)) as Address[];
}

/** Validate path length for V2 (>= 2) and optionally for V3 (=== 2). */
export function validatePathV2(path: Address[]): void {
  if (path.length < 2) {
    throw new Error(`V2 path must have at least 2 tokens, got ${path.length}`);
  }
}

export function validatePathV3(path: Address[]): void {
  if (path.length !== 2) {
    throw new Error(`V3 single-hop path must have exactly 2 tokens, got ${path.length}`);
  }
}

/**
 * Build all quoting paths for a token pair, including a hinted multi-hop path
 * when routeHints provides intermediary tokens. Both the direct and hinted path
 * are returned so they can compete in the same multicall.
 *
 * @param from       Source token (e.g. WETH for buy, token for sell)
 * @param to         Destination token (e.g. token for buy, WETH for sell)
 * @param routeHints Optional map of token -> intermediary tokens
 * @param hintKey    The token address to look up in routeHints (before aToken
 *                   resolution). Falls back to `to` if not provided.
 */
export function buildQuotingPaths(
  from: Address,
  to: Address,
  routeHints?: RouteHints,
  hintKey?: Address
): Address[][] {
  const direct: Address[] = [from, to];
  if (!routeHints || routeHints.size === 0) return [direct];

  const keyLower = (hintKey ?? to).toLowerCase();
  let intermediaries: Address[] | undefined;
  for (const [hintAddr, hintIntermediaries] of routeHints) {
    if (hintAddr.toLowerCase() === keyLower) {
      intermediaries = hintIntermediaries;
      break;
    }
  }
  if (intermediaries && intermediaries.length > 0) {
    const hinted: Address[] = [from, ...intermediaries, to];
    return [direct, hinted];
  }
  return [direct];
}
