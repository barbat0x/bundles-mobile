import type { Address, Hex, PublicClient } from "viem";
import type { DexAdapter, MulticallContract } from "../adapters/DexAdapter.js";
import { CalldataBuilder } from "../calldata/CalldataBuilder.js";
import { normalizePath, buildQuotingPaths } from "./path.js";
import { DEFAULT_CONTRACT_ADDRESSES, type ContractAddresses } from "../config/addresses.js";
import {
  decomposeBundleBuy,
  decomposeBundleSell,
  buildSellTree,
  buildBuyTree,
  sortIndexesForBuy,
  sortIndexesForSell,
  type Decomposition,
  type TokenAmount,
  type IndexEntry,
  type SellTree,
} from "../bundle/BundleHelper.js";
import { BundlesIndexSwapAdapter } from "../adapters/BundlesIndexSwapAdapter.js";
import { AaveV3Adapter, buildATokenMaps } from "../adapters/AaveV3Adapter.js";
import { decomposerAbi, aaveProtocolDataProviderAbi, indexAbi, erc20Abi } from "../contracts/abis.js";
import {
  parseQuoteExactInResult,
  parseQuoteExactOutResult,
} from "./helpers/quoteParsers.js";
import {
  canAdapterHandleExactIn,
  getApplicableAdaptersForExactIn,
  getApplicableAdaptersForExactOut,
} from "./helpers/adapterFilters.js";
import type { QuoteResult, QuoteResultExactOut, SellLeg, RouteHints, TokenQuoteEntry, TokenQuoteMap, TokenAdapterSelection } from "./types.js";
import { BundleCalldataBuilder } from "./bundle/BundleCalldataBuilder.js";
import type { NestedBundleRoute } from "./bundle/types.js";
import { debugLog } from "../utils/logger.js";

// Re-export types for backward compatibility
export type { QuoteResult, QuoteResultExactOut, SellLeg, RouteHints, TokenQuoteEntry, TokenQuoteMap, TokenAdapterSelection } from "./types.js";

/**
 * Central orchestrator: holds adapters, runs multicall for quotes,
 * selects best route, builds UniversalRouter calldata.
 */
export class Router {
  private adapters: DexAdapter[] = [];

  constructor(
    private client: PublicClient,
    public contractAddresses: ContractAddresses = DEFAULT_CONTRACT_ADDRESSES
  ) { }

  get weth(): Address {
    return this.contractAddresses.WETH;
  }

  register(adapter: DexAdapter): void {
    this.adapters.push(adapter);
  }

  /**
   * Get adapters that can handle exact-out for this path.
   * - WETH ↔ bundle (index): only BundlesIndexSwapAdapter (when other token is in bundleAddresses).
   * - WETH ↔ other (e.g. BUN): BundlesSwap and others, never BundlesIndexSwapAdapter.
   */
  private _getApplicableAdaptersForExactOut(
    path: Address[],
    bundleAddresses?: Set<Address>
  ): DexAdapter[] {
    return getApplicableAdaptersForExactOut(this.adapters, path, this.weth, bundleAddresses);
  }

  /**
   * Get adapters that can handle exact-in for this path.
   * - WETH ↔ bundle: only BundlesIndexSwapAdapter (when other token is in bundleAddresses).
   * - WETH ↔ other (e.g. BUN): BundlesSwap and others, never BundlesIndexSwapAdapter.
   */
  private _getApplicableAdaptersForExactIn(
    path: Address[],
    bundleAddresses?: Set<Address>
  ): DexAdapter[] {
    return getApplicableAdaptersForExactIn(this.adapters, path, this.weth, bundleAddresses);
  }

  /**
   * Check current allowances for required approvals via multicall.
   * @param requiredApprovals Map of approval key (token:spender) to required amount
   * @param owner Address that owns the tokens (UniversalRouter)
   * @returns Map of approval key to current allowance
   */
  private async checkAllowances(
    requiredApprovals: Map<string, { token: Address; spender: Address; amount: bigint }>,
    owner: Address
  ): Promise<Map<string, bigint>> {
    if (requiredApprovals.size === 0) {
      return new Map();
    }

    const contracts: MulticallContract[] = [];
    const keyToIndex = new Map<string, number>();

    for (const [key, { token, spender }] of requiredApprovals) {
      const index = contracts.length;
      keyToIndex.set(key, index);
      contracts.push({
        address: token,
        abi: erc20Abi as readonly unknown[],
        functionName: "allowance",
        args: [owner, spender],
      });
    }

    const results = await this.client.multicall({
      contracts: contracts as Parameters<PublicClient["multicall"]>[0]["contracts"],
      allowFailure: true,
    });

    const allowances = new Map<string, bigint>();
    for (const [key, index] of keyToIndex) {
      const result = results[index];
      if (result?.status === "success" && result.result !== undefined) {
        allowances.set(key, result.result as bigint);
      } else {
        // Default to 0 if read fails
        allowances.set(key, 0n);
      }
    }

    return allowances;
  }

  /**
   * Format amount for logging: if >= 90% of max uint256, return "max uint256", otherwise return number as string.
   */
  private formatAmount(amount: bigint): string {
    const maxUint256 = 2n ** 256n - 1n;
    const threshold = (maxUint256 * 90n) / 100n;
    if (amount >= threshold) {
      return "max uint256";
    }
    return amount.toString();
  }

  /**
   * Filter out unnecessary approvals from the builder based on current allowances.
   * @param builder CalldataBuilder with approvals
   * @param allowances Map of approval key to current allowance
   * @param requiredApprovals Map of approval key to required amount
   * @param isExactOut Whether this is an exact-out swap (needs 10% buffer)
   */
  private filterUnnecessaryApprovals(
    builder: CalldataBuilder,
    allowances: Map<string, bigint>,
    requiredApprovals: Map<string, { token: Address; spender: Address; amount: bigint; isBundleMint?: boolean }>,
    isExactOut: boolean,
    options?: {
      printLogs?: boolean;
    }
  ): void {
    if (options?.printLogs) {
      console.log(`[Approval Filter] Checking ${requiredApprovals.size} approval(s)...`);
    }

    let removedCount = 0;
    let keptCount = 0;
    const maxUint256 = 2n ** 256n - 1n;
    const veryLargeThreshold = (maxUint256 * 90n) / 100n; // 90% of max uint256

    for (const [key, { token, spender, amount, isBundleMint }] of requiredApprovals) {
      const currentAllowance = allowances.get(key) ?? 0n;

      // Handle bundle mint approvals specially
      if (isBundleMint) {
        // For bundle mints, use actual token amount from decomposition (stored in amount field)
        // We'll approve max uint256 for safety, but the actual required amount is what we check
        const requiredAmount = amount; // This is now the actual token amount from decomposition

        // For bundle mints, remove approval if:
        // 1. Current allowance is already max uint256 or very large (90%+), OR
        // 2. Current allowance is sufficient for the actual required amount
        if (currentAllowance >= veryLargeThreshold || currentAllowance >= requiredAmount) {
          builder.removeApproval(token, spender);
          removedCount++;
          const reason = currentAllowance >= veryLargeThreshold
            ? "already max approved"
            : "already sufficient";
          if (options?.printLogs) {
            console.log(`[Approval Filter] Removing bundle mint approval: ${token} -> ${spender} (current: ${this.formatAmount(currentAllowance)}, required: ${this.formatAmount(requiredAmount)}, ${reason})`);
          }
        } else {
          keptCount++;
          if (options?.printLogs) {
            console.log(`[Approval Filter] Keeping bundle mint approval: ${token} -> ${spender} (current: ${this.formatAmount(currentAllowance)}, required: ${this.formatAmount(requiredAmount)}, will approve max)`);
          }
        }
        continue;
      }

      // For regular approvals, use actual required amount (not max uint256)
      // For exact-out swaps, add 10% buffer to required amount
      const bufferedAmount = isExactOut
        ? (amount * 110n) / 100n  // 10% buffer
        : amount;

      // If current allowance is sufficient (including buffer for exact-out), remove approval
      if (currentAllowance >= bufferedAmount) {
        builder.removeApproval(token, spender);
        removedCount++;
        if (options?.printLogs) {
          console.log(`[Approval Filter] Removing approval: ${token} -> ${spender} (current: ${this.formatAmount(currentAllowance)}, required: ${this.formatAmount(bufferedAmount)}, already approved)`);
        }
      } else {
        keptCount++;
        if (options?.printLogs) {
          console.log(`[Approval Filter] Keeping approval: ${token} -> ${spender} (current: ${this.formatAmount(currentAllowance)}, required: ${this.formatAmount(bufferedAmount)}, will approve max)`);
        }
      }
    }

    if (options?.printLogs) {
      console.log(`[Approval Filter] Summary: ${removedCount} removed, ${keptCount} kept`);
    }
  }

  /**
   * Find best exact-in route via multicall, then build and return UniversalRouter calldata.
   */
  async findBestExactIn(
    path: (Address | "ETH")[],
    amountIn: bigint,
    recipient: Address,
    bundleAddresses?: Set<Address>,
    routeHints?: RouteHints
  ): Promise<{ calldata: Hex; quotes: { name: string; amountOut: bigint }[]; best: QuoteResult }> {
    const normalized = normalizePath(path, this.weth);
    if (normalized.length < 2) {
      throw new Error("Path must have at least 2 tokens");
    }

    const applicable = this._getApplicableAdaptersForExactIn(normalized, bundleAddresses);
    if (applicable.length === 0) {
      throw new Error("No adapter supports this path for exact-in");
    }

    const contracts: MulticallContract[] = applicable.map((a) =>
      a.getQuoteExactInContract(normalized, amountIn)
    );
    const results = await this.client.multicall({
      contracts: contracts as Parameters<PublicClient["multicall"]>[0]["contracts"],
      allowFailure: true,
    });

    const quotes: { name: string; amountOut: bigint }[] = [];
    let best: QuoteResult | null = null;
    for (let i = 0; i < results.length; i++) {
      const r = results[i];
      const adapter = applicable[i]!;
      if (r?.status === "success" && r?.result !== undefined) {
        const amountOut = parseQuoteExactInResult(adapter, r.result, contracts[i]!);
        if (amountOut !== undefined) {
          quotes.push({ name: adapter.name, amountOut });
          if (best === null || amountOut > best.amountOut) {
            best = { adapter, amountOut };
          }
        }
      }
    }

    if (best === null) {
      throw new Error("No successful quote from any adapter");
    }

    const builder = new CalldataBuilder(this.contractAddresses.RECIPIENT_PLACEHOLDER);
    best.adapter.buildExactIn(builder, normalized, amountIn, recipient);

    // Extract required approvals and check current allowances
    const requiredApprovals = builder.getRequiredApprovals();
    if (requiredApprovals.size > 0) {
      const allowances = await this.checkAllowances(requiredApprovals, this.contractAddresses.UNIVERSAL_ROUTER);
      this.filterUnnecessaryApprovals(builder, allowances, requiredApprovals, false);
    }

    const calldata = builder.encodeForUniversalRouter(this.contractAddresses.UNIVERSAL_ROUTER);

    return { calldata, quotes, best };
  }

  /**
   * Find best exact-out route via multicall, then build and return UniversalRouter calldata.
   */
  async findBestExactOut(
    path: (Address | "ETH")[],
    amountOut: bigint,
    recipient: Address,
    bundleAddresses?: Set<Address>,
    routeHints?: RouteHints
  ): Promise<{ calldata: Hex; quotes: { name: string; amountIn: bigint }[]; best: QuoteResultExactOut }> {
    const normalized = normalizePath(path, this.weth);
    if (normalized.length < 2) {
      throw new Error("Path must have at least 2 tokens");
    }

    const applicable = this._getApplicableAdaptersForExactOut(normalized, bundleAddresses);
    if (applicable.length === 0) {
      throw new Error("No adapter supports this path for exact-out");
    }

    const contracts: MulticallContract[] = applicable.map((a) =>
      a.getQuoteExactOutContract(normalized, amountOut)
    );
    const results = await this.client.multicall({
      contracts: contracts as Parameters<PublicClient["multicall"]>[0]["contracts"],
      allowFailure: true,
    });

    const quotes: { name: string; amountIn: bigint }[] = [];
    let best: QuoteResultExactOut | null = null;
    for (let i = 0; i < results.length; i++) {
      const r = results[i];
      const adapter = applicable[i]!;
      if (r?.status === "success" && r?.result !== undefined) {
        const amountIn = parseQuoteExactOutResult(adapter, r.result, contracts[i]!);
        if (amountIn !== undefined) {
          quotes.push({ name: adapter.name, amountIn });
          if (best === null || amountIn < best.amountIn) {
            best = { adapter, amountIn };
          }
        }
      }
    }

    if (best === null) {
      throw new Error("No successful quote from any adapter");
    }

    const builder = new CalldataBuilder(this.contractAddresses.RECIPIENT_PLACEHOLDER);
    best.adapter.buildExactOut(builder, normalized, amountOut, recipient, best.amountIn);

    // Extract required approvals and check current allowances
    const requiredApprovals = builder.getRequiredApprovals();
    if (requiredApprovals.size > 0) {
      const allowances = await this.checkAllowances(requiredApprovals, this.contractAddresses.UNIVERSAL_ROUTER);
      this.filterUnnecessaryApprovals(builder, allowances, requiredApprovals, true); // exact-out needs buffer
    }

    const calldata = builder.encodeForUniversalRouter(this.contractAddresses.UNIVERSAL_ROUTER);

    return { calldata, quotes, best };
  }

  /**
   * Find best exact-in route with Bundle support.
   * Compares direct swap vs indirect route (mint/burn) when Bundle token is involved.
   * Uses Decomposer contract to get all required tokens and nested bundles.
   * 
   * For buying Bundle (WETH -> Bundle):
   *   - Direct: Swap WETH -> Bundle via BundlesIndexSwapAdapter
   *   - Indirect: Buy all underlyings with WETH, mint nested bundles, then mint Bundle
   * 
   * For selling Bundle (Bundle -> WETH):
   *   - Direct: Swap Bundle -> WETH via BundlesIndexSwapAdapter  
   *   - Indirect: Burn Bundle, burn nested bundles, then sell each token for WETH
   */
  async findBestExactInWithBundle(
    path: (Address | "ETH")[],
    amountIn: bigint,
    recipient: Address,
    options?: {
      isBundle?: { token: Address; isBuying: boolean },
      printLogs?: boolean,
      routeHints?: RouteHints
    },
  ): Promise<{ calldata: Hex; quotes: { name: string; amountOut: bigint }[]; best: QuoteResult }> {
    const normalized = normalizePath(path, this.weth);
    if (normalized.length < 2) {
      throw new Error("Path must have at least 2 tokens");
    }

    // If no Bundle flag, fall back to standard routing
    if (!options?.isBundle) {
      return this.findBestExactIn(path, amountIn, recipient);
    }

    const bundleAddress = options.isBundle.token;
    const isBuying = options.isBundle.isBuying;

    // Validate path contains Bundle and WETH
    const bundleIndex = normalized.indexOf(bundleAddress);
    const wethIndex = normalized.indexOf(this.weth);
    if (bundleIndex === -1) {
      throw new Error(`Bundle token ${bundleAddress} not found in path`);
    }
    if (wethIndex === -1) {
      throw new Error("WETH not found in path");
    }

    // Get all BundlesIndexSwapAdapter instances (one per fee tier) for direct route
    const bundlesAdapters = this.adapters.filter(
      (a): a is BundlesIndexSwapAdapter => a instanceof BundlesIndexSwapAdapter
    );

    if (bundlesAdapters.length === 0) {
      throw new Error("BundlesIndexSwapAdapter not registered");
    }

    let directQuote: bigint | null = null;
    let bestDirectAdapter: BundlesIndexSwapAdapter | null = null;
    let indirectQuote: bigint | null = null;
    let indirectBuilder: CalldataBuilder | null = null;
    const nestedBundleRoutes = new Map<Address, { isDirect: boolean; calldata?: Hex; adapter?: DexAdapter; amount?: bigint }>();

    if (isBuying) {
      // Buying Bundle: amountIn = desired Bundle amount (exact-out). Delegate to findBestExactOutWithBundle.
      const exactOutResult = await this.findBestExactOutWithBundle(
        path,
        amountIn,
        recipient,
        options
      );
      return {
        calldata: exactOutResult.calldata,
        quotes: exactOutResult.quotes.map((q) => ({ name: q.name, amountOut: amountIn })),
        best: { adapter: exactOutResult.best.adapter, amountOut: amountIn },
      };
    }
    // Selling Bundle: Bundle -> WETH (buy branch delegated to findBestExactOutWithBundle above)
    {
      // Selling Bundle: Bundle -> WETH
      // Route A: Direct swap via BundlesIndexSwapAdapter
      // Note: Direct quote will be included in RPC Call 2 multicall below
      // We'll get it from the multicall results instead of a separate call

      // Route B: Decompose root + all nested in batch, then one multicall for all scenario quotes
      if (options?.printLogs) {
        console.log(`\n[Selling] Testing indirect route (burn) for ${amountIn.toString()} Bundle tokens`);
        console.log(`[RPC Call 1] Calling Decomposer.sell() + Aave getAllReservesTokens + getAllATokens...`);
      }

      const rpc1SellResults = await this.client.multicall({
        contracts: [
          {
            address: this.contractAddresses.DECOMPOSER_MAINNET,
            abi: decomposerAbi,
            functionName: "sell",
            args: [amountIn, bundleAddress],
          },
          {
            address: this.contractAddresses.AAVE_V3_PROTOCOL_DATA_PROVIDER,
            abi: aaveProtocolDataProviderAbi,
            functionName: "getAllReservesTokens",
          },
          {
            address: this.contractAddresses.AAVE_V3_PROTOCOL_DATA_PROVIDER,
            abi: aaveProtocolDataProviderAbi,
            functionName: "getAllATokens",
          },
        ] as Parameters<PublicClient["multicall"]>[0]["contracts"],
        allowFailure: true,
      });

      // Parse Aave results (indices 1 and 2) — build aToken mapping for sell
      const reservesResultSell = rpc1SellResults[1];
      const aTokensResultSell = rpc1SellResults[2];
      let sellAaveAdapter: AaveV3Adapter | null = null;
      const sellATokensInDecomposition = new Map<string, Address>();
      if (
        reservesResultSell?.status === "success" && reservesResultSell.result &&
        aTokensResultSell?.status === "success" && aTokensResultSell.result
      ) {
        const reserves = reservesResultSell.result as readonly { symbol: string; tokenAddress: Address }[];
        const aTokens = aTokensResultSell.result as readonly { symbol: string; tokenAddress: Address }[];
        const { aTokenToUnderlying, underlyingToAToken } = buildATokenMaps(reserves, aTokens);
        sellAaveAdapter = new AaveV3Adapter(this.contractAddresses.AAVE_V3_POOL, aTokenToUnderlying, underlyingToAToken);

        if (options?.printLogs) {
          console.log(`[RPC Call 1] Loaded ${aTokenToUnderlying.size} Aave aToken mappings`);
        }
      } else {
        if (options?.printLogs) {
          console.log(`[RPC Call 1] Warning: Could not load Aave aToken mappings`);
        }
      }

      // Parse Decomposer result (index 0)
      const decomposerResultEntry = rpc1SellResults[0];
      const decomposerResult = decomposerResultEntry?.status === "success" ? decomposerResultEntry.result : undefined;

      if (!decomposerResult) {
        if (options?.printLogs) {
          console.log(`\n[Selling] Decomposer call returned no result`);
        }
      } else {
        const decomposition = decomposerResult as {
          tokens: readonly { token: Address; amount: bigint; parentAddress: Address }[];
          indexes: readonly { index: Address; amount: bigint; parentAddress: Address }[];
        };

        if (options?.printLogs) {
          console.log(`\n[Selling] Decomposition for ${amountIn.toString()} Bundle tokens:`);
          console.log(`  - Tokens received: ${decomposition.tokens.length}`);
          console.log(`  - Nested bundles: ${decomposition.indexes.length}`);
        }

        // Root decomposition already includes all tokens with parentAddress (root vs nested);
        // we can build the full sell tree from it without extra Decomposer calls.
        const rootDecomp: Decomposition = {
          tokens: decomposition.tokens.map((t) => ({
            token: t.token,
            amount: t.amount,
            parentAddress: t.parentAddress,
          })),
          indexes: decomposition.indexes.map((i) => ({
            index: i.index,
            amount: i.amount,
            parentAddress: i.parentAddress,
          })),
        };
        const sellTree = buildSellTree(rootDecomp, bundleAddress);

        // Build one multicall: direct (main, one per fee tier) + level0 tokens + per-nested (direct + tokens)
        const allQuoteContracts: MulticallContract[] = [];
        type AdapterQuoteEntry = { adapter: BundlesIndexSwapAdapter; index: number };
        const directQuoteEntries: AdapterQuoteEntry[] = [];
        const level0TokenToEntries: TokenQuoteMap = new Map();
        const level0TokenOrder: Address[] = [];
        const nestedMeta: { directEntries: AdapterQuoteEntry[]; tokenToEntries: TokenQuoteMap; tokenOrder: Address[] }[] = [];
        const sellRouteHints = options?.routeHints;

        if (normalized[0] === bundleAddress && normalized[1] === this.weth) {
          for (const adapter of bundlesAdapters) {
            directQuoteEntries.push({ adapter, index: allQuoteContracts.length });
            allQuoteContracts.push(
              adapter.getQuoteExactInContract([bundleAddress, this.weth], amountIn)
            );
          }
          if (options?.printLogs) {
            console.log(`  [Quote] Direct swap (Bundle -> WETH): added ${directQuoteEntries.length} fee tier(s)`);
          }
        }

        const wethLower = this.weth.toLowerCase();
        const shortAddrSell = (a: Address) => `${a.slice(0, 10)}...`;

        const resolveForQuotingSell = (token: Address): Address => {
          if (sellAaveAdapter && sellAaveAdapter.isAToken(token)) {
            const underlying = sellAaveAdapter.getUnderlying(token)!;
            sellATokensInDecomposition.set(token.toLowerCase(), underlying);
            debugLog(`[Aave SELL] Token ${shortAddrSell(token)} is aToken -> quoting underlying ${shortAddrSell(underlying)}`);
            return underlying;
          }
          return token;
        };

        /** Add quote entries for all paths (direct + hinted) for a sell token. */
        const addSellQuoteEntries = (token: Address, quoteToken: Address, amount: bigint): TokenQuoteEntry[] => {
          const entries: TokenQuoteEntry[] = [];
          const paths = buildQuotingPaths(quoteToken, this.weth, sellRouteHints, token);
          for (const quotePath of paths) {
            const applicable = this._getApplicableAdaptersForExactIn(quotePath);
            for (const adapter of applicable) {
              entries.push({ index: allQuoteContracts.length, adapter, path: quotePath });
              allQuoteContracts.push(adapter.getQuoteExactInContract(quotePath, amount));
            }
          }
          return entries;
        };

        for (const [token, amount] of sellTree.level0Tokens) {
          if (token.toLowerCase() === wethLower) continue;
          level0TokenOrder.push(token);
          const quoteToken = resolveForQuotingSell(token);
          const entries = addSellQuoteEntries(token, quoteToken, amount);
          level0TokenToEntries.set(token, entries);
        }
        if (options?.printLogs) {
          console.log(`  [Quote] Level-0 tokens: ${level0TokenOrder.length} tokens, ${allQuoteContracts.length - directQuoteEntries.length} quote(s)`);
        }

        for (let ni = 0; ni < sellTree.nesteds.length; ni++) {
          const nested = sellTree.nesteds[ni]!;
          const directEntries: AdapterQuoteEntry[] = [];
          for (const adapter of bundlesAdapters) {
            directEntries.push({ adapter, index: allQuoteContracts.length });
            allQuoteContracts.push(
              adapter.getQuoteExactInContract([nested.bundle, this.weth], nested.amount)
            );
          }
          const tokenToEntries: TokenQuoteMap = new Map();
          const tokenOrder: Address[] = [];
          for (const [token, amount] of nested.tokens) {
            if (token.toLowerCase() === wethLower) continue;
            tokenOrder.push(token);
            const quoteToken = resolveForQuotingSell(token);
            const entries = addSellQuoteEntries(token, quoteToken, amount);
            tokenToEntries.set(token, entries);
          }
          nestedMeta.push({ directEntries, tokenToEntries, tokenOrder });
        }

        const N = sellTree.nesteds.length;
        const numScenarios = N === 0 ? 2 : 1 + (1 << N);
        // Per-scenario cumulated token amounts (quote once per token with total amount = same slippage).
        const tokenTotalsByScenario = new Map<number, Map<Address, bigint>>();
        for (let s = 1; s < numScenarios; s++) {
          const bits = s - 1;
          const map = new Map<Address, bigint>();
          for (const [token, amt] of sellTree.level0Tokens) {
            const existing = map.get(token) ?? 0n;
            map.set(token, existing + amt);
          }
          for (let j = 0; j < N; j++) {
            if ((bits & (1 << j)) !== 0) {
              const nested = sellTree.nesteds[j]!;
              for (const [token, amt] of nested.tokens) {
                const existing = map.get(token) ?? 0n;
                map.set(token, existing + amt);
              }
            }
          }
          tokenTotalsByScenario.set(s, map);
        }
        const combinedQuoteKeysSell = new Map<string, { token: Address; amount: bigint }>();
        for (const [, tokenMap] of tokenTotalsByScenario) {
          for (const [token, amount] of tokenMap) {
            if (token.toLowerCase() === wethLower) continue;
            const level0Amt = sellTree.level0Tokens.get(token);
            let alreadyHave = level0Amt === amount;
            if (!alreadyHave) {
              for (const nested of sellTree.nesteds) {
                if (nested.tokens.get(token) === amount) {
                  alreadyHave = true;
                  break;
                }
              }
            }
            if (!alreadyHave) {
              const key = `${token.toLowerCase()}_${amount}`;
              if (!combinedQuoteKeysSell.has(key))
                combinedQuoteKeysSell.set(key, { token, amount });
            }
          }
        }
        const combinedQuoteEntriesSell = new Map<string, TokenQuoteEntry[]>();
        for (const { token, amount } of combinedQuoteKeysSell.values()) {
          const quoteToken = resolveForQuotingSell(token);
          const entries = addSellQuoteEntries(token, quoteToken, amount);
          combinedQuoteEntriesSell.set(`${token.toLowerCase()}_${amount}`, entries);
        }

        if (options?.printLogs) {
          console.log(`\n[RPC Call 2] Executing ${allQuoteContracts.length} quote contract(s) in multicall (all scenarios)...`);
        }
        const quoteResults = await this.client.multicall({
          contracts: allQuoteContracts as Parameters<PublicClient["multicall"]>[0]["contracts"],
          allowFailure: true,
        });
        const successCount = quoteResults.filter((r) => r.status === "success").length;
        if (options?.printLogs) {
          console.log(`[RPC Call 2] Completed: ${successCount}/${quoteResults.length} quotes succeeded`);
        }

        /** Resolve (token, amount) to quote entries for sell (exact-in). */
        const getEntriesForTokenAmountSell = (token: Address, amount: bigint): TokenQuoteEntry[] => {
          const level0Amt = sellTree.level0Tokens.get(token);
          if (level0Amt === amount) return level0TokenToEntries.get(token) ?? [];
          for (let ni = 0; ni < N; ni++) {
            if (sellTree.nesteds[ni]!.tokens.get(token) === amount)
              return nestedMeta[ni]!.tokenToEntries.get(token) ?? [];
          }
          return combinedQuoteEntriesSell.get(`${token.toLowerCase()}_${amount}`) ?? [];
        };

        const shortAddr = (a: Address) => `${a.slice(0, 10)}...`;

        let directRootLeg: SellLeg | null = null;
        let scenario0Total = 0n;
        for (const { adapter, index } of directQuoteEntries) {
          const r = quoteResults[index];
          const c = allQuoteContracts[index]!;
          if (r?.status === "success" && r.result !== undefined) {
            const out = parseQuoteExactInResult(adapter, r.result, c);
            if (out !== undefined && out > scenario0Total) {
              scenario0Total = out;
              bestDirectAdapter = adapter;
              directRootLeg = {
                asset: bundleAddress,
                isBundle: true,
                amountIn,
                amountOut: out,
                adapterName: adapter.name,
              };
            }
          }
        }
        directQuote = scenario0Total > 0n ? scenario0Total : null;

        const nestedDirectTotals: bigint[] = [];
        const nestedDirectLegs: SellLeg[] = [];
        const bestNestedAdapters: BundlesIndexSwapAdapter[] = [];
        for (let ni = 0; ni < N; ni++) {
          const meta = nestedMeta[ni]!;
          const nested = sellTree.nesteds[ni]!;
          let nestedDirect = 0n;
          let nestedBestAdapter: BundlesIndexSwapAdapter | null = null;
          for (const { adapter, index } of meta.directEntries) {
            const r = quoteResults[index];
            const c = allQuoteContracts[index]!;
            if (r?.status === "success" && r.result !== undefined) {
              const out = parseQuoteExactInResult(adapter, r.result, c);
              if (out !== undefined && out > nestedDirect) {
                nestedDirect = out;
                nestedBestAdapter = adapter;
              }
            }
          }
          nestedDirectTotals.push(nestedDirect);
          bestNestedAdapters.push(nestedBestAdapter ?? bundlesAdapters[0]!);
          nestedDirectLegs.push({
            asset: nested.bundle,
            isBundle: true,
            amountIn: nested.amount,
            amountOut: nestedDirect,
            adapterName: nestedBestAdapter?.name ?? bundlesAdapters[0]!.name,
          });
        }

        const scenarioTotals: bigint[] = [];
        const scenarioLegs: SellLeg[][] = [];
        scenarioTotals.push(scenario0Total);
        scenarioLegs.push(directRootLeg ? [directRootLeg] : []);
        for (let s = 1; s < numScenarios; s++) {
          const bits = s - 1;
          let total = 0n;
          const legs: SellLeg[] = [];
          let scenarioInvalid = false;
          const tokenMap = tokenTotalsByScenario.get(s)!;
          for (const [token, amount] of tokenMap) {
            if (token.toLowerCase() === wethLower) {
              total += amount;
              legs.push({
                asset: token,
                isBundle: false,
                amountIn: amount,
                amountOut: amount,
                adapterName: "—",
              });
              continue;
            }
            const entries = getEntriesForTokenAmountSell(token, amount);
            let best = 0n;
            let bestAdapterName = "";
            for (const entry of entries) {
              const r = quoteResults[entry.index];
              const c = allQuoteContracts[entry.index];
              if (!r || !c || r.status !== "success" || r.result === undefined) continue;
              const out = parseQuoteExactInResult(entry.adapter, r.result, c);
              if (out !== undefined && out > best) {
                best = out;
                bestAdapterName = entry.adapter.name;
              }
            }
            if (best === 0n && bestAdapterName === "") {
              scenarioInvalid = true;
            }
            total += best;
            legs.push({
              asset: token,
              isBundle: false,
              amountIn: amount,
              amountOut: best,
              adapterName: bestAdapterName,
            });
          }
          for (let j = 0; j < N; j++) {
            const useDirect = (bits & (1 << j)) === 0;
            if (useDirect) {
              if (nestedDirectTotals[j]! === 0n) {
                scenarioInvalid = true;
              }
              total += nestedDirectTotals[j]!;
              legs.push(nestedDirectLegs[j]!);
            }
          }
          if (scenarioInvalid) {
            total = 0n;
          }
          scenarioTotals.push(total);
          scenarioLegs.push(legs);
        }

        let bestIdx = 0;
        let bestScenarioTotal = scenarioTotals[0] ?? 0n;
        for (let s = 1; s < numScenarios; s++) {
          const t = scenarioTotals[s] ?? 0n;
          if (t > bestScenarioTotal) {
            bestScenarioTotal = t;
            bestIdx = s;
          }
        }
        indirectQuote = bestScenarioTotal > 0n ? bestScenarioTotal : null;

        if (options?.printLogs) {
          console.log(`\nSell scenarios (from tree)`);
          for (let s = 0; s < numScenarios; s++) {
            const legs = scenarioLegs[s] ?? [];
            const total = scenarioTotals[s] ?? 0n;
            console.log(`Scenario ${s}:`);
            for (const leg of legs) {
              const kind = leg.isBundle ? "Bundle" : "Token";
              console.log(`  ${kind} ${shortAddr(leg.asset)}  ${leg.amountIn.toString()} → ${leg.amountOut.toString()} WETH  ${leg.adapterName}`);
            }
            console.log(`  Total: ${total.toString()} WETH`);
          }
          console.log(`Best scenario: index ${bestIdx} — ${bestScenarioTotal.toString()} WETH`);
        }

        if (indirectQuote !== null && bestIdx >= 1) {
          const bits = bestIdx - 1;
          for (let ni = 0; ni < N; ni++) {
            const nested = sellTree.nesteds[ni]!;
            const useDirect = (bits & (1 << ni)) === 0;
            nestedBundleRoutes.set(nested.bundle, {
              isDirect: useDirect,
              adapter: useDirect ? bestNestedAdapters[ni] : undefined,
              amount: nested.amount,
            });
          }
          const bundleCalldataBuilder = new BundleCalldataBuilder(this.client, this.contractAddresses, this.adapters);
          indirectBuilder = await bundleCalldataBuilder.buildIndirectSellCalldata(
            bundleAddress,
            amountIn,
            decomposition,
            recipient,
            nestedBundleRoutes,
            sellAaveAdapter ?? undefined,
            sellATokensInDecomposition,
            sellRouteHints
          );
        }
      }
    }

    // Compare routes and select best
    const quotes: { name: string; amountOut: bigint }[] = [];
    let best: QuoteResult | null = null;

    if (directQuote !== null && directQuote > 0n && bestDirectAdapter) {
      quotes.push({ name: `${bestDirectAdapter.name} (direct)`, amountOut: directQuote });
      const directResult: QuoteResult = {
        adapter: bestDirectAdapter,
        amountOut: directQuote,
      };
      if (best === null) {
        best = directResult;
      } else {
        if (directQuote > (best as QuoteResult).amountOut) {
          best = directResult;
        }
      }
    }

    if (indirectQuote !== null && indirectQuote > 0n) {
      const routeName = isBuying ? "Mint (indirect)" : "Burn (indirect)";
      quotes.push({ name: routeName, amountOut: indirectQuote });
      const shouldUseIndirect = best === null || indirectQuote > (best as QuoteResult).amountOut;
      if (shouldUseIndirect) {
        const indirectAdapter: DexAdapter = {
          name: routeName,
          quoteExactIn: async () => indirectQuote!,
          quoteExactOut: async () => 0n,
          getQuoteExactInContract: () => ({
            address: bundleAddress,
            abi: [],
            functionName: "",
          }),
          getQuoteExactOutContract: () => ({
            address: bundleAddress,
            abi: [],
            functionName: "",
          }),
          buildExactIn: () => { },
          buildExactOut: () => { },
        };
        best = {
          adapter: indirectAdapter,
          amountOut: indirectQuote,
        };
      }
    }

    if (best === null) {
      throw new Error("No successful quote from any route");
    }

    // Build calldata for best route
    let builder: CalldataBuilder;
    if (bestDirectAdapter && best.adapter === bestDirectAdapter && directQuote !== null) {
      // Direct route via the winning fee tier
      builder = new CalldataBuilder(this.contractAddresses.RECIPIENT_PLACEHOLDER);
      bestDirectAdapter.buildExactIn(builder, normalized, amountIn, recipient);
    } else if (indirectBuilder) {
      // Indirect route - use the pre-built builder
      builder = indirectBuilder;
    } else {
      throw new Error("Failed to build calldata for selected route");
    }

    // Extract required approvals and check current allowances
    const requiredApprovals = builder.getRequiredApprovals();
    if (requiredApprovals.size > 0) {
      const allowances = await this.checkAllowances(requiredApprovals, this.contractAddresses.UNIVERSAL_ROUTER);
      this.filterUnnecessaryApprovals(builder, allowances, requiredApprovals, false); // exact-in, no buffer needed
    }

    const calldata = builder.encodeForUniversalRouter(this.contractAddresses.UNIVERSAL_ROUTER);

    return { calldata, quotes, best };
  }

  /**
   * Find best exact-out route with Bundle support.
   * Similar to findBestExactInWithBundle but for exact-out swaps.
   */
  async findBestExactOutWithBundle(
    path: (Address | "ETH")[],
    amountOut: bigint,
    recipient: Address,
    options?: {
      isBundle?: { token: Address; isBuying: boolean },
      printLogs?: boolean,
      routeHints?: RouteHints
    },
  ): Promise<{
    calldata: Hex;
    quotes: { name: string; amountIn: bigint }[];
    best: QuoteResultExactOut;
    scenarios?: {
      numScenarios: number;
      scenarioTotals: bigint[];
      scenarioLegs: SellLeg[][];
      scenarioWinningEntries: Map<Address, TokenQuoteEntry>[];
      decomposition: {
        tokens: readonly { token: Address; amount: bigint; parentAddress: Address }[];
        indexes: readonly { index: Address; amount: bigint; parentAddress: Address }[];
      };
      buyTree: ReturnType<typeof buildBuyTree>;
      quoteResults: Awaited<ReturnType<PublicClient["multicall"]>>;
      allQuoteContracts: MulticallContract[];
      nestedMeta: { directEntries: { adapter: BundlesIndexSwapAdapter; index: number }[]; tokenToEntries: TokenQuoteMap; tokenOrder: Address[] }[];
      level0TokenToEntries: TokenQuoteMap;
      combinedQuoteEntries: Map<string, TokenQuoteEntry[]>;
      directQuoteEntries: { adapter: BundlesIndexSwapAdapter; index: number }[];
      bestDirectAdapter: BundlesIndexSwapAdapter | null;
      bestNestedAdapters: BundlesIndexSwapAdapter[];
      aaveAdapter?: AaveV3Adapter;
      aTokensInDecomposition?: Map<string, Address>;
      routeHints?: RouteHints;
    };
  }> {
    const normalized = normalizePath(path, this.weth);
    if (normalized.length < 2) {
      throw new Error("Path must have at least 2 tokens");
    }

    // If no Bundle flag, fall back to standard routing
    if (!options?.isBundle) {
      return this.findBestExactOut(path, amountOut, recipient);
    }

    const bundleAddress = options.isBundle.token;
    const isBuying = options.isBundle.isBuying;

    // Validate path contains Bundle and WETH
    const bundleIndex = normalized.indexOf(bundleAddress);
    const wethIndex = normalized.indexOf(this.weth);
    if (bundleIndex === -1) {
      throw new Error(`Bundle token ${bundleAddress} not found in path`);
    }
    if (wethIndex === -1) {
      throw new Error("WETH not found in path");
    }

    // Get all BundlesIndexSwapAdapter instances (one per fee tier) for direct route
    const bundlesAdapters = this.adapters.filter(
      (a): a is BundlesIndexSwapAdapter => a instanceof BundlesIndexSwapAdapter
    );

    if (bundlesAdapters.length === 0) {
      throw new Error("BundlesIndexSwapAdapter not registered");
    }

    let directQuote: bigint | null = null;
    let bestDirectAdapter: BundlesIndexSwapAdapter | null = null;
    let indirectQuote: bigint | null = null;
    let indirectBuilder: CalldataBuilder | null = null;

    const nestedBundleRoutes = new Map<
      Address,
      { isDirect: boolean; calldata?: Hex; adapter?: DexAdapter; amount?: bigint }
    >();

    // Scenario data for buy operations (declared at function scope)
    let numScenarios = 0;
    let scenarioTotals: bigint[] = [];
    let scenarioLegs: SellLeg[][] = [];
    let scenarioWinningEntries: Map<Address, TokenQuoteEntry>[] = [];
    let decomposition: {
      tokens: readonly { token: Address; amount: bigint; parentAddress: Address }[];
      indexes: readonly { index: Address; amount: bigint; parentAddress: Address }[];
    } | null = null;
    let buyTree: ReturnType<typeof buildBuyTree> | null = null;
    type MulticallResultElement = { status: "success"; result: unknown } | { status: "failure"; error: Error };
    let quoteResults: MulticallResultElement[] = [];
    let allQuoteContracts: MulticallContract[] = [];
    let nestedMeta: { directEntries: { adapter: BundlesIndexSwapAdapter; index: number }[]; tokenToEntries: TokenQuoteMap; tokenOrder: Address[] }[] = [];
    let level0TokenToEntries: TokenQuoteMap = new Map();
    let combinedQuoteEntries: Map<string, TokenQuoteEntry[]> = new Map();
    let directQuoteEntries: { adapter: BundlesIndexSwapAdapter; index: number }[] = [];
    let bestNestedAdapters: BundlesIndexSwapAdapter[] = [];

    // Aave V3 aToken mapping (populated in RPC Call 1 for both BUY and SELL)
    let aaveAdapter: AaveV3Adapter | null = null;
    /** Maps aToken (lowercase) -> underlying (checksummed) for tokens found in the decomposition */
    let aTokensInDecomposition = new Map<string, Address>();

    if (isBuying) {
      // Buying Bundle (exact-out): WETH -> Bundle. One decomposition, one multicall, all scenarios.
      if (options?.printLogs) {
        console.log(`\n[Buying] Testing routes for ${amountOut.toString()} Bundle tokens (exact-out)`);
        console.log(`[RPC Call 1] Calling Decomposer.buy() + Aave getAllReservesTokens + getAllATokens...`);
      }

      const rpc1Results = await this.client.multicall({
        contracts: [
          {
            address: this.contractAddresses.DECOMPOSER_MAINNET,
            abi: decomposerAbi,
            functionName: "buy",
            args: [amountOut, bundleAddress],
          },
          {
            address: this.contractAddresses.AAVE_V3_PROTOCOL_DATA_PROVIDER,
            abi: aaveProtocolDataProviderAbi,
            functionName: "getAllReservesTokens",
          },
          {
            address: this.contractAddresses.AAVE_V3_PROTOCOL_DATA_PROVIDER,
            abi: aaveProtocolDataProviderAbi,
            functionName: "getAllATokens",
          },
        ] as Parameters<PublicClient["multicall"]>[0]["contracts"],
        allowFailure: true,
      });

      // Parse Aave results (indices 1 and 2) — build aToken mapping
      const reservesResult = rpc1Results[1];
      const aTokensResult = rpc1Results[2];
      if (
        reservesResult?.status === "success" && reservesResult.result &&
        aTokensResult?.status === "success" && aTokensResult.result
      ) {
        const reserves = reservesResult.result as readonly { symbol: string; tokenAddress: Address }[];
        const aTokens = aTokensResult.result as readonly { symbol: string; tokenAddress: Address }[];
        const { aTokenToUnderlying, underlyingToAToken } = buildATokenMaps(reserves, aTokens);
        aaveAdapter = new AaveV3Adapter(this.contractAddresses.AAVE_V3_POOL, aTokenToUnderlying, underlyingToAToken);

        if (options?.printLogs) console.log(`[RPC Call 1] Loaded ${aTokenToUnderlying.size} Aave aToken mappings`);
      } else {
        if (options?.printLogs) console.log(`[RPC Call 1] Warning: Could not load Aave aToken mappings`);
      }

      // Parse Decomposer result (index 0)
      const decomposerResultEntry = rpc1Results[0];
      const decomposerResult = decomposerResultEntry?.status === "success" ? decomposerResultEntry.result : undefined;

      if (!decomposerResult) {
        if (options?.printLogs) console.log(`[Buying] Decomposer.buy() returned no result`);
      } else {
        decomposition = decomposerResult as {
          tokens: readonly { token: Address; amount: bigint; parentAddress: Address }[];
          indexes: readonly { index: Address; amount: bigint; parentAddress: Address }[];
        };

        const rootDecomp: Decomposition = {
          tokens: decomposition.tokens.map((t) => ({
            token: t.token,
            amount: t.amount,
            parentAddress: t.parentAddress,
          })),
          indexes: decomposition.indexes.map((i) => ({
            index: i.index,
            amount: i.amount,
            parentAddress: i.parentAddress,
          })),
        };
        buyTree = buildBuyTree(rootDecomp, bundleAddress);

        const MIN_MINT_TOKEN_AMOUNT = 1000n;

        let rootMintHasDust = false;
        for (const [, amount] of buyTree!.level0Tokens) {
          if (amount < MIN_MINT_TOKEN_AMOUNT) { rootMintHasDust = true; break; }
        }
        if (!rootMintHasDust) {
          for (const nested of buyTree!.nesteds) {
            if (nested.amount < MIN_MINT_TOKEN_AMOUNT) { rootMintHasDust = true; break; }
          }
        }

        const nestedMintHasDust: boolean[] = buyTree!.nesteds.map(nested => {
          for (const [, amount] of nested.tokens) {
            if (amount < MIN_MINT_TOKEN_AMOUNT) return true;
          }
          return false;
        });

        const wethLower = this.weth.toLowerCase();
        const shortAddr = (a: Address) => `${a.slice(0, 10)}...`;

        const allQuoteContracts: MulticallContract[] = [];
        type AdapterQuoteEntry = { adapter: BundlesIndexSwapAdapter; index: number };
        const directQuoteEntries: AdapterQuoteEntry[] = [];
        const level0TokenToEntries: TokenQuoteMap = new Map();
        const level0TokenOrder: Address[] = [];
        const nestedMeta: { directEntries: AdapterQuoteEntry[]; tokenToEntries: TokenQuoteMap; tokenOrder: Address[] }[] = [];
        const buyRouteHints = options?.routeHints;

        if (normalized[0] === this.weth && normalized[1] === bundleAddress) {
          for (const adapter of bundlesAdapters) {
            directQuoteEntries.push({ adapter, index: allQuoteContracts.length });
            allQuoteContracts.push(
              adapter.getQuoteExactOutContract([this.weth, bundleAddress], amountOut)
            );
          }
        }

        const resolveForQuoting = (token: Address): Address => {
          if (aaveAdapter && aaveAdapter.isAToken(token)) {
            const underlying = aaveAdapter.getUnderlying(token)!;
            aTokensInDecomposition.set(token.toLowerCase(), underlying);
            debugLog(`[Aave] Token ${shortAddr(token)} is aToken -> quoting underlying ${shortAddr(underlying)}`);
            return underlying;
          }
          return token;
        };

        /** Add quote entries for all paths (direct + hinted) for a buy token (exact-out). */
        const addBuyQuoteEntries = (token: Address, quoteToken: Address, amount: bigint): TokenQuoteEntry[] => {
          const entries: TokenQuoteEntry[] = [];
          const paths = buildQuotingPaths(this.weth, quoteToken, buyRouteHints, token);
          if (options?.printLogs && paths.length > 1) {
            console.log(`[Hint] ${shortAddr(token)}: ${paths.length} paths generated`);
            for (const p of paths) {
              console.log(`  path: [${p.map(a => shortAddr(a)).join(" → ")}]`);
            }
          }
          for (const quotePath of paths) {
            const applicable = this._getApplicableAdaptersForExactOut(quotePath);
            for (const adapter of applicable) {
              entries.push({ index: allQuoteContracts.length, adapter, path: quotePath });
              allQuoteContracts.push(adapter.getQuoteExactOutContract(quotePath, amount));
            }
            if (options?.printLogs && paths.length > 1) {
              console.log(`  path [${quotePath.map(a => shortAddr(a)).join(" → ")}]: ${applicable.length} adapters (${applicable.map(a => a.name).join(", ")})`);
            }
          }
          return entries;
        };

        for (const [token, amount] of buyTree!.level0Tokens) {
          if (token.toLowerCase() === wethLower) continue;
          level0TokenOrder.push(token);
          const quoteToken = resolveForQuoting(token);
          const entries = addBuyQuoteEntries(token, quoteToken, amount);
          level0TokenToEntries.set(token, entries);
        }

        for (let ni = 0; ni < buyTree!.nesteds.length; ni++) {
          const nested = buyTree!.nesteds[ni]!;
          const directEntries: AdapterQuoteEntry[] = [];
          for (const adapter of bundlesAdapters) {
            directEntries.push({ adapter, index: allQuoteContracts.length });
            allQuoteContracts.push(
              adapter.getQuoteExactOutContract([this.weth, nested.bundle], nested.amount)
            );
          }
          const tokenToEntries: TokenQuoteMap = new Map();
          const tokenOrder: Address[] = [];
          for (const [token, amount] of nested.tokens) {
            if (token.toLowerCase() === wethLower) continue;
            tokenOrder.push(token);
            const quoteToken = resolveForQuoting(token);
            const entries = addBuyQuoteEntries(token, quoteToken, amount);
            tokenToEntries.set(token, entries);
          }
          nestedMeta.push({ directEntries, tokenToEntries, tokenOrder });
        }

        const N = buyTree!.nesteds.length;
        numScenarios = N === 0 ? 2 : 1 + (1 << N);
        // Per-scenario cumulated token amounts (so we quote once per token with total amount = same slippage).
        const tokenTotalsByScenario = new Map<number, Map<Address, bigint>>();
        for (let s = 1; s < numScenarios; s++) {
          const bits = s - 1;
          const map = new Map<Address, bigint>();
          for (const [token, amt] of buyTree!.level0Tokens) {
            const existing = map.get(token) ?? 0n;
            map.set(token, existing + amt);
          }
          for (let j = 0; j < N; j++) {
            if ((bits & (1 << j)) !== 0) {
              const nested = buyTree!.nesteds[j]!;
              for (const [token, amt] of nested.tokens) {
                const existing = map.get(token) ?? 0n;
                map.set(token, existing + amt);
              }
            }
          }
          tokenTotalsByScenario.set(s, map);
        }
        // Combined (token, amount) that we need to quote: only when amount is not already a single leg (level0 or one nested).
        const combinedQuoteKeys = new Map<string, { token: Address; amount: bigint }>();
        for (const [scenarioNum, tokenMap] of tokenTotalsByScenario) {
          for (const [token, amount] of tokenMap) {
            if (token.toLowerCase() === wethLower) continue;
            const level0Amt = buyTree!.level0Tokens.get(token);
            let alreadyHave = level0Amt === amount;
            if (!alreadyHave) {
              for (const nested of buyTree!.nesteds) {
                if (nested.tokens.get(token) === amount) {
                  alreadyHave = true;
                  break;
                }
              }
            }
            if (!alreadyHave) {
              const key = `${token.toLowerCase()}_${amount}`;
              if (!combinedQuoteKeys.has(key)) {
                const tokenShort = `${token.slice(0, 10)}...`;
                debugLog(`[DEBUG] Creating combined quote for token ${tokenShort}: amount ${amount.toString()} (level0=${level0Amt?.toString() ?? 'none'}, scenario=${scenarioNum})`);
                combinedQuoteKeys.set(key, { token, amount });
              }
            }
          }
        }
        combinedQuoteEntries.clear();
        for (const { token, amount } of combinedQuoteKeys.values()) {
          const quoteToken = resolveForQuoting(token);
          const entries = addBuyQuoteEntries(token, quoteToken, amount);
          combinedQuoteEntries.set(`${token.toLowerCase()}_${amount}`, entries);
        }

        if (options?.printLogs) console.log(`[RPC Call 2] Executing ${allQuoteContracts.length} quote contract(s) in multicall (exact-out)...`);
        quoteResults = (await this.client.multicall({
          contracts: allQuoteContracts as Parameters<PublicClient["multicall"]>[0]["contracts"],
          allowFailure: true,
        })) as MulticallResultElement[];
        const successCount = quoteResults.filter((r) => r.status === "success").length;
        if (options?.printLogs) console.log(`[RPC Call 2] Completed: ${successCount}/${quoteResults.length} quotes succeeded`);

        /** Resolve (token, amount) to quote entries (one per adapter+path). */
        const getEntriesForTokenAmount = (token: Address, amount: bigint): TokenQuoteEntry[] => {
          const level0Amt = buyTree!.level0Tokens.get(token);
          if (level0Amt === amount) {
            const entries = level0TokenToEntries.get(token) ?? [];
            debugLog(`[DEBUG getEntries] Token ${shortAddr(token)} amount ${amount.toString()}: using level0 entries [${entries.map(e => e.index).join(',')}]`);
            return entries;
          }
          for (let ni = 0; ni < N; ni++) {
            const nestedAmt = buyTree!.nesteds[ni]!.tokens.get(token);
            if (nestedAmt === amount) {
              const entries = nestedMeta[ni]!.tokenToEntries.get(token) ?? [];
              debugLog(`[DEBUG getEntries] Token ${shortAddr(token)} amount ${amount.toString()}: using nested[${ni}] entries [${entries.map(e => e.index).join(',')}]`);
              return entries;
            }
          }
          const combinedKey = `${token.toLowerCase()}_${amount}`;
          const entries = combinedQuoteEntries.get(combinedKey) ?? [];
          debugLog(`[DEBUG getEntries] Token ${shortAddr(token)} amount ${amount.toString()}: using combined entries [${entries.map(e => e.index).join(',')}] (key=${combinedKey})`);
          return entries;
        };

        let directRootLeg: SellLeg | null = null;
        let scenario0Total = 0n;
        for (const { adapter, index } of directQuoteEntries) {
          const r = quoteResults[index];
          const c = allQuoteContracts[index]!;
          if (r?.status === "success" && r.result !== undefined) {
            const wethIn = parseQuoteExactOutResult(adapter, r.result, c);
            if (wethIn !== undefined && (scenario0Total === 0n || wethIn < scenario0Total)) {
              scenario0Total = wethIn;
              bestDirectAdapter = adapter;
              directRootLeg = {
                asset: bundleAddress,
                isBundle: true,
                amountIn: wethIn,
                amountOut,
                adapterName: adapter.name,
              };
            }
          }
        }
        directQuote = scenario0Total > 0n ? scenario0Total : null;

        const nestedDirectTotals: bigint[] = [];
        const nestedDirectLegs: SellLeg[] = [];
        const bestNestedAdapters: BundlesIndexSwapAdapter[] = [];
        for (let ni = 0; ni < N; ni++) {
          const meta = nestedMeta[ni]!;
          const nested = buyTree.nesteds[ni]!;
          let nestedDirect = 0n;
          let nestedBestAdapter: BundlesIndexSwapAdapter | null = null;
          for (const { adapter, index } of meta.directEntries) {
            const r = quoteResults[index];
            const c = allQuoteContracts[index]!;
            if (r?.status === "success" && r.result !== undefined) {
              const wethIn = parseQuoteExactOutResult(adapter, r.result, c);
              if (wethIn !== undefined && (nestedDirect === 0n || wethIn < nestedDirect)) {
                nestedDirect = wethIn;
                nestedBestAdapter = adapter;
              }
            }
          }
          nestedDirectTotals.push(nestedDirect);
          bestNestedAdapters.push(nestedBestAdapter ?? bundlesAdapters[0]!);
          nestedDirectLegs.push({
            asset: nested.bundle,
            isBundle: true,
            amountIn: nestedDirect,
            amountOut: nested.amount,
            adapterName: nestedBestAdapter?.name ?? bundlesAdapters[0]!.name,
          });
        }

        scenarioTotals = [];
        scenarioLegs = [];
        scenarioWinningEntries = [];
        scenarioTotals.push(scenario0Total);
        scenarioLegs.push(directRootLeg ? [directRootLeg] : []);
        scenarioWinningEntries.push(new Map());
        for (let s = 1; s < numScenarios; s++) {
          const bits = s - 1;
          let total = 0n;
          const legs: SellLeg[] = [];
          const winningEntries = new Map<Address, TokenQuoteEntry>();
          let scenarioInvalid = false;
          if (rootMintHasDust) {
            debugLog(`[DEBUG Scenario ${s}] INVALIDATED - root mint has underlying amount < ${MIN_MINT_TOKEN_AMOUNT}`);
            scenarioInvalid = true;
          }
          const tokenMap = tokenTotalsByScenario.get(s)!;
          for (const [token, amount] of tokenMap) {
            if (token.toLowerCase() === wethLower) {
              total += amount;
              legs.push({
                asset: token,
                isBundle: false,
                amountIn: amount,
                amountOut: amount,
                adapterName: "—",
              });
              continue;
            }
            const entries = getEntriesForTokenAmount(token, amount);

            const level0Amt = buyTree!.level0Tokens.get(token);
            const nestedAmts = buyTree!.nesteds.map(n => n.tokens.get(token)).filter(a => a !== undefined);
            debugLog(`[DEBUG Scenario ${s}] Token ${shortAddr(token)}: need ${amount.toString()}, level0=${level0Amt?.toString() ?? 'none'}, nested=${nestedAmts.map(a => a!.toString()).join(',')}, entries=[${entries.map(e => e.index).join(',')}]`);

            let bestWeth = 0n;
            let bestAdapterName = "";
            let bestEntry: TokenQuoteEntry | null = null;
            for (const entry of entries) {
              const r = quoteResults[entry.index];
              const c = allQuoteContracts[entry.index];
              if (!r || !c || r.status !== "success" || r.result === undefined) {
                debugLog(`[DEBUG Scenario ${s}] Token ${shortAddr(token)}: quote index ${entry.index} failed or undefined`);
                continue;
              }
              const wethIn = parseQuoteExactOutResult(entry.adapter, r.result, c);
              debugLog(`[DEBUG Scenario ${s}] Token ${shortAddr(token)}: adapter ${entry.adapter.name} path=[${entry.path.map(p => shortAddr(p)).join(',')}], quoted ${wethIn?.toString() ?? 'undefined'} WETH for ${amount.toString()} tokens`);
              if (wethIn !== undefined && (bestWeth === 0n || wethIn < bestWeth)) {
                bestWeth = wethIn;
                bestAdapterName = entry.adapter.name;
                bestEntry = entry;
              }
            }
            debugLog(`[DEBUG Scenario ${s}] Token ${shortAddr(token)}: best quote = ${bestWeth.toString()} WETH from ${bestAdapterName || 'none'}`);
            if (bestWeth === 0n && bestAdapterName === "") {
              debugLog(`[DEBUG Scenario ${s}] Token ${shortAddr(token)}: FAILED - no successful quotes from any router`);
              scenarioInvalid = true;
            }
            if (bestEntry) {
              winningEntries.set(token, bestEntry);
            }
            total += bestWeth;
            legs.push({
              asset: token,
              isBundle: false,
              amountIn: bestWeth,
              amountOut: amount,
              adapterName: bestAdapterName,
            });
          }
          for (let j = 0; j < N; j++) {
            const useDirect = (bits & (1 << j)) === 0;
            if (useDirect) {
              if (nestedDirectTotals[j]! === 0n) {
                debugLog(`[DEBUG Scenario ${s}] Nested bundle ${shortAddr(buyTree!.nesteds[j]!.bundle)}: direct quote is 0 -> scenario invalid`);
                scenarioInvalid = true;
              }
              total += nestedDirectTotals[j]!;
              legs.push(nestedDirectLegs[j]!);
            } else if (nestedMintHasDust[j]) {
              debugLog(`[DEBUG Scenario ${s}] Nested ${shortAddr(buyTree!.nesteds[j]!.bundle)} mint has underlying amount < ${MIN_MINT_TOKEN_AMOUNT}`);
              scenarioInvalid = true;
            }
          }
          if (scenarioInvalid) {
            debugLog(`[DEBUG Scenario ${s}] INVALIDATED - at least one token/bundle failed to get quotes`);
            total = 0n;
          }
          scenarioTotals.push(total);
          scenarioLegs.push(legs);
          scenarioWinningEntries.push(winningEntries);
        }

        let bestIdx = 0;
        const scenario0TotalValue = scenarioTotals[0] ?? 0n;
        let bestScenarioTotal = scenario0TotalValue > 0n ? scenario0TotalValue : 2n ** 256n - 1n;
        for (let s = 0; s < numScenarios; s++) {
          const t = scenarioTotals[s] ?? 2n ** 256n - 1n;
          if (t > 0n && t < bestScenarioTotal) {
            bestScenarioTotal = t;
            bestIdx = s;
          }
        }
        indirectQuote = bestScenarioTotal > 0n ? bestScenarioTotal : null;

        if (options?.printLogs) console.log(`\nBuy scenarios (from tree)`);
        for (let s = 0; s < numScenarios; s++) {
          const legs = scenarioLegs[s] ?? [];
          const total = scenarioTotals[s] ?? 0n;
          if (options?.printLogs) console.log(`Scenario ${s}:`);
          for (const leg of legs) {
            const kind = leg.isBundle ? "Bundle" : "Token";
            if (options?.printLogs) console.log(`  ${kind} ${shortAddr(leg.asset)}  ${leg.amountOut.toString()} out → ${leg.amountIn.toString()} WETH  ${leg.adapterName}`);
          }
          if (options?.printLogs) console.log(`  Total: ${total.toString()} WETH`);
        }
        if (options?.printLogs) console.log(`Best scenario: index ${bestIdx} — ${bestScenarioTotal.toString()} WETH`);

        if (indirectQuote !== null && bestIdx >= 1) {
          const bits = bestIdx - 1;
          for (let ni = 0; ni < N; ni++) {
            const nested = buyTree!.nesteds[ni]!;
            const useDirect = (bits & (1 << ni)) === 0;
            nestedBundleRoutes.set(nested.bundle, {
              isDirect: useDirect,
              adapter: useDirect ? bestNestedAdapters[ni] : undefined,
              amount: nested.amount,
            });
          }

          // Extract adapter selections with winning path from best scenario
          const tokenAdapterSelections = new Map<Address, TokenAdapterSelection>();
          const bestWinningEntries = scenarioWinningEntries[bestIdx];
          const bestLegs = scenarioLegs[bestIdx] ?? [];
          for (const leg of bestLegs) {
            if (!leg.isBundle && leg.adapterName !== "" && leg.adapterName !== "—") {
              const entry = bestWinningEntries?.get(leg.asset);
              if (entry) {
                tokenAdapterSelections.set(leg.asset, {
                  adapter: entry.adapter,
                  quotedAmountIn: leg.amountIn,
                  path: entry.path
                });
              }
            }
          }

          const bundleCalldataBuilder = new BundleCalldataBuilder(this.client, this.contractAddresses, this.adapters);
          indirectBuilder = await bundleCalldataBuilder.buildIndirectBuyCalldata(
            bundleAddress,
            amountOut,
            decomposition,
            recipient,
            nestedBundleRoutes,
            tokenAdapterSelections,
            aaveAdapter ?? undefined,
            aTokensInDecomposition.size > 0 ? aTokensInDecomposition : undefined,
            buyRouteHints
          );
        }
      }
    } else {
      // Selling Bundle (exact-out): Bundle -> WETH
      // This is more complex - we need to find minimum Bundle amount to burn
      // to get amountOut WETH. For now, use iterative calculation.
      let testBundleAmount = amountOut;
      let iterations = 0;
      const maxIterations = 10;

      // Route A: Direct swap (try all fee tiers, pick lowest cost)
      if (normalized[0] === bundleAddress && normalized[1] === this.weth) {
        for (const adapter of bundlesAdapters) {
          try {
            const quote = await adapter.quoteExactOut(
              [bundleAddress, this.weth],
              amountOut
            );
            if (quote > 0n && (directQuote === null || quote < directQuote)) {
              directQuote = quote;
              bestDirectAdapter = adapter;
            }
          } catch {
            // This fee tier may not be available
          }
        }
      }

      // Route B: Use Decomposer to get all tokens and nested bundles from burn
      // On the first iteration, also fetch Aave aToken mappings via multicall
      let sellAaveLoaded = false;
      while (iterations < maxIterations) {
        // Build multicall: Decomposer.sell() + (on first iteration) Aave data
        const quoteContracts: MulticallContract[] = [];

        // Add Decomposer.sell() call (index 0)
        quoteContracts.push({
          address: this.contractAddresses.DECOMPOSER_MAINNET,
          abi: decomposerAbi,
          functionName: "sell",
          args: [testBundleAmount, bundleAddress],
        });

        // On first iteration, also fetch Aave aToken mappings (indices 1, 2)
        if (!sellAaveLoaded) {
          quoteContracts.push({
            address: this.contractAddresses.AAVE_V3_PROTOCOL_DATA_PROVIDER,
            abi: aaveProtocolDataProviderAbi as readonly unknown[],
            functionName: "getAllReservesTokens",
          });
          quoteContracts.push({
            address: this.contractAddresses.AAVE_V3_PROTOCOL_DATA_PROVIDER,
            abi: aaveProtocolDataProviderAbi as readonly unknown[],
            functionName: "getAllATokens",
          });
        }

        // Execute multicall to get decomposition (+ Aave data on first iteration)
        const results = await this.client.multicall({
          contracts: quoteContracts as Parameters<PublicClient["multicall"]>[0]["contracts"],
          allowFailure: true,
        });

        // Parse Aave results on first iteration
        if (!sellAaveLoaded) {
          const reservesResult = results[1];
          const aTokensResult = results[2];
          if (
            reservesResult?.status === "success" && reservesResult.result &&
            aTokensResult?.status === "success" && aTokensResult.result
          ) {
            const reserves = reservesResult.result as readonly { symbol: string; tokenAddress: Address }[];
            const aTokens = aTokensResult.result as readonly { symbol: string; tokenAddress: Address }[];
            const { aTokenToUnderlying, underlyingToAToken } = buildATokenMaps(reserves, aTokens);
            aaveAdapter = new AaveV3Adapter(this.contractAddresses.AAVE_V3_POOL, aTokenToUnderlying, underlyingToAToken);
            if (options?.printLogs) console.log(`[SELL RPC Call] Loaded ${aTokenToUnderlying.size} Aave aToken mappings`);
          }
          sellAaveLoaded = true;
        }

        const decomposerResult = results[0];
        if (decomposerResult?.status !== "success" || !decomposerResult?.result) {
          break;
        }

        const decomposition = decomposerResult.result as {
          tokens: readonly { token: Address; amount: bigint; parentAddress: Address }[];
          indexes: readonly { index: Address; amount: bigint; parentAddress: Address }[];
        };

        // Aggregate token amounts
        const tokenAmounts = new Map<Address, bigint>();
        for (const tokenAmount of decomposition.tokens) {
          const existing = tokenAmounts.get(tokenAmount.token) || 0n;
          tokenAmounts.set(tokenAmount.token, existing + tokenAmount.amount);
        }

        // Track which tokens are aTokens (for sell: we'll withdraw underlying then sell it)
        const sellATokenMap = new Map<string, Address>(); // aToken(lower) -> underlying
        if (aaveAdapter) {
          for (const [token] of tokenAmounts) {
            if (aaveAdapter.isAToken(token)) {
              sellATokenMap.set(token.toLowerCase(), aaveAdapter.getUnderlying(token)!);
            }
          }
        }

        // Build quote calls for all tokens
        const tokenQuoteContracts: MulticallContract[] = [];
        let totalWETHReceived = 0n;

        // Quote selling each token for WETH (exact-in)
        // For aTokens, quote selling the underlying instead (after withdraw)
        for (const [token, amount] of tokenAmounts) {
          if (token.toLowerCase() === this.weth.toLowerCase()) {
            totalWETHReceived += amount;
            continue;
          }
          const sellToken = sellATokenMap.get(token.toLowerCase()) ?? token;
          const tokenPath: Address[] = [sellToken, this.weth];
          const applicable = this.adapters.filter((a) =>
            canAdapterHandleExactIn(a, tokenPath)
          );
          for (const adapter of applicable) {
            tokenQuoteContracts.push(
              adapter.getQuoteExactInContract(tokenPath, amount)
            );
          }
        }

        // Quote selling each nested bundle for WETH (exact-in)
        for (const indexEntry of decomposition.indexes) {
          const bundlePath: Address[] = [indexEntry.index, this.weth];
          const applicable = this.adapters.filter((a) =>
            canAdapterHandleExactIn(a, bundlePath)
          );
          for (const adapter of applicable) {
            tokenQuoteContracts.push(
              adapter.getQuoteExactInContract(bundlePath, indexEntry.amount)
            );
          }
        }

        if (tokenQuoteContracts.length > 0) {
          const quoteResults = await this.client.multicall({
            contracts: tokenQuoteContracts as Parameters<
              PublicClient["multicall"]
            >[0]["contracts"],
            allowFailure: true,
          });

          // Calculate total WETH received
          let quoteIndex = 0;

          // Sum WETH received from tokens
          for (const [token, amount] of tokenAmounts) {
            if (token.toLowerCase() === this.weth.toLowerCase()) continue;

            const sellToken = sellATokenMap.get(token.toLowerCase()) ?? token;
            const tokenPath: Address[] = [sellToken, this.weth];
            const applicable = this.adapters.filter((a) =>
              canAdapterHandleExactIn(a, tokenPath)
            );

            let bestQuote: bigint | null = null;
            for (const _adapter of applicable) {
              const r = quoteResults[quoteIndex];
              if (r?.status === "success" && r?.result !== undefined) {
                const amountOut2 = parseQuoteExactInResult(
                  _adapter,
                  r.result,
                  tokenQuoteContracts[quoteIndex]!
                );
                if (amountOut2 !== undefined) {
                  if (bestQuote === null || amountOut2 > bestQuote) {
                    bestQuote = amountOut2;
                  }
                }
              }
              quoteIndex++;
            }
            if (bestQuote !== null) {
              totalWETHReceived += bestQuote;
            }
          }

          // For nested bundles, add their quotes (simplified - TODO: handle recursively)
          for (const indexEntry of decomposition.indexes) {
            const bundlePath: Address[] = [indexEntry.index, this.weth];
            const applicable = this.adapters.filter((a) =>
              canAdapterHandleExactIn(a, bundlePath)
            );

            let bestQuote: bigint | null = null;
            for (const _adapter of applicable) {
              const r = quoteResults[quoteIndex];
              if (r?.status === "success" && r?.result !== undefined) {
                const amountOut2 = parseQuoteExactInResult(
                  _adapter,
                  r.result,
                  tokenQuoteContracts[quoteIndex]!
                );
                if (amountOut2 !== undefined) {
                  if (bestQuote === null || amountOut2 > bestQuote) {
                    bestQuote = amountOut2;
                  }
                }
              }
              quoteIndex++;
            }
            if (bestQuote !== null) {
              totalWETHReceived += bestQuote;
            }
          }

          if (totalWETHReceived >= amountOut) {
            indirectQuote = testBundleAmount;
            // Build indirect route calldata
            // Note: Nested bundles in exact-out are not yet handled recursively, so pass undefined
            const bundleCalldataBuilder = new BundleCalldataBuilder(this.client, this.contractAddresses, this.adapters);
            indirectBuilder = await bundleCalldataBuilder.buildIndirectSellCalldata(
              bundleAddress,
              testBundleAmount,
              decomposition,
              recipient,
              undefined,
              aaveAdapter ?? undefined,
              sellATokenMap.size > 0 ? sellATokenMap : undefined
            );
            break;
          }

          // Scale up for next iteration
          if (totalWETHReceived > 0n) {
            testBundleAmount = (testBundleAmount * amountOut) / totalWETHReceived;
          } else {
            break;
          }
        }
        iterations++;
      }
    }

    // Compare routes and select best (lowest input for exact-out)
    const quotes: { name: string; amountIn: bigint }[] = [];
    let best: QuoteResultExactOut | null = null;

    if (directQuote !== null && directQuote > 0n && bestDirectAdapter) {
      quotes.push({ name: `${bestDirectAdapter.name} (direct)`, amountIn: directQuote });
      const directResult: QuoteResultExactOut = {
        adapter: bestDirectAdapter,
        amountIn: directQuote,
      };
      if (best === null) {
        best = directResult;
      } else {
        if (directQuote < (best as QuoteResultExactOut).amountIn) {
          best = directResult;
        }
      }
    }

    if (indirectQuote !== null && indirectQuote > 0n) {
      const routeName = isBuying ? "Mint (indirect)" : "Burn (indirect)";
      quotes.push({ name: routeName, amountIn: indirectQuote });
      const shouldUseIndirect = best === null || indirectQuote < (best as QuoteResultExactOut).amountIn;
      if (shouldUseIndirect) {
        const indirectAdapter: DexAdapter = {
          name: routeName,
          quoteExactIn: async () => 0n,
          quoteExactOut: async () => indirectQuote!,
          getQuoteExactInContract: () => ({
            address: bundleAddress,
            abi: [],
            functionName: "",
          }),
          getQuoteExactOutContract: () => ({
            address: bundleAddress,
            abi: [],
            functionName: "",
          }),
          buildExactIn: () => { },
          buildExactOut: () => { },
        };
        best = {
          adapter: indirectAdapter,
          amountIn: indirectQuote,
        };
      }
    }

    if (best === null) {
      throw new Error("No successful quote from any route");
    }

    // Build calldata for best route
    let builder: CalldataBuilder;
    if (bestDirectAdapter && best.adapter === bestDirectAdapter && directQuote !== null) {
      builder = new CalldataBuilder(this.contractAddresses.RECIPIENT_PLACEHOLDER);
      bestDirectAdapter.buildExactOut(builder, normalized, amountOut, recipient, directQuote);
    } else if (indirectBuilder) {
      builder = indirectBuilder;
    } else {
      throw new Error("Failed to build calldata for selected route");
    }

    // Extract required approvals and check current allowances
    const requiredApprovals = builder.getRequiredApprovals();
    if (requiredApprovals.size > 0) {
      const allowances = await this.checkAllowances(requiredApprovals, this.contractAddresses.UNIVERSAL_ROUTER);
      this.filterUnnecessaryApprovals(builder, allowances, requiredApprovals, true); // exact-out, needs buffer
    }

    const calldata = builder.encodeForUniversalRouter(this.contractAddresses.UNIVERSAL_ROUTER);

    // Include scenario data for buy operations
    if (isBuying && options?.isBundle && decomposition !== null && buyTree !== null) {
      return {
        calldata,
        quotes,
        best,
        scenarios: {
          numScenarios,
          scenarioTotals,
          scenarioLegs,
          scenarioWinningEntries,
          decomposition,
          buyTree,
          quoteResults,
          allQuoteContracts,
          nestedMeta,
          level0TokenToEntries,
          combinedQuoteEntries,
          directQuoteEntries,
          bestDirectAdapter,
          bestNestedAdapters,
          aaveAdapter: aaveAdapter ?? undefined,
          aTokensInDecomposition: aTokensInDecomposition.size > 0 ? aTokensInDecomposition : undefined,
          routeHints: options?.routeHints,
        }
      };
    }

    return { calldata, quotes, best };
  }

  /**
   * Find best exact-in quote per token for create-index: one multicall for Aave + decompose
   * all tokens, then one multicall for all getAmountsOut (exact-in) quotes. Returns minAmounts
   * and _data calldata for UniversalRouter.createIndex.
   */
  async findBestCreateIndexQuotes(
    tokens: Address[],
    ethAmounts: bigint[],
    routeHints?: RouteHints
  ): Promise<{ minAmounts: bigint[]; data: Hex; totalEth: bigint }> {
    if (tokens.length !== ethAmounts.length) {
      throw new Error("tokens and ethAmounts must have the same length");
    }
    const totalEth = ethAmounts.reduce((a, b) => a + b, 0n);
    const wethLower = this.weth.toLowerCase();
    const nominalDecomposeAmount = 1n * 10n ** 18n;

    // ── RPC Call 1: Aave + Decomposer.buy for each token ─────────────────────
    const rpc1Contracts: MulticallContract[] = [
      {
        address: this.contractAddresses.AAVE_V3_PROTOCOL_DATA_PROVIDER,
        abi: aaveProtocolDataProviderAbi,
        functionName: "getAllReservesTokens",
      },
      {
        address: this.contractAddresses.AAVE_V3_PROTOCOL_DATA_PROVIDER,
        abi: aaveProtocolDataProviderAbi,
        functionName: "getAllATokens",
      },
      ...tokens.map(
        (token): MulticallContract => ({
          address: this.contractAddresses.DECOMPOSER_MAINNET,
          abi: decomposerAbi,
          functionName: "buy",
          args: [nominalDecomposeAmount, token],
        })
      ),
    ];

    const rpc1Results = await this.client.multicall({
      contracts: rpc1Contracts as Parameters<PublicClient["multicall"]>[0]["contracts"],
      allowFailure: true,
    });

    // Parse Aave (indices 0, 1)
    let aaveAdapter: AaveV3Adapter | null = null;
    const aTokensInDecomposition = new Map<string, Address>();
    const reservesResult = rpc1Results[0];
    const aTokensResult = rpc1Results[1];
    if (
      reservesResult?.status === "success" &&
      reservesResult.result &&
      aTokensResult?.status === "success" &&
      aTokensResult.result
    ) {
      const reserves = reservesResult.result as readonly { symbol: string; tokenAddress: Address }[];
      const aTokens = aTokensResult.result as readonly { symbol: string; tokenAddress: Address }[];
      const { aTokenToUnderlying, underlyingToAToken } = buildATokenMaps(reserves, aTokens);
      aaveAdapter = new AaveV3Adapter(this.contractAddresses.AAVE_V3_POOL, aTokenToUnderlying, underlyingToAToken);
    }

    // Which tokens are bundles (decomposer succeeded)
    const bundleAddresses = new Set<Address>();
    for (let i = 0; i < tokens.length; i++) {
      const res = rpc1Results[2 + i];
      if (res?.status === "success" && res.result !== undefined) {
        bundleAddresses.add(tokens[i]!);
      }
    }

    const resolveForQuoting = (token: Address): Address => {
      if (aaveAdapter?.isAToken(token)) {
        const underlying = aaveAdapter.getUnderlying(token)!;
        aTokensInDecomposition.set(token.toLowerCase(), underlying);
        return underlying;
      }
      return token;
    };

    // Build list of constituents: (tokenIndex, paths, amountIn, quoteToken). Skip WETH.
    const constituents: { tokenIndex: number; paths: Address[][]; amountIn: bigint; quoteToken: Address }[] = [];
    for (let i = 0; i < tokens.length; i++) {
      const token = tokens[i]!;
      const amountIn = ethAmounts[i]!;
      if (token.toLowerCase() === wethLower) continue;
      const quoteToken = resolveForQuoting(token);
      const paths = buildQuotingPaths(this.weth, quoteToken, routeHints, token);
      constituents.push({ tokenIndex: i, paths, amountIn, quoteToken });
    }

    // ── RPC Call 2: All exact-in quotes ────────────────────────────────────
    const allQuoteContracts: MulticallContract[] = [];
    const tokenIndexToResultIndices: Map<number, { adapter: DexAdapter; resultIndex: number; path: Address[] }[]> = new Map();

    for (const c of constituents) {
      const indices: { adapter: DexAdapter; resultIndex: number; path: Address[] }[] = [];
      for (const quotePath of c.paths) {
        const applicable = this._getApplicableAdaptersForExactIn(quotePath, bundleAddresses);
        for (const adapter of applicable) {
          const idx = allQuoteContracts.length;
          allQuoteContracts.push(adapter.getQuoteExactInContract(quotePath, c.amountIn));
          indices.push({ adapter, resultIndex: idx, path: quotePath });
        }
      }
      const existing = tokenIndexToResultIndices.get(c.tokenIndex) ?? [];
      tokenIndexToResultIndices.set(c.tokenIndex, [...existing, ...indices]);
    }

    if (allQuoteContracts.length === 0 && constituents.length > 0) {
      throw new Error("No quote contracts to run (no applicable adapters for any constituent)");
    }

    type MulticallOne = { status: "success"; result: unknown } | { status: "failure"; error: Error };
    const quoteResults: MulticallOne[] =
      allQuoteContracts.length > 0
        ? (await this.client.multicall({
          contracts: allQuoteContracts as Parameters<PublicClient["multicall"]>[0]["contracts"],
          allowFailure: true,
        })) as MulticallOne[]
        : [];

    // Best per token: tokenIndex -> { adapter (null for WETH), amountOut, path, amountIn }
    const bestPerToken = new Map<
      number,
      { adapter: DexAdapter | null; amountOut: bigint; path: Address[]; amountIn: bigint }
    >();

    for (let i = 0; i < tokens.length; i++) {
      if (tokens[i]!.toLowerCase() === wethLower) {
        bestPerToken.set(i, {
          adapter: null,
          amountOut: ethAmounts[i]!,
          path: [this.weth, this.weth],
          amountIn: ethAmounts[i]!,
        });
        continue;
      }
      const entries = tokenIndexToResultIndices.get(i) ?? [];
      let best: { adapter: DexAdapter; amountOut: bigint; path: Address[] } | null = null;
      for (const { adapter, resultIndex, path: entryPath } of entries) {
        const r = quoteResults[resultIndex];
        if (r?.status !== "success" || r.result === undefined) continue;
        const contract = allQuoteContracts[resultIndex]!;
        const amountOut = parseQuoteExactInResult(adapter, r.result, contract);
        if (amountOut !== undefined && (best === null || amountOut > best.amountOut)) {
          best = { adapter, amountOut, path: entryPath };
        }
      }
      if (best === null) {
        throw new Error(`No successful quote for token at index ${i} (${tokens[i]})`);
      }
      const c = constituents.find((x) => x.tokenIndex === i)!;
      bestPerToken.set(i, {
        adapter: best.adapter,
        amountOut: best.amountOut,
        path: best.path,
        amountIn: c.amountIn,
      });
    }

    const minAmounts = tokens.map((_, i) => bestPerToken.get(i)!.amountOut);

    const builder = new CalldataBuilder(this.contractAddresses.RECIPIENT_PLACEHOLDER);
    for (let i = 0; i < tokens.length; i++) {
      if (tokens[i]!.toLowerCase() === wethLower) continue;
      const sel = bestPerToken.get(i)!;
      if (sel.adapter != null) {
        sel.adapter.buildExactIn(builder, sel.path, sel.amountIn, this.contractAddresses.UNIVERSAL_ROUTER);
      }
      // If the original token is an aToken, add Aave supply (underlying -> aToken)
      // so the Factory receives the aToken, not the raw underlying.
      // Because swaps are exact-in (variable output), the actual underlying received may
      // differ from the quote by the time the tx executes (block-to-block price drift).
      // Aave supply() requires an exact amount (no "supply all" option), so we apply a
      // 1% haircut to guarantee the supply never exceeds the actual balance. The ~1% of
      // underlying dust stays in the router. Reported minAmount is adjusted to match.
      const underlying = aTokensInDecomposition.get(tokens[i]!.toLowerCase());
      if (underlying && aaveAdapter) {
        const supplyAmount = sel.amountOut * 99n / 100n;
        aaveAdapter.buildExactIn(builder, [underlying, tokens[i]!], supplyAmount, this.contractAddresses.UNIVERSAL_ROUTER);
        minAmounts[i] = supplyAmount;
      }
    }

    // Always keep approvals for create-index: the Universal Router receives WETH only after deposit()
    // in the same tx, so existing allowance state may not apply; explicit approve before each swap is safer.
    const requiredApprovals = builder.getRequiredApprovals();
    if (requiredApprovals.size > 0) {
      const allowances = await this.checkAllowances(requiredApprovals, this.contractAddresses.UNIVERSAL_ROUTER);
      // Do not filter out approvals for create-index so calldata always includes them
      // this.filterUnnecessaryApprovals(builder, allowances, requiredApprovals, false);
    }

    const data = builder.encodeForUniversalRouter(this.contractAddresses.UNIVERSAL_ROUTER);

    return { minAmounts, data, totalEth };
  }

  /**
   * Build calldata for a specific buy scenario.
   * @param scenarioIndex The scenario index (0 = direct, 1+ = indirect)
   * @param bundleAddress The bundle address
   * @param amountOut The desired bundle amount
   * @param recipient The recipient address
   * @param scenarios Scenario data from findBestExactOutWithBundle
   * @returns The calldata builder for the scenario
   */
  async buildCalldataForScenario(
    scenarioIndex: number,
    bundleAddress: Address,
    amountOut: bigint,
    recipient: Address,
    scenarios: {
      numScenarios: number;
      scenarioTotals: bigint[];
      scenarioLegs: SellLeg[][];
      scenarioWinningEntries: Map<Address, TokenQuoteEntry>[];
      decomposition: {
        tokens: readonly { token: Address; amount: bigint; parentAddress: Address }[];
        indexes: readonly { index: Address; amount: bigint; parentAddress: Address }[];
      };
      buyTree: ReturnType<typeof buildBuyTree>;
      quoteResults: Awaited<ReturnType<PublicClient["multicall"]>>;
      allQuoteContracts: MulticallContract[];
      nestedMeta: { directEntries: { adapter: BundlesIndexSwapAdapter; index: number }[]; tokenToEntries: TokenQuoteMap; tokenOrder: Address[] }[];
      level0TokenToEntries: TokenQuoteMap;
      combinedQuoteEntries: Map<string, TokenQuoteEntry[]>;
      directQuoteEntries: { adapter: BundlesIndexSwapAdapter; index: number }[];
      bestDirectAdapter: BundlesIndexSwapAdapter | null;
      bestNestedAdapters: BundlesIndexSwapAdapter[];
      aaveAdapter?: AaveV3Adapter;
      aTokensInDecomposition?: Map<string, Address>;
      routeHints?: RouteHints;
    }
  ): Promise<CalldataBuilder> {
    const { bestDirectAdapter, bestNestedAdapters, buyTree, decomposition, scenarioLegs, aaveAdapter: scenarioAaveAdapter, aTokensInDecomposition: scenarioATokens } = scenarios;
    const normalized = [this.weth, bundleAddress] as Address[];

    if (scenarioIndex === 0) {
      if (!bestDirectAdapter) {
        throw new Error("No BundlesIndexSwapAdapter found for direct route");
      }
      const builder = new CalldataBuilder(this.contractAddresses.RECIPIENT_PLACEHOLDER);
      const directAmountIn = scenarios.scenarioTotals[0] ?? 0n;
      bestDirectAdapter.buildExactOut(builder, normalized, amountOut, recipient, directAmountIn);
      return builder;
    }

    const N = buyTree.nesteds.length;
    const bits = scenarioIndex - 1;

    const nestedBundleRoutes = new Map<
      Address,
      { isDirect: boolean; calldata?: Hex; adapter?: DexAdapter; amount?: bigint }
    >();

    for (let ni = 0; ni < N; ni++) {
      const nested = buyTree.nesteds[ni]!;
      const useDirect = (bits & (1 << ni)) === 0;
      nestedBundleRoutes.set(nested.bundle, {
        isDirect: useDirect,
        adapter: useDirect ? bestNestedAdapters[ni] : undefined,
        amount: nested.amount,
      });
    }

    // Extract adapter selections from the stored winning entries for this scenario
    const tokenAdapterSelections = new Map<Address, TokenAdapterSelection>();
    const winningEntries = scenarios.scenarioWinningEntries[scenarioIndex];
    const legs = scenarioLegs[scenarioIndex] ?? [];

    for (const leg of legs) {
      if (!leg.isBundle && leg.adapterName !== "" && leg.adapterName !== "—") {
        const entry = winningEntries?.get(leg.asset);
        if (entry) {
          tokenAdapterSelections.set(leg.asset, {
            adapter: entry.adapter,
            quotedAmountIn: leg.amountIn,
            path: entry.path
          });
        }
      }
    }

    const bundleCalldataBuilder = new BundleCalldataBuilder(this.client, this.contractAddresses, this.adapters);
    return await bundleCalldataBuilder.buildIndirectBuyCalldata(
      bundleAddress,
      amountOut,
      decomposition,
      recipient,
      nestedBundleRoutes,
      tokenAdapterSelections,
      scenarioAaveAdapter,
      scenarioATokens,
      scenarios.routeHints
    );
  }

}


