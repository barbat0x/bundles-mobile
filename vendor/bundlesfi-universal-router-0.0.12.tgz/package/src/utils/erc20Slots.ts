import { keccak256, encodeAbiParameters, parseAbiParameters, pad, encodeFunctionData, decodeFunctionResult } from "viem";
import type { Address, Hex, PublicClient } from "viem";
import { erc20Abi } from "../contracts/abis.js";

/**
 * Compute the storage slot for `_allowances[owner][spender]` in a standard
 * Solidity ERC20 contract where the `_allowances` mapping lives at base
 * storage slot `mappingBaseSlot`.
 *
 * Solidity mapping storage layout:
 *   slot(mapping[key]) = keccak256(abi.encode(key, baseSlot))
 *
 * For a nested mapping `_allowances[owner][spender]`:
 *   innerSlot  = keccak256(abi.encode(owner, mappingBaseSlot))
 *   finalSlot  = keccak256(abi.encode(spender, innerSlot))
 */
export function computeAllowanceSlot(
  owner: Address,
  spender: Address,
  mappingBaseSlot: bigint
): Hex {
  const innerSlot = keccak256(
    encodeAbiParameters(
      parseAbiParameters("address, uint256"),
      [owner, mappingBaseSlot]
    )
  );
  const finalSlot = keccak256(
    encodeAbiParameters(
      parseAbiParameters("address, bytes32"),
      [spender, innerSlot]
    )
  );
  return finalSlot;
}

/** Max uint256 as a 32-byte hex value for state overrides. */
const MAX_UINT256_HEX: Hex =
  "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff";

/** A distinctive magic value used by the probe to identify the correct slot. */
const PROBE_MAGIC: Hex =
  "0x000000000000000000000000000000000000000000000000000000000000002a"; // 42

/**
 * Dynamically discover the base storage slot of the ERC20 `_allowances`
 * mapping for a given token contract.
 *
 * Strategy: for each candidate base slot (0 .. maxSlot), compute the derived
 * allowance slot for (owner, spender), override it to a known magic value via
 * `stateOverride`, then call `allowance(owner, spender)` on the token. If the
 * return matches the magic value we've found the correct base slot.
 *
 * This costs one `eth_call` per candidate (typically finds it at slot 0 or 1).
 *
 * @returns The base slot number, or `null` if none of the candidates matched.
 */
export async function findAllowanceBaseSlot(
  client: PublicClient,
  token: Address,
  owner: Address,
  spender: Address,
  maxSlot: number = 10
): Promise<bigint | null> {
  const calldata = encodeFunctionData({
    abi: erc20Abi,
    functionName: "allowance",
    args: [owner, spender],
  });

  for (let s = 0; s <= maxSlot; s++) {
    const candidateSlot = computeAllowanceSlot(owner, spender, BigInt(s));
    try {
      const result = await client.call({
        to: token,
        data: calldata,
        stateOverride: [
          {
            address: token,
            stateDiff: [
              {
                slot: candidateSlot,
                value: PROBE_MAGIC,
              },
            ],
          },
        ],
      });

      if (result.data) {
        const decoded = decodeFunctionResult({
          abi: erc20Abi,
          functionName: "allowance",
          data: result.data,
        });
        if (decoded === 42n) {
          console.log(
            `[Approval Override] Found allowance mapping at base slot ${s} for ${token.slice(0, 10)}...`
          );
          return BigInt(s);
        }
      }
    } catch {
      // Probe failed for this slot — try next
    }
  }

  console.warn(
    `[Approval Override] Could not find allowance base slot for ${token.slice(0, 10)}... (tried 0..${maxSlot})`
  );
  return null;
}

/**
 * Build a `stateOverride` entry that sets `token.allowance(owner, spender)`
 * to max uint256. Probes the correct base slot automatically.
 *
 * @returns A viem-compatible stateOverride array element, or `null` if the
 *          base slot could not be determined.
 */
export async function buildApprovalStateOverride(
  client: PublicClient,
  token: Address,
  owner: Address,
  spender: Address
): Promise<{
  address: Address;
  stateDiff: { slot: Hex; value: Hex }[];
} | null> {
  const baseSlot = await findAllowanceBaseSlot(client, token, owner, spender);
  if (baseSlot === null) return null;

  const allowanceSlot = computeAllowanceSlot(owner, spender, baseSlot);
  console.log(
    `[Approval Override] Overriding allowance slot ${allowanceSlot.slice(0, 18)}... to max uint256`
  );

  return {
    address: token,
    stateDiff: [
      {
        slot: allowanceSlot,
        value: MAX_UINT256_HEX,
      },
    ],
  };
}
