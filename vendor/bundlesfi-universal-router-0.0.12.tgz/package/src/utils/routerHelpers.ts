import type { PublicClient } from "viem";
import { Router } from "../router/Router.js";
import { getAdapterSpecsForChain } from "../config/adapters.js";

import { DEFAULT_CONTRACT_ADDRESSES, type ContractAddresses } from "../config/addresses.js";

/**
 * Registers with the router all adapters that are available on the given chain.
 */
export function registerAdaptersForChain(
  router: Router,
  client: PublicClient,
  chainId: number,
  config: ContractAddresses = DEFAULT_CONTRACT_ADDRESSES
): void {
  const specs = getAdapterSpecsForChain(chainId);
  for (const spec of specs) {
    router.register(spec.create(client, chainId, config));
  }
}
