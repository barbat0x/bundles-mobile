import type { Address, Hex } from "viem";
import { Router } from "../router/Router.js";

/**
 * Find best exact-in route for a given path and amount.
 * Logs quotes per DEX, selected route, and UniversalRouter calldata.
 */
export async function findBestRoute(
  router: Router,
  path: (Address | "ETH")[],
  amountIn: bigint,
  recipient: Address
): Promise<{ calldata: Hex; quotes: { name: string; amountOut: bigint }[]; best: { adapter: { name: string }; amountOut: bigint } }> {
  console.log("\n" + "=".repeat(80));
  console.log("--- Exact-in quote ---");
  console.log("Path:", path);
  console.log("Amount in:", amountIn.toString());

  const result = await router.findBestExactIn(path, amountIn, recipient);

  console.log("\nQuotes per DEX:");
  for (const q of result.quotes) {
    console.log(`  ${q.name}: amountOut = ${q.amountOut.toString()}`);
  }
  console.log("\nSelected route:", result.best.adapter.name);
  console.log("Best amount out:", result.best.amountOut.toString());
  console.log("\nFinal UniversalRouter calldata (hex):");
  console.log(result.calldata);
  console.log("=".repeat(80));

  return result;
}

/**
 * Find best route for Bundle tokens (exact-in when selling, exact-out when buying).
 * When selling: amountIn = Bundle amount, compares direct swap vs burn.
 * When buying: amountIn = desired Bundle amount (exact-out), compares direct swap vs mint; logs WETH needed.
 */
export async function findBestRouteWithBundle(
  router: Router,
  path: (Address | "ETH")[],
  amountIn: bigint,
  recipient: Address,
  options: {
    printLogs?: boolean,
    isBundle: { token: Address; isBuying: boolean }
  }
): Promise<{ calldata: Hex; quotes: { name: string; amountOut: bigint }[]; best: { adapter: { name: string }; amountOut: bigint } }> {
  if (options?.printLogs) {
    console.log("\n" + "=".repeat(80));
    console.log(options.isBundle.isBuying ? "--- Bundle route (exact-out buy) ---" : "--- Bundle route (exact-in sell) ---");
    console.log("Path:", path);
    console.log(options.isBundle.isBuying ? "Desired Bundle amount:" : "Amount in:", amountIn.toString());
    console.log("Bundle token:", options.isBundle.token);
    console.log("Is buying:", options.isBundle.isBuying);
  }

  if (options?.isBundle.isBuying) {
    const result = await router.findBestExactOutWithBundle(path, amountIn, recipient, options);
    if (options?.printLogs) {
      console.log("\nWETH needed:", result.best.amountIn.toString());
      console.log("Bundle amount:", amountIn.toString());
      console.log("\nFinal UniversalRouter calldata (hex):");
      console.log(result.calldata);
      console.log("=".repeat(80));
    }
    return {
      calldata: result.calldata,
      quotes: result.quotes.map((q) => ({ name: q.name, amountOut: amountIn })),
      best: { adapter: result.best.adapter, amountOut: amountIn },
    };
  }

  const result = await router.findBestExactInWithBundle(path, amountIn, recipient, options);
  if (options?.printLogs) {
    console.log("\nBest amount out:", result.best.amountOut.toString());
    console.log("\nFinal UniversalRouter calldata (hex):");
    console.log(result.calldata);
    console.log("=".repeat(80));
  }

  return result;
}
