/**
 * Simple logger interface for optional logging throughout the codebase.
 * Default implementation is silent (no-op), but can be replaced with console logger for debugging.
 */
export interface Logger {
  log(...args: unknown[]): void;
  error(...args: unknown[]): void;
  warn(...args: unknown[]): void;
  debug(...args: unknown[]): void;
}

/**
 * Silent logger that does nothing (default).
 */
class SilentLogger implements Logger {
  log(): void {}
  error(): void {}
  warn(): void {}
  debug(): void {}
}

/**
 * Console logger that outputs to console (for debugging).
 */
class ConsoleLogger implements Logger {
  log(...args: unknown[]): void {
    console.log(...args);
  }
  error(...args: unknown[]): void {
    console.error(...args);
  }
  warn(...args: unknown[]): void {
    console.warn(...args);
  }
  debug(...args: unknown[]): void {
    console.debug(...args);
  }
}

/**
 * Default logger instance. Can be replaced for debugging.
 */
export let defaultLogger: Logger = new SilentLogger();

/**
 * Set the default logger instance.
 */
export function setLogger(logger: Logger): void {
  defaultLogger = logger;
}

/**
 * Enable console logging (useful for debugging).
 */
export function enableConsoleLogging(): void {
  defaultLogger = new ConsoleLogger();
}

/**
 * Disable logging (set to silent).
 */
export function disableLogging(): void {
  defaultLogger = new SilentLogger();
}

/**
 * Check if debug logging is enabled via DEBUG environment variable.
 * Set DEBUG=1 or DEBUG=true to enable debug logs.
 */
export function isDebugEnabled(): boolean {
  if (typeof process !== "undefined" && process.env) {
    const debug = process.env.DEBUG;
    return debug === "1" || debug === "true" || debug === "TRUE";
  }
  return false;
}

/**
 * Debug log function that only logs if DEBUG environment variable is set.
 */
export function debugLog(...args: unknown[]): void {
  if (isDebugEnabled()) {
    console.log(...args);
  }
}
