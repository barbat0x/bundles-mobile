import { encodeFunctionData } from "viem";
import type { Address, Hex, PublicClient } from "viem";

import { UNIVERSAL_ROUTER_DEADLINE_SECONDS } from "../config/constants.js";
import { Router } from "../router/Router.js";
import type { RouteHints } from "../router/types.js";
import { universalRouterAbi } from "../contracts/abis.js";
import { buildApprovalStateOverride } from "./erc20Slots.js";

/**
 * Simulate a Universal Router buy or sell on-chain via eth_call (no real tx, no signature).
 * Uses UNIVERSAL_ROUTER address and universalRouterAbi to encode the outer call
 * (swapETHForExactTokens for buy, swapExactTokensForETH for sell) and runs client.call
 * with the given simulationAccount as "from", so the RPC simulates whether the tx would succeed.
 * Adds a 1% value buffer on buy to reduce slippage reverts in simulation.
 * If simulationState is provided, sets simulationState.lastInnerCalldata before the call so the caller
 * can decode and log the failing operation on UniversalRouter__OperationFailed(i).
 *
 * Data shape (correct): the transaction `data` we send MUST start with the 4-byte selector of
 * swapETHForExactTokens (or swapExactTokensForETH) so the Universal Router can dispatch to that
 * function. That function then decodes the rest and passes the third argument `_data` to
 * _executeOperations. That inner _data is result.calldata = abi.encode(targets[], selectors[], params[])
 * and does NOT contain the Universal Router's function selector; it is only decoded inside
 * _executeOperations as (address[], bytes4[], bytes[]).
 */
export async function simulateOnChain(
  client: PublicClient,
  router: Router,
  operation: "buy" | "sell",
  token: Address,
  amount: bigint,
  recipient: Address,
  simulationAccount: Address,
  simulationState?: { lastInnerCalldata?: Hex },
  routeHints?: RouteHints
): Promise<void> {
  if (recipient.toLowerCase() !== router.contractAddresses.UNIVERSAL_ROUTER.toLowerCase()) {
    throw new Error(
      `Simulation requires recipient to be the Universal Router (${router.contractAddresses.UNIVERSAL_ROUTER}); got ${recipient}. Inner operations must send tokens to the router.`
    );
  }
  const deadline = BigInt(Math.floor(Date.now() / 1000) + UNIVERSAL_ROUTER_DEADLINE_SECONDS);

  if (operation === "buy") {
    const result = await router.findBestExactOutWithBundle(
      ["ETH", token],
      amount,
      recipient,
      {
        isBundle: { token, isBuying: true },
        printLogs: true,
        routeHints,
      }
    );

    // If scenario data is available, simulate all scenarios
    if (result.scenarios) {
      const { scenarios } = result;
      console.log(`\nSimulating all ${scenarios.numScenarios} scenarios...\n`);

      for (let s = 0; s < scenarios.numScenarios; s++) {
        const scenarioTotal = scenarios.scenarioTotals[s];
        if (!scenarioTotal || scenarioTotal === 0n) {
          console.log(`Scenario ${s}: Skipped (no valid quote)`);
          continue;
        }

        try {
          // Build calldata for this scenario
          const scenarioBuilder = await router.buildCalldataForScenario(
            s,
            token,
            amount,
            recipient,
            scenarios
          );
          const scenarioCalldata = scenarioBuilder.encodeForUniversalRouter(router.contractAddresses.UNIVERSAL_ROUTER);

          if (simulationState) simulationState.lastInnerCalldata = scenarioCalldata;

          const data = encodeFunctionData({
            abi: universalRouterAbi,
            functionName: "swapETHForExactTokens",
            args: [token, amount, scenarioCalldata, deadline],
          });

          // Use 1001/1000 multiplier for msg.value (0.1% buffer)
          const valueWithBuffer = (scenarioTotal * 1001n) / 1000n;

          await client.call({
            to: router.contractAddresses.UNIVERSAL_ROUTER,
            data,
            value: valueWithBuffer,
            account: simulationAccount,
          });

          console.log(`Scenario ${s}: Simulation succeeded (total: ${scenarioTotal.toString()} WETH)`);
        } catch (err: unknown) {
          console.error(`Scenario ${s}: Simulation failed (total: ${scenarioTotal.toString()} WETH)`);
          if (s === scenarios.numScenarios - 1) {
            // Re-throw error for the last scenario to maintain backward compatibility
            throw err;
          }
          // Continue to next scenario for others
        }
      }
      console.log("\nAll scenario simulations completed.");
    } else {
      // Fallback to original behavior if scenario data not available
      if (simulationState) simulationState.lastInnerCalldata = result.calldata;
      const data = encodeFunctionData({
        abi: universalRouterAbi,
        functionName: "swapETHForExactTokens",
        args: [token, amount, result.calldata, deadline],
      });
      // Use 1001/1000 multiplier for msg.value (0.1% buffer)
      const valueWithBuffer = (result.best.amountIn * 1001n) / 1000n;
      await client.call({
        to: router.contractAddresses.UNIVERSAL_ROUTER,
        data,
        value: valueWithBuffer,
        account: simulationAccount,
      });
      console.log("Simulation succeeded.");
    }
  } else {
    const result = await router.findBestExactInWithBundle(
      [token, "ETH"],
      amount,
      recipient,
      {
        isBundle: { token, isBuying: false },
        printLogs: true,
        routeHints,
      }
    );
    if (simulationState) simulationState.lastInnerCalldata = result.calldata;
    const minEthOut = 0n; // conservative for simulation
    const data = encodeFunctionData({
      abi: universalRouterAbi,
      functionName: "swapExactTokensForETH",
      args: [token, amount, minEthOut, result.calldata, deadline],
    });

    // For sell: the Universal Router needs to transferFrom the bundle token
    // from the simulation account. We use stateOverride to fake the ERC20
    // approval so the simulation doesn't revert due to missing allowance.
    console.log("[Simulation] Probing ERC20 allowance storage slot for approval override...");
    const approvalOverride = await buildApprovalStateOverride(
      client,
      token,
      simulationAccount,
      router.contractAddresses.UNIVERSAL_ROUTER
    );

    const stateOverride = approvalOverride ? [approvalOverride] : undefined;
    if (!approvalOverride) {
      console.warn(
        "[Simulation] Warning: could not build approval override; simulation may fail due to missing allowance."
      );
    }

    await client.call({
      to: router.contractAddresses.UNIVERSAL_ROUTER,
      data,
      account: simulationAccount,
      stateOverride,
    });
    console.log("Simulation succeeded.");
  }
}
