/** Walk the full error cause chain to find revert data (hex string). */
export function getRevertDataFromError(err: unknown): string | undefined {
  let e: unknown = err;
  while (e && typeof e === "object") {
    const data = (e as Record<string, unknown>).data;
    if (typeof data === "string" && data.startsWith("0x")) return data;
    const cause = (e as Record<string, unknown>).cause;
    if (cause === undefined || cause === null) break;
    e = cause;
  }
  return undefined;
}
