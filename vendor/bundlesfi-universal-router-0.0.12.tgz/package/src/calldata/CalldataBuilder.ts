import {
  type Abi,
  type Address,
  type Hex,
  encodeFunctionData,
  encodeAbiParameters,
  parseAbiParameters,
  decodeAbiParameters,
  sliceHex,
} from "viem";
import { erc20Abi } from "../contracts/abis.js";
import { indexAbi } from "../contracts/abis.js";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";

/** Single operation for UniversalRouter: target + selector + params. */
export interface Operation {
  target: Address;
  selector: Hex;
  params: Hex;
}

function approveKey(token: Address, spender: Address): string {
  return `${token.toLowerCase()}:${spender.toLowerCase()}`;
}

/**
 * Builds calldata for UniversalRouter._executeOperations(bytes).
 * Output format: abi.encode(address[] targets, bytes4[] selectors, bytes[] params).
 * No per-call ETH value; no return-value chaining.
 */
export class CalldataBuilder {
  private ops: Operation[] = [];
  private approveIndices: Map<string, number> = new Map();
  private actualRequiredAmounts: Map<string, bigint> = new Map();
  private bundleMintApprovalKeys: Set<string> = new Set();

  constructor(private recipientPlaceholder: Address = DEFAULT_CONTRACT_ADDRESSES.RECIPIENT_PLACEHOLDER) { }

  /**
   * Append a contract call. Encodes via Viem and stores target, selector (4 bytes), and params.
   */
  addCall(
    target: Address,
    abi: Abi,
    functionName: string,
    args: readonly unknown[]
  ): void {
    const data = encodeFunctionData({ abi, functionName, args });
    const selector = sliceHex(data, 0, 4) as Hex;
    const params = sliceHex(data, 4) as Hex;
    this.ops.push({ target, selector, params });
  }

  /**
   * Append a contract call with pre-encoded selector and params (e.g. when encodeFunctionData
   * fails to encode a struct correctly). selector must be 4 bytes, params is the ABI-encoded
   * arguments only (no selector).
   */
  addCallRaw(target: Address, selector: Hex, params: Hex): void {
    if (selector.length !== 10) throw new Error("addCallRaw: selector must be 4 bytes (10 hex chars)");
    this.ops.push({ target, selector, params });
  }

  /**
   * Append an ERC20 approve. Deduplicates by (token, spender): keeps the larger approval amount,
   * but sums the actual required amounts when multiple operations need the same token-spender pair.
   * @param actualAmount Optional actual required amount (for allowance checking). If not provided, uses the approval amount.
   */
  addApprove(token: Address, spender: Address, amount: bigint, actualAmount?: bigint): void {
    const key = approveKey(token, spender);
    const existing = this.approveIndices.get(key);
    if (existing !== undefined) {
      const op = this.ops[existing]!;
      const prevAmount = decodeApproveAmount(op.params);
      const maxUint256 = 2n ** 256n - 1n;
      const newAmount =
        prevAmount === null
          ? amount
          : prevAmount >= maxUint256 || amount >= maxUint256
            ? maxUint256
            : prevAmount + amount;
      const newEncoded = encodeFunctionData({
        abi: erc20Abi,
        functionName: "approve",
        args: [spender, newAmount],
      });
      this.ops[existing] = {
        ...op,
        params: sliceHex(newEncoded, 4) as Hex,
      };

      // Sum actual amounts when multiple operations require the same token-spender pair
      if (actualAmount !== undefined) {
        const prevActual = this.actualRequiredAmounts.get(key);
        if (prevActual === undefined) {
          this.actualRequiredAmounts.set(key, actualAmount);
        } else {
          // Sum the amounts since multiple operations may need the same token
          this.actualRequiredAmounts.set(key, prevActual + actualAmount);
        }
      }
      return;
    }
    this.addCall(token, erc20Abi as Abi, "approve", [spender, amount]);
    this.approveIndices.set(key, this.ops.length - 1);

    // Store actual amount if provided
    if (actualAmount !== undefined) {
      this.actualRequiredAmounts.set(key, actualAmount);
    }
  }

  /**
   * Add Bundle mint operation: approve all underlying tokens, then mint.
   * @param bundleAddress Address of the Bundle contract
   * @param amount Amount of Bundle tokens to mint
   * @param recipient Address to receive minted tokens
   * @param underlyingTokens Array of underlying token addresses (must match Bundle's tokens)
   * @param actualTokenAmounts Optional map of token address to actual required amount (for allowance checking)
   */
  addBundleMint(
    bundleAddress: Address,
    amount: bigint,
    recipient: Address,
    underlyingTokens: Address[],
    actualTokenAmounts?: Map<Address, bigint>
  ): void {
    // Approve each underlying token (max uint256 for safety, but track actual amounts)
    const maxUint256 = 2n ** 256n - 1n;
    for (const token of underlyingTokens) {
      const key = approveKey(token, bundleAddress);
      // Mark this approval as a bundle mint approval
      this.bundleMintApprovalKeys.add(key);
      const actualAmount = actualTokenAmounts?.get(token);
      this.addApprove(token, bundleAddress, maxUint256, actualAmount);
    }

    // Mint with max amounts array (contract will use actual required amounts)
    const maxAmountsIn = underlyingTokens.map(() => maxUint256);
    this.addCall(
      bundleAddress,
      indexAbi as Abi,
      "mint",
      [amount, maxAmountsIn, recipient]
    );
  }

  /**
   * Add Bundle burn operation: burn Bundle tokens to receive underlying tokens.
   * @param bundleAddress Address of the Bundle contract
   * @param amount Amount of Bundle tokens to burn
   * @param recipient Address to receive underlying tokens
   * @param underlyingTokens Array of underlying token addresses (must match Bundle's tokens)
   */
  addBundleBurn(
    bundleAddress: Address,
    amount: bigint,
    recipient: Address,
    underlyingTokens: Address[]
  ): void {
    // Burn with min amounts array (zeros - contract will use actual received amounts)
    const minAmountsOut = underlyingTokens.map(() => 0n);
    this.addCall(
      bundleAddress,
      indexAbi as Abi,
      "burn",
      [amount, minAmountsOut, recipient]
    );
  }

  /**
   * Get all required approvals from the builder.
   * Returns a map of approval key (token:spender) to required amount.
   * Uses actual required amounts when available, otherwise falls back to approval operation amounts.
   */
  getRequiredApprovals(): Map<string, { token: Address; spender: Address; amount: bigint; isBundleMint?: boolean }> {
    const approvals = new Map<string, { token: Address; spender: Address; amount: bigint; isBundleMint?: boolean }>();
    const maxUint256 = 2n ** 256n - 1n;

    for (const [key, index] of this.approveIndices) {
      const op = this.ops[index];
      if (!op) continue;

      // Token is the target of the approve call
      const token = op.target;

      // Decode spender and amount from params
      try {
        const decoded = decodeAbiParameters(
          parseAbiParameters("address spender, uint256 amount"),
          op.params
        );
        const spender = decoded[0] as Address;
        const approvalAmount = decoded[1] as bigint;

        // Use actual required amount if available, otherwise use approval amount
        const actualAmount = this.actualRequiredAmounts.get(key);
        const amount = actualAmount !== undefined ? actualAmount : approvalAmount;

        // Check if this is a bundle mint approval (explicitly tracked when addBundleMint is called)
        const isBundleMint = this.bundleMintApprovalKeys.has(key);

        approvals.set(key, {
          token,
          spender,
          amount,
          isBundleMint,
        });
      } catch {
        // Skip if decoding fails
        continue;
      }
    }

    return approvals;
  }

  /**
   * Remove an approval operation from the builder.
   * @param token Token address
   * @param spender Spender address
   */
  removeApproval(token: Address, spender: Address): void {
    const key = approveKey(token, spender);
    const index = this.approveIndices.get(key);

    if (index === undefined) return;

    // Remove from operations array
    this.ops.splice(index, 1);

    // Remove from approveIndices, actualRequiredAmounts, and bundleMintApprovalKeys
    this.approveIndices.delete(key);
    this.actualRequiredAmounts.delete(key);
    this.bundleMintApprovalKeys.delete(key);

    // Update indices for all approvals that came after this one
    for (const [k, idx] of this.approveIndices) {
      if (idx > index) {
        this.approveIndices.set(k, idx - 1);
      }
    }
  }

  /**
   * Encode for UniversalRouter. Replaces recipient placeholder in all params
   * with the given recipient. Returns abi.encode(targets, selectors, params).
   */
  encodeForUniversalRouter(recipient?: Address): Hex {
    const placeholder = this.recipientPlaceholder;
    const targets: Address[] = [];
    const selectors: Hex[] = [];
    const params: Hex[] = [];
    for (const op of this.ops) {
      let p = op.params;
      if (recipient) {
        p = replacePlaceholderInHex(p, placeholder, recipient);
      }
      targets.push(op.target);
      selectors.push(op.selector);
      params.push(p);
    }
    return encodeAbiParameters(
      parseAbiParameters("address[] targets, bytes4[] selectors, bytes[] params"),
      [targets, selectors, params]
    );
  }
}

function decodeApproveAmount(paramsHex: Hex): bigint | null {
  try {
    const decoded = decodeAbiParameters(
      parseAbiParameters("address spender, uint256 amount"),
      paramsHex
    );
    return decoded[1] as bigint;
  } catch {
    return null;
  }
}

/** Replace 20-byte placeholder address with recipient in ABI-encoded bytes. */
function replacePlaceholderInHex(
  data: Hex,
  placeholder: Address,
  recipient: Address
): Hex {
  const pad = (a: Address) => a.slice(2).toLowerCase().padStart(64, "0");
  const ph = pad(placeholder);
  const rec = pad(recipient);
  const hex = data.slice(2);
  let out = hex;
  for (let i = 0; i + 64 <= hex.length; i += 64) {
    const chunk = hex.slice(i, i + 64);
    if (chunk === ph) {
      out = hex.slice(0, i) + rec + hex.slice(i + 64);
      break;
    }
  }
  return ("0x" + out) as Hex;
}
