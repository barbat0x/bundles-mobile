import type { Address, Hex, PublicClient } from "viem";
import { DEFAULT_CONTRACT_ADDRESSES, type ContractAddresses } from "../config/addresses.js";
import { getAdapterSpecsForChain } from "../config/adapters.js";
import { Router } from "../router/Router.js";
import type { RouteHints } from "../router/types.js";
import { registerAdaptersForChain } from "../utils/routerHelpers.js";
import { computeBundleQuotes } from "../bundle/BundleQuoter.js";

/** Index params for createIndex (matches IFactory.IndexParams). */
export interface IndexParams {
  name: string;
  symbol: string;
  swapFee: number;
  mintAndBurnFee: number;
  managerShareFee: number;
}

/** Input for quoteCreateIndex (from front-end). */
export interface CreateIndexParams {
  tokens: Address[];
  ethAmounts: bigint[];
  contractAddresses?: ContractAddresses;
  printLogs?: boolean;
  routeHints?: RouteHints;
}

/** Result of quoteCreateIndex: minAmounts (no slippage) + inner _data for UniversalRouter.createIndex. */
export interface CreateIndexResult {
  /** Quoted minimum token amounts (no slippage applied; front-end applies slippage). */
  minAmounts: bigint[];
  /** Inner _data to pass as _data to UniversalRouter.createIndex. */
  calldata: Hex;
}

/** Input for buyBundle (from front-end). */
export interface TradeBundleParams {
  deadline?: bigint;
  contractAddresses?: ContractAddresses;
  printLogs?: boolean;
  routeHints?: RouteHints;
}

/** Result of a bundle buy: inner _data for Universal Router + ETH cost (no slippage buffer). */
export interface BundleBuyResult {
  /** Inner _data to pass as third argument to UniversalRouter.swapETHForExactTokens(bundleAddress, amount, calldata, deadline). Front must build the full tx and set msg.value = ethCost (plus slippage). */
  calldata: Hex;
  /** WETH cost for the best scenario (raw, no buffer -- frontend handles slippage). */
  ethCost: bigint;
}

/** Result of a bundle sell: inner _data for Universal Router + ETH proceeds (no slippage minimum). */
export interface BundleSellResult {
  /** Inner _data to pass as fourth argument to UniversalRouter.swapExactTokensForETH(bundleAddress, amount, minEthOut, calldata, deadline). Front must build the full tx. */
  calldata: Hex;
  /** WETH received for the best scenario (raw -- frontend handles slippage). */
  ethProceeds: bigint;
}

/**
 * Production function: find the best route to buy a bundle and return the
 * inner _data for the Universal Router + ETH cost.
 *
 * Compares direct swap vs mint (with nested bundle permutations) and picks
 * the cheapest scenario. No on-chain simulation is performed.
 *
 * The returned calldata is the inner _data only. The front must call
 * UniversalRouter.swapETHForExactTokens(bundleAddress, amount, calldata, deadline)
 * with msg.value = ethCost (plus slippage).
 *
 * @param client  - viem PublicClient connected to the target chain
 * @param bundleAddress - Address of the bundle token to buy
 * @param amount  - Amount of bundle tokens to buy (in the token's decimals, e.g. 1000n * 10n**18n)
 * @param config - Optional configuration overrides
 * @returns BundleBuyResult with inner _data (calldata) and ethCost
 */
export async function buyBundle(
  client: PublicClient,
  bundleAddress: Address,
  amount: bigint,
  config?: TradeBundleParams
): Promise<BundleBuyResult> {
  const router = new Router(client, config?.contractAddresses ?? DEFAULT_CONTRACT_ADDRESSES);
  registerAdaptersForChain(router, client, client.chain?.id ?? 1, config?.contractAddresses ?? DEFAULT_CONTRACT_ADDRESSES);

  // The inner operations always route tokens through the Universal Router itself.
  const recipient = config?.contractAddresses?.UNIVERSAL_ROUTER ?? DEFAULT_CONTRACT_ADDRESSES.UNIVERSAL_ROUTER;

  const result = await router.findBestExactOutWithBundle(
    ["ETH", bundleAddress],
    amount,
    recipient,
    {
      isBundle: { token: bundleAddress, isBuying: true },
      printLogs: config?.printLogs ?? false,
      routeHints: config?.routeHints
    }
  );

  return {
    calldata: result.calldata,
    ethCost: result.best.amountIn,
  };
}

/**
 * Production function: find the best route to sell a bundle and return the
 * inner _data for the Universal Router + ETH proceeds.
 *
 * Compares direct swap vs burn (with nested bundle permutations) and picks
 * the most profitable scenario. No on-chain simulation is performed.
 *
 * The returned calldata is the inner _data only. The front must call
 * UniversalRouter.swapExactTokensForETH(bundleAddress, amount, minEthOut, calldata, deadline).
 *
 * @param client  - viem PublicClient connected to the target chain
 * @param bundleAddress - Address of the bundle token to sell
 * @param amount  - Amount of bundle tokens to sell (in the token's decimals, e.g. 600n * 10n**18n)
 * @param config - Optional configuration overrides
 * @returns BundleSellResult with inner _data (calldata) and ethProceeds
 */
export async function sellBundle(
  client: PublicClient,
  bundleAddress: Address,
  amount: bigint,
  config?: TradeBundleParams
): Promise<BundleSellResult> {
  const router = new Router(client, config?.contractAddresses ?? DEFAULT_CONTRACT_ADDRESSES);
  registerAdaptersForChain(router, client, client.chain?.id ?? 1, config?.contractAddresses ?? DEFAULT_CONTRACT_ADDRESSES);

  // The inner operations always route tokens through the Universal Router itself.
  const recipient = config?.contractAddresses?.UNIVERSAL_ROUTER ?? DEFAULT_CONTRACT_ADDRESSES.UNIVERSAL_ROUTER;

  const result = await router.findBestExactInWithBundle(
    [bundleAddress, "ETH"],
    amount,
    recipient,
    {
      isBundle: { token: bundleAddress, isBuying: false },
      printLogs: config?.printLogs ?? false,
      routeHints: config?.routeHints
    }
  );

  return {
    calldata: result.calldata,
    ethProceeds: result.best.amountOut,
  };
}

/**
 * Production function: quote create-index. Finds the best exact-in route per token,
 * returns minAmounts (no slippage) and the inner _data calldata.
 *
 * Front-end is responsible for token ordering, weights, deadline, totalEth (sum of
 * ethAmounts), and applying slippage to minAmounts before building the full tx via
 * encodeFunctionData(createIndex, [indexParams, tokens, userProvidedAmounts, minAmounts,
 * weights, initialSupply, calldata, deadline]).
 *
 * @param client - viem PublicClient connected to the target chain
 * @param params - tokens and ethAmounts (one per token); optional contractAddresses override
 * @returns CreateIndexResult with minAmounts and calldata (inner _data)
 */
export async function quoteCreateIndex(
  client: PublicClient,
  params: CreateIndexParams
): Promise<CreateIndexResult> {
  const router = new Router(client, params.contractAddresses ?? DEFAULT_CONTRACT_ADDRESSES);
  registerAdaptersForChain(router, client, client.chain?.id ?? 1, params.contractAddresses ?? DEFAULT_CONTRACT_ADDRESSES);

  const { minAmounts, data } = await router.findBestCreateIndexQuotes(params.tokens, params.ethAmounts, params.routeHints);

  return {
    minAmounts,
    calldata: data,
  };
}

// ---------------------------------------------------------------------------
// Bundle Quotation
// ---------------------------------------------------------------------------

/** Optional config for quoteBundles. */
export interface BundleQuoteParams {
  contractAddresses?: ContractAddresses;
  printLogs?: boolean;
  routeHints?: RouteHints;
}

/** Per-token valuation breakdown inside a bundle. */
export interface TokenValuation {
  token: Address;
  amount: bigint;
  valueETH: bigint;
}

/** Result of quoting a single bundle. */
export interface BundleQuoteResult {
  bundleAddress: Address;
  /** Raw total supply (always 18 decimals). */
  totalSupply: bigint;
  /** ETH value of the entire total supply (wei). */
  totalSupplyValueETH: bigint;
  /** ETH value of a single bundle token (wei, i.e. totalSupplyValueETH * 1e18 / totalSupply). */
  singleTokenValueETH: bigint;
  /** Per-token breakdown showing each underlying asset's amount and ETH value. */
  tokenBreakdown: TokenValuation[];
}

/**
 * Quote one or multiple bundles in exactly 3 RPC multicalls.
 *
 * Decomposes each bundle via Decomposer.holdings(), quotes every unique leaf
 * token in both directions (buy with 0.01 ETH, sell the result back), and
 * averages the two prices to derive a mid-market ETH valuation.
 *
 * @param client - viem PublicClient connected to the target chain
 * @param bundleAddresses - One or more bundle addresses to quote
 * @param config - Optional overrides (contract addresses, logging)
 * @returns One BundleQuoteResult per bundle address
 */
export async function quoteBundles(
  client: PublicClient,
  bundleAddresses: Address[],
  config?: BundleQuoteParams
): Promise<BundleQuoteResult[]> {
  const addresses = config?.contractAddresses ?? DEFAULT_CONTRACT_ADDRESSES;
  const chainId = client.chain?.id ?? 1;
  const adapters = getAdapterSpecsForChain(chainId, { includeQuoteOnly: true }).map((s) => s.create(client, chainId, addresses));
  return computeBundleQuotes(client, bundleAddresses, addresses, adapters, config?.printLogs ?? false, config?.routeHints);
}
