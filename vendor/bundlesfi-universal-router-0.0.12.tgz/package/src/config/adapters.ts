import type { PublicClient } from "viem";
import type { DexAdapter } from "../adapters/DexAdapter.js";
import { UniswapV2Adapter } from "../adapters/UniswapV2Adapter.js";
import { UniswapV3Adapter } from "../adapters/UniswapV3Adapter.js";
import { BundlesSwapAdapter } from "../adapters/BundlesSwapAdapter.js";
import { BundlesIndexSwapAdapter } from "../adapters/BundlesIndexSwapAdapter.js";
import { AntfarmV1Adapter } from "../adapters/AntfarmV1Adapter.js";
import { TraderJoeV2Adapter } from "../adapters/TraderJoeV2Adapter.js";
import { UniswapV4Adapter } from "../adapters/UniswapV4Adapter.js";
import { type ContractAddresses, DEFAULT_CONTRACT_ADDRESSES } from "./addresses.js";

/** Chain IDs. */
export const CHAIN_ID_MAINNET = 1;
export const CHAIN_ID_FUJI = 43113;

export interface AdapterSpec {
  /** Chain IDs on which this adapter is available. */
  chains: number[];
  /** Factory that returns the adapter instance. Receives chainId for chain-specific addresses. */
  create: (client: PublicClient, chainId: number, contractAddresses: ContractAddresses) => DexAdapter;
  /** If true, this adapter only supports quoting (no calldata generation). */
  quoteOnly?: boolean;
}

const ADAPTER_SPECS: AdapterSpec[] = [
  {
    chains: [CHAIN_ID_MAINNET],
    create: (client, _, config) => new UniswapV2Adapter(client, config.UNISWAP_V2_ROUTER, config.WETH),
  },
  {
    chains: [CHAIN_ID_MAINNET],
    create: (client, _, config) =>
      new UniswapV3Adapter(
        client,
        config.UNISWAP_V3_ROUTER,
        config.UNISWAP_V3_QUOTER,
        config.WETH,
        3000
      ),
  },
  {
    chains: [CHAIN_ID_MAINNET],
    create: (client, _, config) =>
      new UniswapV3Adapter(
        client,
        config.UNISWAP_V3_ROUTER,
        config.UNISWAP_V3_QUOTER,
        config.WETH,
        500
      ),
  },
  {
    chains: [CHAIN_ID_MAINNET],
    create: (client, _, config) =>
      new UniswapV3Adapter(
        client,
        config.UNISWAP_V3_ROUTER,
        config.UNISWAP_V3_QUOTER,
        config.WETH,
        100
      ),
  },
  {
    chains: [CHAIN_ID_MAINNET],
    create: (client, _, config) =>
      new UniswapV3Adapter(
        client,
        config.UNISWAP_V3_ROUTER,
        config.UNISWAP_V3_QUOTER,
        config.WETH,
        10000
      ),
  },
  {
    chains: [CHAIN_ID_MAINNET, CHAIN_ID_FUJI],
    create: (client, chainId, config) =>
      new BundlesSwapAdapter(
        client,
        chainId === CHAIN_ID_FUJI
          ? config.BUNDLES_SWAP_ROUTER_FUJI
          : config.BUNDLES_SWAP_ROUTER_MAINNET,
        chainId === CHAIN_ID_FUJI
          ? config.BUNDLES_PROTOCOL_TOKEN_FUJI
          : config.BUNDLES_PROTOCOL_TOKEN_MAINNET,
        config.WETH
      ),
  },
  {
    chains: [CHAIN_ID_MAINNET, CHAIN_ID_FUJI],
    create: (client, chainId, config) =>
      new BundlesIndexSwapAdapter(
        client,
        chainId === CHAIN_ID_FUJI
          ? config.BUNDLES_INDEX_SWAP_ROUTER_FUJI
          : config.BUNDLES_INDEX_SWAP_ROUTER_MAINNET,
        config.WETH,
        10
      ),
  },
  {
    chains: [CHAIN_ID_MAINNET, CHAIN_ID_FUJI],
    create: (client, chainId, config) =>
      new BundlesIndexSwapAdapter(
        client,
        chainId === CHAIN_ID_FUJI
          ? config.BUNDLES_INDEX_SWAP_ROUTER_FUJI
          : config.BUNDLES_INDEX_SWAP_ROUTER_MAINNET,
        config.WETH,
        222
      ),
  },
  {
    chains: [CHAIN_ID_MAINNET],
    create: (client, _, config) =>
      new AntfarmV1Adapter(
        client,
        config.ANTFARM_V1_ROUTER_MAINNET,
        config.ANTFARM_V1_QUOTER_MAINNET,
        config.ANTFARM_TOKEN_MAINNET,
        config.WETH
      ),
  },
  {
    chains: [CHAIN_ID_MAINNET],
    quoteOnly: true,
    create: (client, _, config) =>
      new UniswapV4Adapter(client, config.UNISWAP_V4_QUOTER, config.WETH, 500, 10),
  },
  {
    chains: [CHAIN_ID_MAINNET],
    quoteOnly: true,
    create: (client, _, config) =>
      new UniswapV4Adapter(client, config.UNISWAP_V4_QUOTER, config.WETH, 3000, 60),
  },
  {
    chains: [CHAIN_ID_MAINNET],
    quoteOnly: true,
    create: (client, _, config) =>
      new UniswapV4Adapter(client, config.UNISWAP_V4_QUOTER, config.WETH, 10000, 200),
  },
  {
    chains: [CHAIN_ID_MAINNET],
    quoteOnly: true,
    create: (client, _, config) =>
      new UniswapV4Adapter(client, config.UNISWAP_V4_QUOTER, config.WETH, 100, 1),
  },
  {
    chains: [CHAIN_ID_FUJI],
    create: (client, _, config) =>
      new TraderJoeV2Adapter(client, config.TRADERJOE_V2_ROUTER_FUJI, config.WETH),
  },
];

/**
 * Returns adapter specs that are available on the given chain.
 * Use with the current chain id (e.g. CHAIN.id) so the router only registers adapters for its chain.
 */
export function getAdapterSpecsForChain(
  chainId: number,
  options?: { includeQuoteOnly?: boolean },
): AdapterSpec[] {
  return ADAPTER_SPECS.filter(
    (spec) =>
      spec.chains.includes(chainId) &&
      (options?.includeQuoteOnly || !spec.quoteOnly),
  );
}
