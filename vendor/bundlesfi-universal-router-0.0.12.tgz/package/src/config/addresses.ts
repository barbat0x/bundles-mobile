import { createPublicClient, http, type Address, type PublicClient } from "viem";
import { mainnet } from "viem/chains";

/**
 * Override these for your target chain and deployments.
 * Example values below are Ethereum mainnet Uniswap V2/V3.
 */
export interface ContractAddresses {
  WETH: Address;
  UNISWAP_V2_ROUTER: Address;
  UNISWAP_V2_FACTORY: Address;
  UNISWAP_V3_ROUTER: Address;
  UNISWAP_V3_QUOTER: Address;
  RECIPIENT_PLACEHOLDER: Address;
  TOKEN_A: Address;
  TOKEN_B: Address;
  BUNDLES_SWAP_ROUTER_MAINNET: Address;
  BUNDLES_SWAP_ROUTER_FUJI: Address;
  BUNDLES_INDEX_SWAP_ROUTER_MAINNET: Address;
  BUNDLES_INDEX_SWAP_ROUTER_FUJI: Address;
  ANTFARM_V1_ROUTER_MAINNET: Address;
  ANTFARM_V1_QUOTER_MAINNET: Address;
  TRADERJOE_V2_ROUTER_FUJI: Address;
  BUNDLES_PROTOCOL_TOKEN_MAINNET: Address;
  BUNDLES_PROTOCOL_TOKEN_FUJI: Address;
  ANTFARM_TOKEN_MAINNET: Address;
  DECOMPOSER_MAINNET: Address;
  AAVE_V3_PROTOCOL_DATA_PROVIDER: Address;
  AAVE_V3_POOL: Address;
  UNISWAP_V4_QUOTER: Address;
  UNIVERSAL_ROUTER: Address;
}

export const DEFAULT_CONTRACT_ADDRESSES: ContractAddresses = {
  /** WETH address (used when path contains "ETH") */
  WETH: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
  /** Uniswap V2 Router 02 */
  UNISWAP_V2_ROUTER: "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D",
  /** Uniswap V2 Factory (for reference; not used in minimal router) */
  UNISWAP_V2_FACTORY: "0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f",
  /** Uniswap V3 SwapRouter */
  UNISWAP_V3_ROUTER: "0xE592427A0AEce92De3Edee1F18E0157C05861564",
  /** Uniswap V3 Quoter V2 (or Quoter; adjust ABI if using QuoterV2) */
  UNISWAP_V3_QUOTER: "0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6",
  /** Placeholder replaced with actual recipient in encodeForUniversalRouter */
  RECIPIENT_PLACEHOLDER: "0x0000000000000000000000000000000000000001",
  /** Demo tokens (set via env or override for your test) */
  TOKEN_A: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", // USDC
  TOKEN_B: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", // WETH
  /** BundleSwap Router addresses (chain-specific) */
  BUNDLES_SWAP_ROUTER_MAINNET: "0x6b8Cd00Eeff2e8D9f563869B068D9C64EF1Dd791",
  BUNDLES_SWAP_ROUTER_FUJI: "0x63147AC353A063eB01bA65F104b0a065a0643B7e",
  /** BundlesIndexSwap Router addresses (same as BundleSwap on each chain) */
  BUNDLES_INDEX_SWAP_ROUTER_MAINNET: "0x6b8Cd00Eeff2e8D9f563869B068D9C64EF1Dd791", // BUNDLES_SWAP_ROUTER_MAINNET
  BUNDLES_INDEX_SWAP_ROUTER_FUJI: "0x63147AC353A063eB01bA65F104b0a065a0643B7e", // BUNDLES_SWAP_ROUTER_FUJI
  /** Antfarm V1 Router and Quoter addresses (mainnet only) */
  ANTFARM_V1_ROUTER_MAINNET: "0x6D9f0eb21D77C6d24bE49a579508471E937D5418",
  ANTFARM_V1_QUOTER_MAINNET: "0x186982aB33D1D323F2d471571B7081c56d27Fa51",
  /** TraderJoe V2 Router address (Fuji testnet) */
  TRADERJOE_V2_ROUTER_FUJI: "0xd7f655E3376cE2D7A2b08fF01Eb3B1023191A901",
  /** Protocol token addresses (for path validation) */
  BUNDLES_PROTOCOL_TOKEN_MAINNET: "0x695f775551fb0D28b64101c9507c06F334b4bA86", // TODO: Set actual address
  BUNDLES_PROTOCOL_TOKEN_FUJI: "0xCe1b3739c0620f9a3c633CFfA197cA7B1795D6d7", // TODO: Set actual address
  ANTFARM_TOKEN_MAINNET: "0x518b63Da813D46556FEa041A88b52e3CAa8C16a8", // TODO: Set actual address
  /** Decomposer contract address (mainnet) */
  DECOMPOSER_MAINNET: "0x4a3d0b480a3A017Eb940f75bb5E8e32050fC6da2",
  /** Aave V3 Protocol Data Provider (mainnet). Used to fetch aToken<->underlying mappings. */
  AAVE_V3_PROTOCOL_DATA_PROVIDER: "0x497a1994c46d4f6C864904A9f1fac6328Cb7C8a6",
  /** Aave V3 Pool (mainnet). Used for supply (mint aToken) and withdraw (burn aToken). */
  AAVE_V3_POOL: "0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2",
  /** Uniswap V4 Quoter (mainnet). Used for quoting swaps on V4 pools (native ETH). */
  UNISWAP_V4_QUOTER: "0x52f0e24d1c21c8a0cb1e5a5dd6198556bd9e1203",
  /** Universal Router contract (mainnet). Used for simulation and building outer swapETHForExactTokens / swapExactTokensForETH calls. */
  UNIVERSAL_ROUTER: "0x1751F0eADFeB3d618B9e4176edDC9E7D24657c00",
};
