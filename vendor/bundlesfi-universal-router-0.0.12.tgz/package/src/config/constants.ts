/** Seconds from now for the Universal Router outer deadline (swapETHForExactTokens, swapExactTokensForETH, createIndex). */
export const UNIVERSAL_ROUTER_DEADLINE_SECONDS = 300;
