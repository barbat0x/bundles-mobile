import type { Address } from "viem";

/**
 * Generate fee path for protocol token swaps.
 * Returns an array of fee values (10) with length = path.length - 1.
 */
export function getFeePath(path: Address[]): number[] {
  return Array(path.length - 1).fill(10);
}

/**
 * Validate that a path is valid for protocol token swaps.
 * Requirements:
 * - Path must have at least 2 tokens
 * - Every consecutive pair must include the protocol token
 * - Protocol token cannot appear twice in a row
 *
 * @throws Error if path is invalid
 */
export function validateProtocolTokenPath(
  path: Address[],
  protocolToken: Address
): void {
  if (path.length < 2) {
    throw new Error("Path must contain at least 2 tokens");
  }

  for (let i = 0; i < path.length - 1; i++) {
    const tokenA = path[i]!;
    const tokenB = path[i + 1]!;

    // Check that at least one of each consecutive pair is the protocol token
    if (tokenA !== protocolToken && tokenB !== protocolToken) {
      throw new Error(
        "Protocol token exchanges only support paths where each consecutive pair includes the protocol token"
      );
    }

    // Check that protocol token doesn't appear twice in a row
    if (tokenA === protocolToken && tokenB === protocolToken) {
      throw new Error("Protocol token cannot appear twice in a row");
    }
  }
}
