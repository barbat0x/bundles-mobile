import type { Address, PublicClient } from "viem";
import type { CalldataBuilder } from "../calldata/CalldataBuilder.js";
import type { DexAdapter, MulticallContract } from "./DexAdapter.js";
import { bundlesRouterAbi } from "../contracts/abis.js";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";

/** Default deadline: far future (max uint256 would be even safer). */
const DEFAULT_DEADLINE = 2n ** 32n - 1n;

/** Fee tier to display name (10 -> "BundlesIndexSwap", others -> "BundlesIndexSwap_20", etc.). */
function feeToName(fee: number): string {
  if (fee === 10) return "BundlesIndexSwap";
  return `BundlesIndexSwap_${fee}`;
}

/**
 * BundlesIndexSwap adapter: 2-token paths only, one must be WETH.
 * Fee in basis points (e.g. 10 = 0.1%). The same fee is used for all calls.
 */
export class BundlesIndexSwapAdapter implements DexAdapter {
  readonly name: string;
  readonly fee: number;

  constructor(
    private client: PublicClient,
    private routerAddress: Address = DEFAULT_CONTRACT_ADDRESSES.BUNDLES_INDEX_SWAP_ROUTER_MAINNET,
    private weth: Address = DEFAULT_CONTRACT_ADDRESSES.WETH,
    fee: number = 10,
  ) {
    this.fee = fee;
    this.name = feeToName(fee);
  }

  private _validToken(token: Address): boolean {
    return token === this.weth;
  }

  private _validatePath(path: Address[]): void {
    if (path.length !== 2) {
      throw new Error(
        `${this.name} only supports 2-token paths, got ${path.length}`
      );
    }
    if (!this._validToken(path[0]!) && !this._validToken(path[1]!)) {
      throw new Error(
        `${this.name} requires one token in the path to be WETH/ETH`
      );
    }
  }

  canHandlePath?(path: Address[], _isExactIn: boolean): boolean {
    if (path.length !== 2) return false;
    return this._validToken(path[0]!) || this._validToken(path[1]!);
  }

  async quoteExactIn(path: Address[], amountIn: bigint): Promise<bigint> {
    this._validatePath(path);
    const token0 = path[0]!;
    const token1 = path[1]!;

    if (this._validToken(token0)) {
      // ETH/WETH -> Token
      return await this.client.readContract({
        address: this.routerAddress,
        abi: bundlesRouterAbi,
        functionName: "estimateExactETHForTokens",
        args: [token1, this.fee, amountIn],
      });
    } else {
      // Token -> ETH/WETH
      return await this.client.readContract({
        address: this.routerAddress,
        abi: bundlesRouterAbi,
        functionName: "estimateExactTokensForETH",
        args: [token0, this.fee, amountIn],
      });
    }
  }

  async quoteExactOut(path: Address[], amountOut: bigint): Promise<bigint> {
    this._validatePath(path);
    const token0 = path[0]!;
    const token1 = path[1]!;

    if (!this._validToken(token0)) {
      throw new Error(
        `${this.name} quoteExactOut requires the first token to be WETH/ETH`
      );
    }

    // ETH/WETH -> Token (exact out)
    return await this.client.readContract({
      address: this.routerAddress,
      abi: bundlesRouterAbi,
      functionName: "estimateETHForExactTokens",
      args: [token1, this.fee, amountOut],
    });
  }

  getQuoteExactInContract(path: Address[], amountIn: bigint): MulticallContract {
    this._validatePath(path);
    const token0 = path[0]!;
    const token1 = path[1]!;

    if (this._validToken(token0)) {
      return {
        address: this.routerAddress,
        abi: bundlesRouterAbi,
        functionName: "estimateExactETHForTokens",
        args: [token1, this.fee, amountIn],
      };
    } else {
      return {
        address: this.routerAddress,
        abi: bundlesRouterAbi,
        functionName: "estimateExactTokensForETH",
        args: [token0, this.fee, amountIn],
      };
    }
  }

  getQuoteExactOutContract(path: Address[], amountOut: bigint): MulticallContract {
    this._validatePath(path);
    const token0 = path[0]!;
    const token1 = path[1]!;

    if (!this._validToken(token0)) {
      throw new Error(
        `${this.name} quoteExactOut requires the first token to be WETH/ETH`
      );
    }

    return {
      address: this.routerAddress,
      abi: bundlesRouterAbi,
      functionName: "estimateETHForExactTokens",
      args: [token1, this.fee, amountOut],
    };
  }

  buildExactIn(
    builder: CalldataBuilder,
    path: Address[],
    amountIn: bigint,
    recipient: Address
  ): void {
    this._validatePath(path);
    const token0 = path[0]!;
    const token1 = path[1]!;
    const amountOutMin = 0n;

    if (token0 === this.weth && token1 === this.weth) {
      throw new Error(`${this.name} does not support WETH->WETH swaps`);
    }

    // Note: In normalized paths, "ETH" becomes WETH address.
    // We use ETH functions (payable) when token0 is WETH (treating as native ETH).
    // For WETH->Token swaps where WETH is explicitly used (not native), we'd use swapExactWETHForTokens,
    // but since paths are normalized, we can't distinguish. Using ETH functions for simplicity.
    if (token0 === this.weth) {
      // WETH -> Token: use swapExactWETHForTokens (non-payable) with approval.
      // The UniversalRouter wraps msg.value to WETH before executing inner operations,
      // so the inner call must use the WETH variant (same reasoning as buildExactOut).
      builder.addApprove(this.weth, this.routerAddress, amountIn, amountIn);
      builder.addCall(
        this.routerAddress,
        bundlesRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapExactWETHForTokens",
        [amountIn, token1, this.fee, recipient, DEFAULT_DEADLINE, amountOutMin]
      );
    } else if (token1 === this.weth) {
      // Token -> ETH/WETH (need approval)
      builder.addApprove(token0, this.routerAddress, amountIn, amountIn);
      builder.addCall(
        this.routerAddress,
        bundlesRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapExactTokensForETH",
        [token0, this.fee, recipient, DEFAULT_DEADLINE, amountIn, amountOutMin]
      );
    } else {
      // This shouldn't happen if validation is correct, but handle for safety
      throw new Error(
        `${this.name} requires one token in the path to be WETH/ETH`
      );
    }
  }

  buildExactOut(
    builder: CalldataBuilder,
    path: Address[],
    amountOut: bigint,
    recipient: Address,
    amountInMax?: bigint
  ): void {
    this._validatePath(path);
    const token0 = path[0]!;
    const token1 = path[1]!;

    if (!this._validToken(token0)) {
      throw new Error(
        `${this.name} does not support exact-out swaps when first token is not WETH/ETH`
      );
    }

    if (token1 === this.weth) {
      throw new Error(
        `${this.name} does not support Token->ETH exact-out swaps`
      );
    }

    // ETH/WETH -> Token (exact out)
    // When used inside UniversalRouter.swapETHForExactTokens(), the router has already wrapped
    // msg.value to WETH, so the inner call must use swapWETHForExactTokens (with approval), not
    // swapETHForExactTokens (payable), otherwise the Bundles router receives 0 ETH and the swap fails.
    const maxUint256 = 2n ** 256n - 1n;
    const approvalAmount = maxUint256;
    const actualAmount = amountInMax ?? maxUint256;
    builder.addApprove(this.weth, this.routerAddress, approvalAmount, actualAmount);
    builder.addCall(
      this.routerAddress,
      bundlesRouterAbi as readonly unknown[] as import("viem").Abi,
      "swapWETHForExactTokens",
      [maxUint256, token1, this.fee, recipient, DEFAULT_DEADLINE, amountOut]
    );
  }
}
