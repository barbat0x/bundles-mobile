import type { Address, PublicClient } from "viem";
import { validatePathV2 } from "../router/path.js";
import type { CalldataBuilder } from "../calldata/CalldataBuilder.js";
import type { DexAdapter, MulticallContract } from "./DexAdapter.js";
import { antfarmRouterAbi } from "../contracts/abis.js";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";
import {
  getFeePath,
  validateProtocolTokenPath,
} from "./protocolTokenHelpers.js";

/** Default deadline: far future (max uint256 would be even safer). */
const DEFAULT_DEADLINE = 2n ** 32n - 1n;
const MAX_FEE = 2n ** 256n - 1n;

/** Antfarm V1 adapter: protocol token swaps with separate quoter for reads. */
export class AntfarmV1Adapter implements DexAdapter {
  name = "AntfarmV1";

  constructor(
    private client: PublicClient,
    private routerAddress: Address = DEFAULT_CONTRACT_ADDRESSES.ANTFARM_V1_ROUTER_MAINNET,
    private quoterAddress: Address = DEFAULT_CONTRACT_ADDRESSES.ANTFARM_V1_QUOTER_MAINNET,
    private protocolToken: Address = DEFAULT_CONTRACT_ADDRESSES.ANTFARM_TOKEN_MAINNET,
    private weth: Address = DEFAULT_CONTRACT_ADDRESSES.WETH
  ) { }

  canHandlePath?(path: Address[], _isExactIn: boolean): boolean {
    if (path.length < 2) return false;
    try {
      validateProtocolTokenPath(path, this.protocolToken);
      return true;
    } catch {
      return false;
    }
  }

  async quoteExactIn(path: Address[], amountIn: bigint): Promise<bigint> {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const fees = getFeePath(path);
    // Use quoter address for quotes
    const amounts = await this.client.readContract({
      address: this.quoterAddress,
      abi: antfarmRouterAbi,
      functionName: "getAmountsOut",
      args: [amountIn, path, fees],
    });
    return amounts.length > 0 ? amounts[amounts.length - 1]! : 0n;
  }

  async quoteExactOut(path: Address[], amountOut: bigint): Promise<bigint> {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const fees = getFeePath(path);
    // Use quoter address for quotes
    const amounts = await this.client.readContract({
      address: this.quoterAddress,
      abi: antfarmRouterAbi,
      functionName: "getAmountsIn",
      args: [amountOut, path, fees],
    });
    return amounts.length > 0 ? amounts[0]! : 0n;
  }

  getQuoteExactInContract(path: Address[], amountIn: bigint): MulticallContract {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const fees = getFeePath(path);
    // Use quoter address for quotes
    return {
      address: this.quoterAddress,
      abi: antfarmRouterAbi,
      functionName: "getAmountsOut",
      args: [amountIn, path, fees],
    };
  }

  getQuoteExactOutContract(path: Address[], amountOut: bigint): MulticallContract {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const fees = getFeePath(path);
    // Use quoter address for quotes
    return {
      address: this.quoterAddress,
      abi: antfarmRouterAbi,
      functionName: "getAmountsIn",
      args: [amountOut, path, fees],
    };
  }

  buildExactIn(
    builder: CalldataBuilder,
    path: Address[],
    amountIn: bigint,
    recipient: Address
  ): void {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const tokenIn = path[0]!;
    const tokenOut = path[path.length - 1]!;
    const fees = getFeePath(path);
    const amountOutMin = 0n;

    // Determine swap function based on whether path starts/ends with WETH
    if (tokenIn === this.weth) {
      // ETH to token(s) - payable
      builder.addCall(
        this.routerAddress,
        antfarmRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapExactETHForTokens",
        [
          {
            amountOutMin,
            maxFee: MAX_FEE,
            path,
            fees,
            to: recipient,
            deadline: DEFAULT_DEADLINE,
          },
        ]
      );
    } else if (tokenOut === this.weth) {
      // Token(s) to ETH - need approval
      builder.addApprove(tokenIn, this.routerAddress, amountIn, amountIn);
      builder.addCall(
        this.routerAddress,
        antfarmRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapExactTokensForETH",
        [
          {
            amountIn,
            amountOutMin,
            maxFee: MAX_FEE,
            path,
            fees,
            to: recipient,
            deadline: DEFAULT_DEADLINE,
          },
        ]
      );
    } else {
      // Token to token - need approval
      builder.addApprove(tokenIn, this.routerAddress, amountIn, amountIn);
      builder.addCall(
        this.routerAddress,
        antfarmRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapExactTokensForTokens",
        [
          {
            amountIn,
            amountOutMin,
            maxFee: MAX_FEE,
            path,
            fees,
            to: recipient,
            deadline: DEFAULT_DEADLINE,
          },
        ]
      );
    }
  }

  buildExactOut(
    builder: CalldataBuilder,
    path: Address[],
    amountOut: bigint,
    recipient: Address,
    amountInMax?: bigint
  ): void {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const tokenIn = path[0]!;
    const tokenOut = path[path.length - 1]!;
    const fees = getFeePath(path);
    const maxUint256 = 2n ** 256n - 1n;
    const approvalAmount = maxUint256;
    const actualAmount = amountInMax ?? maxUint256;

    // Determine swap function based on whether path starts/ends with WETH
    if (tokenIn === this.weth) {
      // ETH to token(s) - payable
      builder.addCall(
        this.routerAddress,
        antfarmRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapETHForExactTokens",
        [
          {
            amountOut,
            maxFee: MAX_FEE,
            path,
            fees,
            to: recipient,
            deadline: DEFAULT_DEADLINE,
          },
        ]
      );
    } else if (tokenOut === this.weth) {
      // Token(s) to ETH - need approval
      builder.addApprove(tokenIn, this.routerAddress, approvalAmount, actualAmount);
      builder.addCall(
        this.routerAddress,
        antfarmRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapTokensForExactETH",
        [
          {
            amountOut,
            amountInMax: maxUint256,
            maxFee: MAX_FEE,
            path,
            fees,
            to: recipient,
            deadline: DEFAULT_DEADLINE,
          },
        ]
      );
    } else {
      // Token to token - need approval
      builder.addApprove(tokenIn, this.routerAddress, approvalAmount, actualAmount);
      builder.addCall(
        this.routerAddress,
        antfarmRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapTokensForExactTokens",
        [
          {
            amountOut,
            amountInMax: maxUint256,
            maxFee: MAX_FEE,
            path,
            fees,
            to: recipient,
            deadline: DEFAULT_DEADLINE,
          },
        ]
      );
    }
  }
}
