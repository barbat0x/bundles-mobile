import type { Address, Hex } from "viem";
import type { CalldataBuilder } from "../calldata/CalldataBuilder.js";

/**
 * Viem multicall contract entry: one item in the contracts array for publicClient.multicall().
 */
export interface MulticallContract {
  address: Address;
  abi: readonly unknown[];
  functionName: string;
  args?: readonly unknown[];
}

export interface DexAdapter {
  name: string;

  quoteExactIn(path: Address[], amountIn: bigint): Promise<bigint>;
  quoteExactOut(path: Address[], amountOut: bigint): Promise<bigint>;

  /** Returns the contract call entry for multicall (exact-in quote). */
  getQuoteExactInContract(path: Address[], amountIn: bigint): MulticallContract;
  /** Returns the contract call entry for multicall (exact-out quote). */
  getQuoteExactOutContract(path: Address[], amountOut: bigint): MulticallContract;

  buildExactIn(
    builder: CalldataBuilder,
    path: Address[],
    amountIn: bigint,
    recipient: Address
  ): void;

  buildExactOut(
    builder: CalldataBuilder,
    path: Address[],
    amountOut: bigint,
    recipient: Address,
    /** Optional: quoted amountIn for exact-out (e.g. for WETH leg to avoid type(uint256).max). */
    amountInMax?: bigint
  ): void;

  /**
   * Optional method to check if adapter can handle a specific path.
   * If not implemented, Router uses default logic (path.length >= 2, V3 => length 2).
   */
  canHandlePath?(path: Address[], isExactIn: boolean): boolean;
}
