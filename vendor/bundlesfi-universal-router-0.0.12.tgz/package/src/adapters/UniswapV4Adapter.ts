import type { Address, Hex, PublicClient } from "viem";
import type { CalldataBuilder } from "../calldata/CalldataBuilder.js";
import type { DexAdapter, MulticallContract } from "./DexAdapter.js";
import { uniswapV4QuoterAbi } from "../contracts/abis.js";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";

const ZERO_ADDRESS = "0x0000000000000000000000000000000000000000" as Address;
const EMPTY_HOOK_DATA = "0x" as Hex;

interface PoolKey {
  currency0: Address;
  currency1: Address;
  fee: number;
  tickSpacing: number;
  hooks: Address;
}

function v4FeeToName(fee: number, tickSpacing: number): string {
  return `UniswapV4_${fee}_ts${tickSpacing}`;
}

/**
 * Uniswap V4 adapter. Supports single-hop and multi-hop quoting via the V4Quoter.
 *
 * V4 pools use native ETH (address(0)) instead of WETH, so the adapter
 * transparently maps WETH to address(0) when constructing PoolKeys.
 *
 * Swap execution (buildExactIn/Out) is not yet implemented; only quoting is supported.
 */
export class UniswapV4Adapter implements DexAdapter {
  readonly name: string;
  private readonly fee: number;
  private readonly tickSpacing: number;
  private readonly hooks: Address;

  constructor(
    private client: PublicClient,
    private quoterAddress: Address = DEFAULT_CONTRACT_ADDRESSES.UNISWAP_V4_QUOTER,
    private weth: Address = DEFAULT_CONTRACT_ADDRESSES.WETH,
    fee: number = 3000,
    tickSpacing: number = 60,
    hooks: Address = ZERO_ADDRESS,
    name?: string,
  ) {
    this.fee = fee;
    this.tickSpacing = tickSpacing;
    this.hooks = hooks;
    this.name = name ?? v4FeeToName(fee, tickSpacing);
  }

  canHandlePath(path: Address[], _isExactIn: boolean): boolean {
    return path.length >= 2;
  }

  private isMultiHop(path: Address[]): boolean {
    return path.length > 2;
  }

  /** Map WETH to native ETH (address(0)) for V4 pool key construction. */
  private toCurrency(token: Address): Address {
    return token.toLowerCase() === this.weth.toLowerCase() ? ZERO_ADDRESS : token;
  }

  /**
   * Build a PoolKey for a single-hop swap and determine zeroForOne.
   * currency0 must be numerically lower than currency1.
   */
  private buildPoolKeyAndDirection(tokenIn: Address, tokenOut: Address): {
    poolKey: PoolKey;
    zeroForOne: boolean;
  } {
    const c0 = this.toCurrency(tokenIn);
    const c1 = this.toCurrency(tokenOut);
    const c0Lower = c0.toLowerCase();
    const c1Lower = c1.toLowerCase();
    const sorted = c0Lower < c1Lower;
    return {
      poolKey: {
        currency0: (sorted ? c0 : c1) as Address,
        currency1: (sorted ? c1 : c0) as Address,
        fee: this.fee,
        tickSpacing: this.tickSpacing,
        hooks: this.hooks,
      },
      zeroForOne: sorted,
    };
  }

  private buildSingleParams(tokenIn: Address, tokenOut: Address, amount: bigint) {
    const { poolKey, zeroForOne } = this.buildPoolKeyAndDirection(tokenIn, tokenOut);
    return {
      poolKey,
      zeroForOne,
      exactAmount: amount,
      hookData: EMPTY_HOOK_DATA,
    };
  }

  private buildMultiHopParams(path: Address[], amount: bigint, reverse: boolean) {
    const ordered = reverse ? [...path].reverse() : path;
    const exactCurrency = this.toCurrency(ordered[0]!);
    const pathKeys = [];
    for (let i = 1; i < ordered.length; i++) {
      pathKeys.push({
        intermediateCurrency: this.toCurrency(ordered[i]!),
        fee: this.fee,
        tickSpacing: this.tickSpacing,
        hooks: this.hooks,
        hookData: EMPTY_HOOK_DATA,
      });
    }
    return { exactCurrency, path: pathKeys, exactAmount: amount };
  }

  async quoteExactIn(path: Address[], amountIn: bigint): Promise<bigint> {
    if (this.isMultiHop(path)) {
      const params = this.buildMultiHopParams(path, amountIn, false);
      const result = await this.client.simulateContract({
        address: this.quoterAddress,
        abi: uniswapV4QuoterAbi,
        functionName: "quoteExactInput",
        args: [params],
      });
      return (result.result as readonly [bigint, bigint])[0];
    }
    const params = this.buildSingleParams(path[0]!, path[1]!, amountIn);
    const result = await this.client.simulateContract({
      address: this.quoterAddress,
      abi: uniswapV4QuoterAbi,
      functionName: "quoteExactInputSingle",
      args: [params],
    });
    return (result.result as readonly [bigint, bigint])[0];
  }

  async quoteExactOut(path: Address[], amountOut: bigint): Promise<bigint> {
    if (this.isMultiHop(path)) {
      const params = this.buildMultiHopParams(path, amountOut, true);
      const result = await this.client.simulateContract({
        address: this.quoterAddress,
        abi: uniswapV4QuoterAbi,
        functionName: "quoteExactOutput",
        args: [params],
      });
      return (result.result as readonly [bigint, bigint])[0];
    }
    const params = this.buildSingleParams(path[0]!, path[1]!, amountOut);
    const result = await this.client.simulateContract({
      address: this.quoterAddress,
      abi: uniswapV4QuoterAbi,
      functionName: "quoteExactOutputSingle",
      args: [params],
    });
    return (result.result as readonly [bigint, bigint])[0];
  }

  getQuoteExactInContract(path: Address[], amountIn: bigint): MulticallContract {
    if (this.isMultiHop(path)) {
      const params = this.buildMultiHopParams(path, amountIn, false);
      return {
        address: this.quoterAddress,
        abi: uniswapV4QuoterAbi,
        functionName: "quoteExactInput",
        args: [params],
      };
    }
    const params = this.buildSingleParams(path[0]!, path[1]!, amountIn);
    return {
      address: this.quoterAddress,
      abi: uniswapV4QuoterAbi,
      functionName: "quoteExactInputSingle",
      args: [params],
    };
  }

  getQuoteExactOutContract(path: Address[], amountOut: bigint): MulticallContract {
    if (this.isMultiHop(path)) {
      const params = this.buildMultiHopParams(path, amountOut, true);
      return {
        address: this.quoterAddress,
        abi: uniswapV4QuoterAbi,
        functionName: "quoteExactOutput",
        args: [params],
      };
    }
    const params = this.buildSingleParams(path[0]!, path[1]!, amountOut);
    return {
      address: this.quoterAddress,
      abi: uniswapV4QuoterAbi,
      functionName: "quoteExactOutputSingle",
      args: [params],
    };
  }

  buildExactIn(
    _builder: CalldataBuilder,
    _path: Address[],
    _amountIn: bigint,
    _recipient: Address,
  ): void {
    throw new Error("UniswapV4Adapter: buildExactIn not yet implemented");
  }

  buildExactOut(
    _builder: CalldataBuilder,
    _path: Address[],
    _amountOut: bigint,
    _recipient: Address,
    _amountInMax?: bigint,
  ): void {
    throw new Error("UniswapV4Adapter: buildExactOut not yet implemented");
  }
}
