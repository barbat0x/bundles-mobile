import type { Address, Hex, PublicClient } from "viem";
import { validatePathV3 } from "../router/path.js";
import type { CalldataBuilder } from "../calldata/CalldataBuilder.js";
import type { DexAdapter, MulticallContract } from "./DexAdapter.js";
import { uniswapV3QuoterAbi, uniswapV3RouterAbi } from "../contracts/abis.js";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";

const SQRT_PRICE_LIMIT_X96 = 0n;
const DEFAULT_DEADLINE = 2n ** 32n - 1n;

/** Fee tier to display name (3000 -> "UniswapV3", 500 -> "UniswapV3_005", etc.). */
function feeToName(fee: number): string {
  if (fee === 3000) return "UniswapV3";
  return `UniswapV3_${String(fee).padStart(3, "0")}`;
}

/**
 * Encode a Uniswap V3 multi-hop path as packed bytes.
 * Format: token0 (20 bytes) || fee (3 bytes) || token1 (20 bytes) || fee (3 bytes) || ...
 * For exact-output, the path is reversed (tokenOut first, tokenIn last).
 */
function encodeV3Path(tokens: Address[], fee: number, reverse: boolean): Hex {
  const ordered = reverse ? [...tokens].reverse() : tokens;
  let hex = ordered[0]!.slice(2).toLowerCase();
  for (let i = 1; i < ordered.length; i++) {
    hex += fee.toString(16).padStart(6, "0");
    hex += ordered[i]!.slice(2).toLowerCase();
  }
  return `0x${hex}` as Hex;
}

/**
 * Uniswap V3-style adapter. Supports single-hop (2 tokens) and multi-hop (3+ tokens).
 * Fee in hundredths of bps (e.g. 3000 = 0.3%). The same fee is used for all hops.
 */
export class UniswapV3Adapter implements DexAdapter {
  readonly name: string;
  private readonly fee: number;

  constructor(
    private client: PublicClient,
    private routerAddress: Address = DEFAULT_CONTRACT_ADDRESSES.UNISWAP_V3_ROUTER,
    private quoterAddress: Address = DEFAULT_CONTRACT_ADDRESSES.UNISWAP_V3_QUOTER,
    private weth: Address = DEFAULT_CONTRACT_ADDRESSES.WETH,
    fee: number = 3000,
    name?: string
  ) {
    this.fee = fee;
    this.name = name ?? feeToName(fee);
  }

  canHandlePath(path: Address[], _isExactIn: boolean): boolean {
    return path.length >= 2;
  }

  private isMultiHop(path: Address[]): boolean {
    return path.length > 2;
  }

  async quoteExactIn(path: Address[], amountIn: bigint): Promise<bigint> {
    if (this.isMultiHop(path)) {
      const encodedPath = encodeV3Path(path, this.fee, false);
      const result = await this.client.simulateContract({
        address: this.quoterAddress,
        abi: uniswapV3QuoterAbi,
        functionName: "quoteExactInput",
        args: [encodedPath, amountIn],
      });
      return result.result;
    }
    validatePathV3(path);
    const [tokenIn, tokenOut] = path;
    const result = await this.client.simulateContract({
      address: this.quoterAddress,
      abi: uniswapV3QuoterAbi,
      functionName: "quoteExactInputSingle",
      args: [tokenIn!, tokenOut!, this.fee, amountIn, SQRT_PRICE_LIMIT_X96],
    });
    return result.result;
  }

  async quoteExactOut(path: Address[], amountOut: bigint): Promise<bigint> {
    if (this.isMultiHop(path)) {
      const encodedPath = encodeV3Path(path, this.fee, true);
      const result = await this.client.simulateContract({
        address: this.quoterAddress,
        abi: uniswapV3QuoterAbi,
        functionName: "quoteExactOutput",
        args: [encodedPath, amountOut],
      });
      return result.result;
    }
    validatePathV3(path);
    const [tokenIn, tokenOut] = path;
    const result = await this.client.simulateContract({
      address: this.quoterAddress,
      abi: uniswapV3QuoterAbi,
      functionName: "quoteExactOutputSingle",
      args: [tokenIn!, tokenOut!, this.fee, amountOut, SQRT_PRICE_LIMIT_X96],
    });
    return result.result;
  }

  getQuoteExactInContract(path: Address[], amountIn: bigint): MulticallContract {
    if (this.isMultiHop(path)) {
      const encodedPath = encodeV3Path(path, this.fee, false);
      return {
        address: this.quoterAddress,
        abi: uniswapV3QuoterAbi,
        functionName: "quoteExactInput",
        args: [encodedPath, amountIn],
      };
    }
    validatePathV3(path);
    const [tokenIn, tokenOut] = path;
    return {
      address: this.quoterAddress,
      abi: uniswapV3QuoterAbi,
      functionName: "quoteExactInputSingle",
      args: [tokenIn!, tokenOut!, this.fee, amountIn, SQRT_PRICE_LIMIT_X96],
    };
  }

  getQuoteExactOutContract(path: Address[], amountOut: bigint): MulticallContract {
    if (this.isMultiHop(path)) {
      const encodedPath = encodeV3Path(path, this.fee, true);
      return {
        address: this.quoterAddress,
        abi: uniswapV3QuoterAbi,
        functionName: "quoteExactOutput",
        args: [encodedPath, amountOut],
      };
    }
    validatePathV3(path);
    const [tokenIn, tokenOut] = path;
    return {
      address: this.quoterAddress,
      abi: uniswapV3QuoterAbi,
      functionName: "quoteExactOutputSingle",
      args: [tokenIn!, tokenOut!, this.fee, amountOut, SQRT_PRICE_LIMIT_X96],
    };
  }

  buildExactIn(
    builder: CalldataBuilder,
    path: Address[],
    amountIn: bigint,
    recipient: Address
  ): void {
    const tokenIn = path[0]!;
    if (this.isMultiHop(path)) {
      const encodedPath = encodeV3Path(path, this.fee, false);
      builder.addApprove(tokenIn, this.routerAddress, amountIn, amountIn);
      builder.addCall(
        this.routerAddress,
        uniswapV3RouterAbi as readonly unknown[] as import("viem").Abi,
        "exactInput",
        [
          {
            path: encodedPath,
            recipient,
            deadline: DEFAULT_DEADLINE,
            amountIn,
            amountOutMinimum: 0n,
          },
        ]
      );
      return;
    }
    validatePathV3(path);
    const [, tokenOut] = path;
    const amountOutMinimum = 0n;
    builder.addApprove(tokenIn, this.routerAddress, amountIn, amountIn);
    builder.addCall(
      this.routerAddress,
      uniswapV3RouterAbi as readonly unknown[] as import("viem").Abi,
      "exactInputSingle",
      [
        {
          tokenIn,
          tokenOut: tokenOut!,
          fee: this.fee,
          recipient,
          deadline: DEFAULT_DEADLINE,
          amountIn,
          amountOutMinimum,
          sqrtPriceLimitX96: SQRT_PRICE_LIMIT_X96,
        },
      ]
    );
  }

  buildExactOut(
    builder: CalldataBuilder,
    path: Address[],
    amountOut: bigint,
    recipient: Address,
    amountInMax?: bigint
  ): void {
    const tokenIn = path[0]!;
    const maxUint256 = 2n ** 256n - 1n;
    const amountInMaximum = maxUint256;
    const actualAmount = amountInMax ?? maxUint256;

    if (this.isMultiHop(path)) {
      const encodedPath = encodeV3Path(path, this.fee, true);
      builder.addApprove(tokenIn, this.routerAddress, amountInMaximum, actualAmount);
      builder.addCall(
        this.routerAddress,
        uniswapV3RouterAbi as readonly unknown[] as import("viem").Abi,
        "exactOutput",
        [
          {
            path: encodedPath,
            recipient,
            deadline: DEFAULT_DEADLINE,
            amountOut,
            amountInMaximum,
          },
        ]
      );
      return;
    }
    validatePathV3(path);
    const [, tokenOut] = path;
    builder.addApprove(tokenIn, this.routerAddress, amountInMaximum, actualAmount);
    builder.addCall(
      this.routerAddress,
      uniswapV3RouterAbi as readonly unknown[] as import("viem").Abi,
      "exactOutputSingle",
      [
        {
          tokenIn,
          tokenOut: tokenOut!,
          fee: this.fee,
          recipient,
          deadline: DEFAULT_DEADLINE,
          amountOut,
          amountInMaximum,
          sqrtPriceLimitX96: SQRT_PRICE_LIMIT_X96,
        },
      ]
    );
  }
}
