import type { Address, Abi } from "viem";
import type { CalldataBuilder } from "../calldata/CalldataBuilder.js";
import type { DexAdapter, MulticallContract } from "./DexAdapter.js";
import { aaveV3PoolAbi, erc20Abi } from "../contracts/abis.js";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";

/**
 * Aave V3 Adapter for 1:1 aToken <-> underlying conversions.
 *
 * Unlike DEX adapters, this handles protocol-level operations:
 * - supply: underlying -> aToken (1:1, via Pool.supply)
 * - withdraw: aToken -> underlying (1:1, via Pool.withdraw)
 *
 * The adapter is instantiated after RPC Call 1 with the aToken mapping
 * fetched from the Aave Protocol Data Provider. It is NOT registered
 * as a regular DEX adapter; instead it is used by BundleCalldataBuilder
 * to insert supply/withdraw steps for aToken targets.
 */
export class AaveV3Adapter implements DexAdapter {
  name = "AaveV3";

  /** aToken (lowercase) -> underlying (checksummed) */
  private aTokenToUnderlying: Map<string, Address>;
  /** underlying (lowercase) -> aToken (checksummed) */
  private underlyingToAToken: Map<string, Address>;

  constructor(
    private poolAddress: Address = DEFAULT_CONTRACT_ADDRESSES.AAVE_V3_POOL,
    aTokenToUnderlying: Map<string, Address> = new Map(),
    underlyingToAToken: Map<string, Address> = new Map()
  ) {
    this.aTokenToUnderlying = aTokenToUnderlying;
    this.underlyingToAToken = underlyingToAToken;
  }

  // ── Lookup helpers ──────────────────────────────────────────────────

  /** Check if an address is a known aToken. */
  isAToken(address: Address): boolean {
    return this.aTokenToUnderlying.has(address.toLowerCase());
  }

  /** Get the underlying for an aToken, or undefined if not an aToken. */
  getUnderlying(aToken: Address): Address | undefined {
    return this.aTokenToUnderlying.get(aToken.toLowerCase());
  }

  /** Get the aToken for an underlying, or undefined if no aToken exists. */
  getAToken(underlying: Address): Address | undefined {
    return this.underlyingToAToken.get(underlying.toLowerCase());
  }

  // ── DexAdapter: path validation ────────────────────────────────────

  /**
   * Returns true if path is [underlying, aToken] (supply) or [aToken, underlying] (withdraw).
   */
  canHandlePath(path: Address[], _isExactIn: boolean): boolean {
    if (path.length !== 2) return false;
    const [tokenA, tokenB] = path as [Address, Address];

    // supply: underlying -> aToken
    const aTokenForA = this.underlyingToAToken.get(tokenA.toLowerCase());
    if (aTokenForA && aTokenForA.toLowerCase() === tokenB.toLowerCase()) return true;

    // withdraw: aToken -> underlying
    const underlyingForA = this.aTokenToUnderlying.get(tokenA.toLowerCase());
    if (underlyingForA && underlyingForA.toLowerCase() === tokenB.toLowerCase()) return true;

    return false;
  }

  // ── DexAdapter: quoting (1:1, no RPC needed) ───────────────────────

  async quoteExactIn(_path: Address[], amountIn: bigint): Promise<bigint> {
    return amountIn; // 1:1
  }

  async quoteExactOut(_path: Address[], amountOut: bigint): Promise<bigint> {
    return amountOut; // 1:1
  }

  /**
   * Since aToken conversions are 1:1, we use balanceOf(address(0)) as a cheap
   * no-op view call that will succeed on-chain. The Router never actually uses
   * the result — it knows the quote is 1:1 for AaveV3 paths.
   */
  getQuoteExactInContract(path: Address[], amountIn: bigint): MulticallContract {
    // Return a cheap view call; the Router should treat AaveV3 quotes as 1:1.
    return {
      address: path[0]!,
      abi: erc20Abi as readonly unknown[],
      functionName: "balanceOf",
      args: [path[0]!],
    };
  }

  getQuoteExactOutContract(path: Address[], amountOut: bigint): MulticallContract {
    return {
      address: path[0]!,
      abi: erc20Abi as readonly unknown[],
      functionName: "balanceOf",
      args: [path[0]!],
    };
  }

  // ── DexAdapter: calldata building ──────────────────────────────────

  /**
   * Build exact-in calldata.
   * - [underlying, aToken] → approve underlying to Pool, then Pool.supply()
   * - [aToken, underlying] → Pool.withdraw()
   */
  buildExactIn(
    builder: CalldataBuilder,
    path: Address[],
    amountIn: bigint,
    recipient: Address
  ): void {
    if (path.length !== 2) throw new Error("AaveV3Adapter: path must be length 2");
    const [tokenIn, tokenOut] = path as [Address, Address];

    if (this._isSupplyPath(tokenIn, tokenOut)) {
      // Supply: underlying -> aToken
      this._buildSupply(builder, tokenIn, amountIn, recipient);
    } else if (this._isWithdrawPath(tokenIn, tokenOut)) {
      // Withdraw: aToken -> underlying
      this._buildWithdraw(builder, tokenOut, amountIn, recipient);
    } else {
      throw new Error(`AaveV3Adapter: invalid path [${tokenIn}, ${tokenOut}]`);
    }
  }

  /**
   * Build exact-out calldata. Since ratio is 1:1, equivalent to exact-in.
   */
  buildExactOut(
    builder: CalldataBuilder,
    path: Address[],
    amountOut: bigint,
    recipient: Address,
    _amountInMax?: bigint
  ): void {
    // 1:1 ratio: amountIn === amountOut
    this.buildExactIn(builder, path, amountOut, recipient);
  }

  // ── Private helpers ────────────────────────────────────────────────

  private _isSupplyPath(tokenIn: Address, tokenOut: Address): boolean {
    const aToken = this.underlyingToAToken.get(tokenIn.toLowerCase());
    return aToken !== undefined && aToken.toLowerCase() === tokenOut.toLowerCase();
  }

  private _isWithdrawPath(tokenIn: Address, tokenOut: Address): boolean {
    const underlying = this.aTokenToUnderlying.get(tokenIn.toLowerCase());
    return underlying !== undefined && underlying.toLowerCase() === tokenOut.toLowerCase();
  }

  /**
   * Pool.supply(asset, amount, onBehalfOf, referralCode)
   * Requires prior approval of underlying to Pool.
   */
  private _buildSupply(
    builder: CalldataBuilder,
    underlying: Address,
    amount: bigint,
    recipient: Address
  ): void {
    const maxUint256 = 2n ** 256n - 1n;
    builder.addApprove(underlying, this.poolAddress, maxUint256, amount);
    builder.addCall(
      this.poolAddress,
      aaveV3PoolAbi as Abi,
      "supply",
      [underlying, amount, recipient, 0]
    );
  }

  /**
   * Pool.withdraw(asset, amount, to)
   * Burns aTokens held by the caller and sends underlying to `to`.
   */
  private _buildWithdraw(
    builder: CalldataBuilder,
    underlying: Address,
    amount: bigint,
    recipient: Address
  ): void {
    builder.addCall(
      this.poolAddress,
      aaveV3PoolAbi as Abi,
      "withdraw",
      [underlying, amount, recipient]
    );
  }
}

/**
 * Build the aToken <-> underlying maps from the Protocol Data Provider results.
 * Both arrays iterate the same reserves list, so entries at the same index correspond.
 *
 * @param reserves Result of getAllReservesTokens(): Array<{ symbol: string, tokenAddress: Address }>
 * @param aTokens  Result of getAllATokens(): Array<{ symbol: string, tokenAddress: Address }>
 * @returns { aTokenToUnderlying, underlyingToAToken } maps with lowercase keys and checksummed values.
 */
export function buildATokenMaps(
  reserves: readonly { symbol: string; tokenAddress: Address }[],
  aTokens: readonly { symbol: string; tokenAddress: Address }[]
): {
  aTokenToUnderlying: Map<string, Address>;
  underlyingToAToken: Map<string, Address>;
} {
  const aTokenToUnderlying = new Map<string, Address>();
  const underlyingToAToken = new Map<string, Address>();

  const len = Math.min(reserves.length, aTokens.length);
  for (let i = 0; i < len; i++) {
    const underlying = reserves[i]!.tokenAddress;
    const aToken = aTokens[i]!.tokenAddress;
    aTokenToUnderlying.set(aToken.toLowerCase(), underlying);
    underlyingToAToken.set(underlying.toLowerCase(), aToken);
  }

  return { aTokenToUnderlying, underlyingToAToken };
}
