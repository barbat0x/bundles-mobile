import type { Address, PublicClient } from "viem";
import { validatePathV2 } from "../router/path.js";
import type { CalldataBuilder } from "../calldata/CalldataBuilder.js";
import type { DexAdapter, MulticallContract } from "./DexAdapter.js";
import { uniswapV2RouterAbi } from "../contracts/abis.js";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";

/** Default deadline: far future (max uint256 would be even safer). */
const DEFAULT_DEADLINE = 2n ** 32n - 1n;

/** Uniswap V2-style adapter. Path length >= 2. */
export class UniswapV2Adapter implements DexAdapter {
  name = "UniswapV2";

  constructor(
    private client: PublicClient,
    private routerAddress: Address = DEFAULT_CONTRACT_ADDRESSES.UNISWAP_V2_ROUTER,
    private weth: Address = DEFAULT_CONTRACT_ADDRESSES.WETH
  ) { }

  async quoteExactIn(path: Address[], amountIn: bigint): Promise<bigint> {
    validatePathV2(path);
    const amounts = await this.client.readContract({
      address: this.routerAddress,
      abi: uniswapV2RouterAbi,
      functionName: "getAmountsOut",
      args: [amountIn, path],
    });
    return amounts.length > 0 ? amounts[amounts.length - 1]! : 0n;
  }

  async quoteExactOut(path: Address[], amountOut: bigint): Promise<bigint> {
    validatePathV2(path);
    const amounts = await this.client.readContract({
      address: this.routerAddress,
      abi: uniswapV2RouterAbi,
      functionName: "getAmountsIn",
      args: [amountOut, path],
    });
    return amounts.length > 0 ? amounts[0]! : 0n;
  }

  getQuoteExactInContract(path: Address[], amountIn: bigint): MulticallContract {
    validatePathV2(path);
    return {
      address: this.routerAddress,
      abi: uniswapV2RouterAbi,
      functionName: "getAmountsOut",
      args: [amountIn, path],
    };
  }

  getQuoteExactOutContract(path: Address[], amountOut: bigint): MulticallContract {
    validatePathV2(path);
    return {
      address: this.routerAddress,
      abi: uniswapV2RouterAbi,
      functionName: "getAmountsIn",
      args: [amountOut, path],
    };
  }

  buildExactIn(
    builder: CalldataBuilder,
    path: Address[],
    amountIn: bigint,
    recipient: Address
  ): void {
    validatePathV2(path);
    const tokenIn = path[0]!;
    // Use quoted amount as minimum (no slippage buffer for demo; can add 99% of quote later).
    const amountOutMin = 0n; // Builder will typically get quote first; caller can pass via context. For demo we use 0.
    builder.addApprove(tokenIn, this.routerAddress, amountIn, amountIn);
    builder.addCall(
      this.routerAddress,
      uniswapV2RouterAbi as readonly unknown[] as import("viem").Abi,
      "swapExactTokensForTokens",
      [amountIn, amountOutMin, path, recipient, DEFAULT_DEADLINE]
    );
  }

  buildExactOut(
    builder: CalldataBuilder,
    path: Address[],
    amountOut: bigint,
    recipient: Address,
    amountInMax?: bigint
  ): void {
    validatePathV2(path);
    const tokenIn = path[0]!;
    const maxUint256 = 2n ** 256n - 1n;
    const approvalAmount = maxUint256; // Use max for safety
    const actualAmount = amountInMax ?? maxUint256; // Use quoted amount if available
    builder.addApprove(tokenIn, this.routerAddress, approvalAmount, actualAmount);
    builder.addCall(
      this.routerAddress,
      uniswapV2RouterAbi as readonly unknown[] as import("viem").Abi,
      "swapTokensForExactTokens",
      [amountOut, maxUint256, path, recipient, DEFAULT_DEADLINE]
    );
  }
}
