import type { Address, PublicClient } from "viem";
import { validatePathV2 } from "../router/path.js";
import type { CalldataBuilder } from "../calldata/CalldataBuilder.js";
import type { DexAdapter, MulticallContract } from "./DexAdapter.js";
import { bundleSwapRouterAbi } from "../contracts/abis.js";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";
import {
  getFeePath,
  validateProtocolTokenPath,
} from "./protocolTokenHelpers.js";

/** Default deadline: far future (matches Python future_timestamp usage). */
const DEFAULT_DEADLINE = 2n ** 32n - 1n;
const MAX_FEE = 2n ** 256n - 1n;

/** BundleSwap adapter: protocol token swaps with struct-based API (IBundleSwapRouter). */
export class BundlesSwapAdapter implements DexAdapter {
  name = "BundlesSwap";

  constructor(
    private client: PublicClient,
    private routerAddress: Address = DEFAULT_CONTRACT_ADDRESSES.BUNDLES_SWAP_ROUTER_MAINNET,
    private protocolToken: Address = DEFAULT_CONTRACT_ADDRESSES.BUNDLES_PROTOCOL_TOKEN_MAINNET,
    private weth: Address = DEFAULT_CONTRACT_ADDRESSES.WETH
  ) { }

  canHandlePath?(path: Address[], _isExactIn: boolean): boolean {
    if (path.length < 2) return false;
    try {
      validateProtocolTokenPath(path, this.protocolToken);
      return true;
    } catch {
      return false;
    }
  }

  async quoteExactIn(path: Address[], amountIn: bigint): Promise<bigint> {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const fees = getFeePath(path);
    const amounts = await this.client.readContract({
      address: this.routerAddress,
      abi: bundleSwapRouterAbi,
      functionName: "getAmountsOut",
      args: [amountIn, path, fees],
    });
    return amounts.length > 0 ? amounts[amounts.length - 1]! : 0n;
  }

  async quoteExactOut(path: Address[], amountOut: bigint): Promise<bigint> {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const fees = getFeePath(path);
    const amounts = await this.client.readContract({
      address: this.routerAddress,
      abi: bundleSwapRouterAbi,
      functionName: "getAmountsIn",
      args: [amountOut, path, fees],
    });
    return amounts.length > 0 ? amounts[0]! : 0n;
  }

  getQuoteExactInContract(path: Address[], amountIn: bigint): MulticallContract {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const fees = getFeePath(path);
    return {
      address: this.routerAddress,
      abi: bundleSwapRouterAbi,
      functionName: "getAmountsOut",
      args: [amountIn, path, fees],
    };
  }

  getQuoteExactOutContract(path: Address[], amountOut: bigint): MulticallContract {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const fees = getFeePath(path);
    return {
      address: this.routerAddress,
      abi: bundleSwapRouterAbi,
      functionName: "getAmountsIn",
      args: [amountOut, path, fees],
    };
  }

  buildExactIn(
    builder: CalldataBuilder,
    path: Address[],
    amountIn: bigint,
    recipient: Address
  ): void {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const tokenIn = path[0]!;
    const tokenOut = path[path.length - 1]!;
    const fees = getFeePath(path);
    const amountOutMin = 0n;

    // Determine swap function based on whether path starts/ends with WETH
    // Use RECIPIENT_PLACEHOLDER so encodeForUniversalRouter can replace it with actual recipient
    const deadline = DEFAULT_DEADLINE;

    if (tokenIn === this.weth) {
      // WETH to token(s) - approve WETH then use token swap (UR already wrapped ETH)
      builder.addApprove(tokenIn, this.routerAddress, amountIn, amountIn);
      builder.addCall(
        this.routerAddress,
        bundleSwapRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapExactTokensForTokens",
        [{
          amountIn,
          amountOutMin,
          maxFee: MAX_FEE,
          path,
          fees,
          to: DEFAULT_CONTRACT_ADDRESSES.RECIPIENT_PLACEHOLDER,
          deadline,
        }]
      );
    } else if (tokenOut === this.weth) {
      // Token(s) to ETH - need approval; tuple (amountIn, amountOutMin, maxFee, path, fees, to, deadline)
      builder.addApprove(tokenIn, this.routerAddress, amountIn, amountIn);
      builder.addCall(
        this.routerAddress,
        bundleSwapRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapExactTokensForETH",
        [{
          amountIn,
          amountOutMin,
          maxFee: MAX_FEE,
          path,
          fees,
          to: DEFAULT_CONTRACT_ADDRESSES.RECIPIENT_PLACEHOLDER,
          deadline,
        }]
      );
    } else {
      // Token to token - need approval; tuple (amountIn, amountOutMin, maxFee, path, fees, to, deadline)
      builder.addApprove(tokenIn, this.routerAddress, amountIn, amountIn);
      builder.addCall(
        this.routerAddress,
        bundleSwapRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapExactTokensForTokens",
        [{
          amountIn,
          amountOutMin,
          maxFee: MAX_FEE,
          path,
          fees,
          to: DEFAULT_CONTRACT_ADDRESSES.RECIPIENT_PLACEHOLDER,
          deadline,
        }]
      );
    }
  }

  buildExactOut(
    builder: CalldataBuilder,
    path: Address[],
    amountOut: bigint,
    recipient: Address,
    amountInMaxQuoted?: bigint
  ): void {
    validatePathV2(path);
    validateProtocolTokenPath(path, this.protocolToken);
    const tokenIn = path[0]!;
    const tokenOut = path[path.length - 1]!;
    const fees = getFeePath(path);
    // Always use max uint256 for amountInMax to avoid rounding issues with protocol token fee calculations
    // Slippage protection will be added at execution level
    const maxUint256 = 2n ** 256n - 1n;
    const approvalAmount = maxUint256;
    const actualAmount = amountInMaxQuoted ?? maxUint256;

    // Match Python protocol_token_mixin.swap_tokens_for_exact_tokens: no special WETH handling
    // Approve path[0] and call swapTokensForExactTokens for all token->token swaps
    // Use RECIPIENT_PLACEHOLDER so encodeForUniversalRouter can replace it with actual recipient
    const deadline = DEFAULT_DEADLINE;

    if (tokenOut === this.weth) {
      // Token(s) to ETH - use swapTokensForExactETH
      builder.addApprove(tokenIn, this.routerAddress, approvalAmount, actualAmount);
      builder.addCall(
        this.routerAddress,
        bundleSwapRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapTokensForExactETH",
        [{
          amountOut,
          amountInMax: maxUint256,
          maxFee: MAX_FEE,
          path,
          fees,
          to: DEFAULT_CONTRACT_ADDRESSES.RECIPIENT_PLACEHOLDER,
          deadline,
        }]
      );
    } else {
      // Token to token (including WETH->token): approve path[0] and use swapTokensForExactTokens
      // This matches Python: self.approve(path[0]) then swapTokensForExactTokens
      builder.addApprove(tokenIn, this.routerAddress, approvalAmount, actualAmount);
      builder.addCall(
        this.routerAddress,
        bundleSwapRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapTokensForExactTokens",
        [{
          amountOut,
          amountInMax: maxUint256,
          maxFee: MAX_FEE,
          path,
          fees,
          to: DEFAULT_CONTRACT_ADDRESSES.RECIPIENT_PLACEHOLDER,
          deadline,
        }]
      );
    }
  }
}
