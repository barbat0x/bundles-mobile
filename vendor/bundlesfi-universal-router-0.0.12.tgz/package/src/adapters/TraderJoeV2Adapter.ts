import type { Address, PublicClient } from "viem";
import { validatePathV2 } from "../router/path.js";
import type { CalldataBuilder } from "../calldata/CalldataBuilder.js";
import type { DexAdapter, MulticallContract } from "./DexAdapter.js";
import { joeRouterAbi } from "../contracts/abis.js";
import { DEFAULT_CONTRACT_ADDRESSES } from "../config/addresses.js";

/** Default deadline: far future (max uint256 would be even safer). */
const DEFAULT_DEADLINE = 2n ** 32n - 1n;

/** TraderJoe V2-style adapter. Path length >= 2. Uses AVAX instead of ETH. */
export class TraderJoeV2Adapter implements DexAdapter {
  name = "TraderJoeV2";

  constructor(
    private client: PublicClient,
    private routerAddress: Address = DEFAULT_CONTRACT_ADDRESSES.TRADERJOE_V2_ROUTER_FUJI,
    private wavax: Address = DEFAULT_CONTRACT_ADDRESSES.WETH // WAVAX on Avalanche
  ) { }

  canHandlePath?(path: Address[], _isExactIn: boolean): boolean {
    return path.length >= 2;
  }

  async quoteExactIn(path: Address[], amountIn: bigint): Promise<bigint> {
    validatePathV2(path);
    const amounts = await this.client.readContract({
      address: this.routerAddress,
      abi: joeRouterAbi,
      functionName: "getAmountsOut",
      args: [amountIn, path],
    });
    return amounts.length > 0 ? amounts[amounts.length - 1]! : 0n;
  }

  async quoteExactOut(path: Address[], amountOut: bigint): Promise<bigint> {
    validatePathV2(path);
    const amounts = await this.client.readContract({
      address: this.routerAddress,
      abi: joeRouterAbi,
      functionName: "getAmountsIn",
      args: [amountOut, path],
    });
    return amounts.length > 0 ? amounts[0]! : 0n;
  }

  getQuoteExactInContract(path: Address[], amountIn: bigint): MulticallContract {
    validatePathV2(path);
    return {
      address: this.routerAddress,
      abi: joeRouterAbi,
      functionName: "getAmountsOut",
      args: [amountIn, path],
    };
  }

  getQuoteExactOutContract(path: Address[], amountOut: bigint): MulticallContract {
    validatePathV2(path);
    return {
      address: this.routerAddress,
      abi: joeRouterAbi,
      functionName: "getAmountsIn",
      args: [amountOut, path],
    };
  }

  buildExactIn(
    builder: CalldataBuilder,
    path: Address[],
    amountIn: bigint,
    recipient: Address
  ): void {
    validatePathV2(path);
    const tokenIn = path[0]!;
    const tokenOut = path[path.length - 1]!;
    const amountOutMin = 0n;

    // Determine swap function based on whether path starts/ends with WAVAX
    if (tokenIn === this.wavax) {
      // AVAX to token(s) - payable, no approval needed
      builder.addCall(
        this.routerAddress,
        joeRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapExactAVAXForTokens",
        [amountOutMin, path, recipient, DEFAULT_DEADLINE]
      );
    } else if (tokenOut === this.wavax) {
      // Token(s) to AVAX - need approval
      builder.addApprove(tokenIn, this.routerAddress, amountIn, amountIn);
      builder.addCall(
        this.routerAddress,
        joeRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapExactTokensForAVAX",
        [amountIn, amountOutMin, path, recipient, DEFAULT_DEADLINE]
      );
    } else {
      // Token to token - need approval
      builder.addApprove(tokenIn, this.routerAddress, amountIn, amountIn);
      builder.addCall(
        this.routerAddress,
        joeRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapExactTokensForTokens",
        [amountIn, amountOutMin, path, recipient, DEFAULT_DEADLINE]
      );
    }
  }

  buildExactOut(
    builder: CalldataBuilder,
    path: Address[],
    amountOut: bigint,
    recipient: Address,
    amountInMax?: bigint
  ): void {
    validatePathV2(path);
    const tokenIn = path[0]!;
    const tokenOut = path[path.length - 1]!;
    const maxUint256 = 2n ** 256n - 1n;
    const approvalAmount = maxUint256;
    const actualAmount = amountInMax ?? maxUint256;

    // Determine swap function based on whether path starts/ends with WAVAX
    if (tokenIn === this.wavax) {
      // AVAX to token(s) - payable
      builder.addCall(
        this.routerAddress,
        joeRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapAVAXForExactTokens",
        [amountOut, path, recipient, DEFAULT_DEADLINE]
      );
    } else if (tokenOut === this.wavax) {
      // Token(s) to AVAX - need approval
      builder.addApprove(tokenIn, this.routerAddress, approvalAmount, actualAmount);
      builder.addCall(
        this.routerAddress,
        joeRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapTokensForExactAVAX",
        [amountOut, maxUint256, path, recipient, DEFAULT_DEADLINE]
      );
    } else {
      // Token to token - need approval
      builder.addApprove(tokenIn, this.routerAddress, approvalAmount, actualAmount);
      builder.addCall(
        this.routerAddress,
        joeRouterAbi as readonly unknown[] as import("viem").Abi,
        "swapTokensForExactTokens",
        [amountOut, maxUint256, path, recipient, DEFAULT_DEADLINE]
      );
    }
  }
}
